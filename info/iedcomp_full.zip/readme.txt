=======================================
Internet EDiting Components 1.0 package
=======================================

HREFParser 1.2 

 This non visual component is intended to extract all links 
 that founded in your HTML file (images, emails, http links,
 ftp links).It also automaticly detect and parse hyperlink 
 links into PHP,CSS pages. It will list all related links.
 HREFParser is a part of Internet EDiting components.
 Very easy in use and customizable. Compiled demo is included.
 
IEDXMLreader 1.0 

 This non visual component is intended to parse XML structure.
 It optimized for parsing  WebDav response. 
 Very fast and easy in use. Compiled demo is included.
 
IEDWebDav  1.0
 This non visual component is intended for the management of 
 remote resource properties, creation and management of remote 
 resource collections, namespace manipulation, and resource 
 locking (collision avoidance). It based on RFC2518 (HTTP 
 Extensions for Distributed Authoring).
 Very fast and easy in use. Compiled demo is included.

IED components has been written by Sergey Kanenko and is 
copyright 2002 of myself. Contact me before including it 
in any package (commercial or not).


History
---------------
July   2002   Initial public release IED_light
August 2002   Initial public release IED

Installation
---------------
 HREFparser component may be compiled with Delphi 5 and 6 
 Some demo and IED components may be compiled only with Delphi 6

Uninstall previous installed version of IED light from Delphi IDE.
Use "File\Open..." menu item to open IED  light package IED_L.dpk.
In "Package..." window click "Compile" button to compile the package
and then click "Install" button to register IED light Library components on
the component palette.
Use "File\Open..." menu item of Delphi IDE to open demo/DiagramDemo.dpr 
Click "Run" button to compile and run demo application. 

Contacts
---------------

Main site  : http://iedcomp.nm.ru
Mirror site: http://iedcomp.happytocode.com

EMail: iedcomp@nm.ru <Sergey Kanenko>

=========================================================
=========================================================
Copyright � 2001-2002 Sergey Kanenko. All Rights Reserved.