//---------------------------------------------------------------------------

#include <basepch.h>
#pragma hdrstop


USEFORMNS("..\Source\OverbyteIcsTnOptFrm.pas", Overbyteicstnoptfrm, OptForm);
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------


#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
    return 1;
}
//---------------------------------------------------------------------------
