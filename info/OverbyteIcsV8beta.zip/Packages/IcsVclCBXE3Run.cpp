//---------------------------------------------------------------------------

#include <System.hpp>
#pragma hdrstop





USEFORMNS("Z:\Source\OverbyteIcsTnOptFrm.pas", Overbyteicstnoptfrm, OptForm);
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------


#pragma argsused
extern "C" int _libmain(unsigned long reason)
{
	return 1;
}
//---------------------------------------------------------------------------
