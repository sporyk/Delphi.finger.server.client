======================
  iPRO Unit Tests
======================

The folders in this directory contain the Internet Professional unit
tests. The unit tests are implemented using DUnit.

DUnit website on SourceForge: http://sourceforge.net/projects/dunit/

Because the creation of these unit tests started well after the product
was released, they are not as comprehensive as they should be.

The test projects assume the location of the DUnit source code, relative
to the iPRO installation, is as follows:


C:\
|
+---DUnit
|   |
|   +---Src
|
+---iPRO
    |
    +---Test
        |
        +---<test folder>


Each test folder contains tests for a specific set of functionality in
iPRO. Each test folder contains a project file (e.g., TestFTP.dpr) and
one or more units containing unit tests.

The iPRO\Test\All folder contains a project that runs all of the unit
tests in the iPRO\Test subfolders.
