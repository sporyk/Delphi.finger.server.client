Description of test cases:

1.msg - Contains standard, user-defined, and unsupported header
	fields. All should be ported over to the output message.

2.msg - The filename attribute of the Content-Disposition field in the
	last MIME part should be carried over to the output message.

        *** This test fails due to omitted blank line at end of msg.
	    This is WAD. ***

3.msg - There are two blank lines after the last header field. The
	first blank line should be skipped but the next blank line
	should be included in the message.

4.msg - The trailing line of text at the end of the message should be
	included in the same position within the output message.

        *** This test fails due to the text being included at front of
	    message. This is WAD. ***

5.msg - This was added to test issue 3696. For Content-Disposition
	header field, parameter Filename, if a filename contains a
	space, control characters, or other special characters (as
	defined in RFC 1521), then it should be wrapped in double
	quotes.

6.msg - This was added to test the case where copying a binary
	attachment resulted in a stream read error. Issue 3987.

7.msg - This was added as a result of issue 4013. The MIME parts begin
	with the MIME-Version header field instead of the Content-Type
	header field.

8.msg, 9.msg, 10.msg - These are cases where the text/plain or html
	parts are nested. Without a bug fix, the
	TIpMessage.GetBodyPlain and GetBodyHTML methods could not see
	the corresponding MIME parts and would return a blank body for
	each.

11.msg through 14.msg - These are cases where the leading MIME part is
	empty. Without a bug fix, the message decoder was making the
	next MIME boundary, header fields, & body part of the body of
	the empty MIME part.

