The NNTPUI project attaches logging events to the
NNTP unit tests and displays the logging information
in a memo field.