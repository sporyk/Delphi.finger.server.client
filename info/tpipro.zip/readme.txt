TurboPower Internet Professional (iPRO)


Table of contents

1.  Introduction
2.  Package names
3.  Installation
4.  Version history
4.1   Release 1.15

==============================================


1. Introduction


iPRO is a set of VCL components providing Internet connectivity for
Borland Delphi & C++Builder. iPRO includes POP3, SMTP, NNTP, FTP,
HTTP, Instant Messaging, & HTML viewer components, as well as
components for low-level socket access.

This is a source-only release of TurboPower iPRO. It includes
designtime and runtime packages for Delphi 3 through 7 and C++Builder
3 through 6.

==============================================

2. Package names


TurboPower iPRO package names have the following form:

  IPRO_DVV.*
       ||
       |+------ VV  VCL version (30=Delphi 3, 35=C++Builder 3, 40=Delphi 4)
       +------- K   Kind of package (D=designtime)


For example, the iPRO designtime package files for Delphi 7 have
the filename IPRO_D70.*.

==============================================

3. Installation


To install TurboPower iPRO into your IDE, take the following steps:

  1. Unzip the release files into a directory (e.g., d:\ipro).

  2. Start Delphi or C++Builder.

  3. Add the source subdirectory (e.g., d:\ipro\source) to the
     IDE's library path.

  4. Open & install the designtime package specific to the IDE being
     used. The IDE should notify you the components have been
     installed.

  5. Make sure the PATH environmental variable contains the directory
     in which the compiled packages (i.e., BPL or DPL files) were
     placed.

==============================================

4. Version history


4.1 Release 1.15

    Bug fixes
    -------------------------------------------------------------
    4007 - TIpCache.DeleteStrays method does not delete strays
    4012 - Should be able to decode quoted-printable messages with soft line breaks
    4013 - Cannot decode message whose MIME parts start with MIME-Version header
    4022 - ICMP thread assumes that parent's debugLog exists
    4033 - HTML body not found if nested in MIME part
    4034 - Incorrect logic in TIpHeaderCollection.LoadHeaders
    4063 - Message decoder does not correctly handle empty MIME part
    4069 - Missing GIF causes repeated attempts to load the GIF
    4072 - Speed improvement for TIpMessage.LoadFromFile
    4073 - Incorrect attachment count
    4074 - TIpMessage.Clear not clearing all message variables
    4075 - TIpAnsiTextStream.WriteLine does not correctly handle empty strings
    4113 - DecodeBase64 does not init InBuf var
    4124 - AV in TIpHtmlNodeIMG.Draw if graphic not available
    4125 - Hidden input fields not posted with form data
    4185 - HTMLPanel incorrectly renders <DL> elements
