// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("ImDemo.res");
USEFORM("ImMain.cpp", frmMain);
USEFORM("ImProps.cpp", frmMyProperties);
USEFORM("ImOpts.cpp", frmOptions);
USEFORM("ImSelect.cpp", frmSelectForSend);
USEFORM("ImSignIn.cpp", frmSignin);
USEFORM("ImAddCon.cpp", frmAddContact);
USEFORM("ImHelp.cpp", frmHelp);
USEFORM("ImForm.cpp", frmIM);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    try
    {
        Application->Initialize();
        Application->CreateForm(__classid(TfrmMain), &frmMain);
        Application->CreateForm(__classid(TfrmMyProperties), &frmMyProperties);
        Application->CreateForm(__classid(TfrmOptions), &frmOptions);
        Application->CreateForm(__classid(TfrmSelectForSend), &frmSelectForSend);
        Application->CreateForm(__classid(TfrmSignin), &frmSignin);
        Application->CreateForm(__classid(TfrmAddContact), &frmAddContact);
        Application->CreateForm(__classid(TfrmHelp), &frmHelp);
        Application->CreateForm(__classid(TfrmIM), &frmIM);
        Application->Run();
    }
    catch (Exception &exception)
    {
        Application->ShowException(&exception);
    }
    return 0;
}
//---------------------------------------------------------------------------
