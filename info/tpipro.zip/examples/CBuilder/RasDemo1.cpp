// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "RasDemo1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpRas"
#pragma link "IpUtils"
#pragma link "IpRasSt"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  chkUsePrefixSuffix->Checked =
    IpRasDialer->ExtendedDialOptions.Contains(edoUsePrefixSuffix);
  chkPausedStates->Checked =
    IpRasDialer->ExtendedDialOptions.Contains(edoAllowPausedStates);
  chkIgnoreModemSpeaker->Checked =
    IpRasDialer->ExtendedDialOptions.Contains(edoIgnoreModemSpeaker);
  chkSetModemSpeaker->Checked =
    IpRasDialer->ExtendedDialOptions.Contains(edoSetModemSpeaker);
  chkIgnoreSWCompression->Checked =
    IpRasDialer->ExtendedDialOptions.Contains(edoIgnoreSWCompression);
  chkSetSWCompression->Checked =
    IpRasDialer->ExtendedDialOptions.Contains(edoSetSWCompression);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DisplayDialParameters(void)
{
  UserNameEdit->Text        = IpRasDialer->UserName;
  DomainEdit->Text          = IpRasDialer->Domain;
  PhoneNumberEdit->Text     = IpRasDialer->PhoneNumber;
  DialModeSelect->ItemIndex = (int)IpRasDialer->DialMode;
  PasswordEdit->Text        = IpRasDialer->Password;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SetDialParameters(void)
{
  IpRasDialer->Password    = PasswordEdit->Text;
  IpRasDialer->UserName    = UserNameEdit->Text;
  IpRasDialer->Domain      = DomainEdit->Text;
  IpRasDialer->PhoneNumber = PhoneNumberEdit->Text;
  IpRasDialer->DialMode    = (TIpRasDialMode)DialModeSelect->ItemIndex;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Dial1Click(TObject *Sender)
{
  SetDialParameters();
  int Error = IpRasDialer->Dial();
  if (Error != 0)
    StatusBar1->Panels->Items[0]->Text = IpRasDialer->GetErrorText(Error);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Hangup1Click(TObject *Sender)
{
  IpRasDialer->Hangup();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::NewPhonebookEntryClick(TObject *Sender)
{
  int Error = IpRasDialer->CreatePhonebookEntry();
  if (Error != 0)
    StatusBar1->Panels->Items[0]->Text = IpRasDialer->GetErrorText(Error);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::EditPhonebookEntryClick(TObject *Sender)
{
  int Error = IpRasDialer->EditPhonebookEntry();
  if (Error == 0)
    DisplayDialParameters();
  else
    StatusBar1->Panels->Items[0]->Text = IpRasDialer->GetErrorText(Error);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Deleteentry1Click(TObject *Sender)
{
  int Error = IpRasDialer->DeletePhonebookEntry();
  if (Error == 0)
    DisplayDialParameters();
  else
    StatusBar1->Panels->Items[0]->Text = IpRasDialer->GetErrorText(Error);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpRasDialerDialStatus(TObject *Sender, int Status)
{
  StatusBar1->Panels->Items[0]->Text = IpRasDialer->GetStatusText(Status);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::PhonebookBtnClick(TObject *Sender)
{
  OpenDialog->FileName = "*.pbk";
  if (OpenDialog->Execute())
    PhoneBookEdit->Text = OpenDialog->FileName;
  else
    PhoneBookEdit->Text = "Default";
  IpRasDialer->Phonebook = PhoneBookEdit->Text;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Exit1Click(TObject *Sender)
{
  Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpRasDialerConnected(TObject *Sender)
{
  StatusBar1->Panels->Items[0]->Text = "Connected";
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpRasDialerDialError(TObject *Sender, int Error)
{
  StatusBar1->Panels->Items[0]->Text = IpRasDialer->GetErrorText(Error);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpRasDialerDisconnected(TObject *Sender)
{
  StatusBar1->Panels->Items[0]->Text = "Disconnected";
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpRasEntryComboBoxChange(TObject *Sender)
{
  DisplayDialParameters();
  StatusBar1->Panels->Items[0]->Text = IpRasDialer->EntryName;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::chkUsePrefixSuffixClick(TObject *Sender)
{
  if (chkUsePrefixSuffix->Checked)
    IpRasDialer->ExtendedDialOptions << edoUsePrefixSuffix;
  else
    IpRasDialer->ExtendedDialOptions >> edoUsePrefixSuffix;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::chkPausedStatesClick(TObject *Sender)
{
  if (chkPausedStates->Checked)
    IpRasDialer->ExtendedDialOptions << edoAllowPausedStates;
  else
    IpRasDialer->ExtendedDialOptions >> edoAllowPausedStates;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::chkIgnoreModemSpeakerClick(TObject *Sender)
{
  if (chkIgnoreModemSpeaker->Checked)
    IpRasDialer->ExtendedDialOptions << edoIgnoreModemSpeaker;
  else
    IpRasDialer->ExtendedDialOptions >> edoIgnoreModemSpeaker;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::chkSetModemSpeakerClick(TObject *Sender)
{
  if (chkSetModemSpeaker->Checked)
    IpRasDialer->ExtendedDialOptions << edoSetModemSpeaker;
  else
    IpRasDialer->ExtendedDialOptions >> edoSetModemSpeaker;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::chkIgnoreSWCompressionClick(TObject *Sender)
{
  if (chkIgnoreSWCompression->Checked)
    IpRasDialer->ExtendedDialOptions << edoIgnoreSWCompression;
  else
    IpRasDialer->ExtendedDialOptions >> edoIgnoreSWCompression;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::chkSetSWCompressionClick(TObject *Sender)
{
  if (chkSetSWCompression->Checked)
    IpRasDialer->ExtendedDialOptions << edoSetSWCompression;
  else
    IpRasDialer->ExtendedDialOptions >> edoSetSWCompression;
}
//---------------------------------------------------------------------------

