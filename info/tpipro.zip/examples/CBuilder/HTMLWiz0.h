//---------------------------------------------------------------------------
#ifndef HTMLWiz0H
#define HTMLWiz0H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpBroker.hpp"
#include "IpHtml.hpp"
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TIpHtmlPanel *IpHtmlPanel1;
        void __fastcall IpHtmlPanel1ControlClick(
          TIpHtmlCustomPanel *Sender, TIpHtmlFrame *Frame, TIpHtml *Html,
          TIpHtmlNodeControl *Node);
        void __fastcall IpHtmlPanel1ControlCreate(
          TIpHtmlCustomPanel *Sender, TIpHtmlFrame *Frame, TIpHtml *Html,
          TIpHtmlNodeControl *Node);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);

  TIpFileDataProvider* HtmlFile;
  /* The settings controlled by the wizard */
  Boolean TriggerActivated;
  Boolean TimeWithSource;
  Boolean TimeWithoutSource;
  Boolean TimeExternals;
  Boolean ExcludeLeaves;
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
