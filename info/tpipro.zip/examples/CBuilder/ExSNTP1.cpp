// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ExSNTP1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpSock"
#pragma link "IpTime"
#pragma link "IpUtils"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
  edtURL->Text = IpSNTPClient1->Server;
  edtPollInterval->Text = IntToStr(IpSNTPClient1->PollInterval);
  edtSyncThreshold->Text = IntToStr(IpSNTPClient1->SyncThreshold);
  cbxBroadcastMode->ItemIndex = (int)IpSNTPClient1->BroadcastMode;
  cbxLocalHostDropDown(0);
  cbxLocalHost->ItemIndex = IpSNTPClient1->DefaultLocalAddress;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::edtPollIntervalExit(TObject *Sender)
{
  IpSNTPClient1->PollInterval = StrToIntDef(edtPollInterval->Text, 0);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
  StatusBar1->Panels->Items[0]->Text = DateTimeToStr(Now());
}
//---------------------------------------------------------------------------
void __fastcall TForm1::edtSyncThresholdExit(TObject *Sender)
{
  IpSNTPClient1->SyncThreshold = StrToIntDef(edtSyncThreshold->Text, 0);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::btnPollClick(TObject *Sender)
{
  IpSNTPClient1->Server = edtURL->Text;
  IpSNTPClient1->Poll();
  Application->ProcessMessages();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::cbxLocalHostDropDown(TObject *Sender)
{
  cbxLocalHost->Items->BeginUpdate();
  cbxLocalHost->Items->Clear();
  for (int i = 0; i < IpSNTPClient1->HostAddressCount; i++)
    cbxLocalHost->Items->Add(IpSNTPClient1->HostAddress[i]);
  cbxLocalHost->Items->EndUpdate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::cbxLocalHostChange(TObject *Sender)
{
  IpSNTPClient1->DefaultLocalAddress = cbxLocalHost->ItemIndex;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpSNTPClient1SNTPTime(TObject *Sender,
      TDateTime TimeStamp, double LocalOffset, double RoundTripDelay,
      BYTE Stratum, bool Synchronized)
{
  unsigned short Year, Month, Day, Hour, Min, Sec, MSec;
  DecodeDate(TimeStamp, Year, Month, Day);
  DecodeTime(TimeStamp, Hour, Min, Sec, MSec);
  edtYear->Text   = Year;
  edtMonth->Text  = Month;
  edtDay->Text    = Day;
  edtHour->Text   = Hour;
  edtMinute->Text = Min;
  edtSecond->Text = Sec;
  edtMillisecond->Text = MSec;
  edtOffset->Text = LocalOffset;
  edtDelay->Text  = RoundTripDelay;
  if (Synchronized)
    Caption = "Local clock synchronized to ";
  else
    Caption = "";
  Caption = "Stratum " + IntToStr(Stratum);
}
//---------------------------------------------------------------------------
