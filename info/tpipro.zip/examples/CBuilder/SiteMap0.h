//---------------------------------------------------------------------------
#ifndef SiteMap0H
#define SiteMap0H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpBroker.hpp"
#include "IpCache.hpp"
#include "IpHtml.hpp"
#include "IpHttp.hpp"
#include "IpSock.hpp"
#include "IpUtils.hpp"
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TLabel *Label1;
        TLabel *Label2;
        TEdit *Edit1;
        TButton *Button1;
        TButton *Button2;
        TTreeView *TreeView1;
        TIpHtmlDataProvider *IpHTMLDataProvider1;
        TIpHttpClient *IpHttpClient1;
        TIpCache *IpCache1;
        void __fastcall IpHTMLDataProvider1CheckURL(TObject *Sender,
          const AnsiString URL, bool &Available, AnsiString &ContentType);
        void __fastcall IpHTMLDataProvider1GetHtml(TObject *Sender,
          const AnsiString URL, const TIpFormDataEntity *PostData,
          TStream *&Stream);
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall IpHttpClient1GotItem(TObject *Sender, DWORD Socket,
          const AnsiString Item, bool Cached);
        void __fastcall IpHttpClient1Disconnect(TObject *Sender,
          DWORD Socket);
        void __fastcall TreeView1DblClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
  Boolean WaitingForReply;
  Boolean HaveReply;
  Boolean Cancelled;
  TStringList* LinkList;
  TStringList* VisitedLinks;
  TIpHtmlScanner* IpHTMLScanner1;
  void __fastcall WalkLinks(TTreeNode  *N,
                      const AnsiString Root,
                      const AnsiString Host);
  void __fastcall ListNodes(TIpHtmlNode *Node);
  void __fastcall BuildList(TIpHtml* H);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
