//---------------------------------------------------------------------------
#ifndef ImSelectH
#define ImSelectH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TfrmSelectForSend : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel1;
    TButton *btnOK;
    TButton *btnCancel;
    TListBox *lbSelect;
    void __fastcall btnOKClick(TObject *Sender);
    void __fastcall lbSelectDblClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TfrmSelectForSend(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmSelectForSend *frmSelectForSend;
//---------------------------------------------------------------------------
#endif
