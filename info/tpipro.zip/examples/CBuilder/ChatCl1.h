//---------------------------------------------------------------------------
#ifndef ChatCl1H
#define ChatCl1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpSock.hpp"
#include "IpUtils.hpp"
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>
#include <Menus.hpp>

#define MAXCONNECTIONS 10
#define HELLO          1
#define TALK           2
#define USERS          3 
#define PRIVT          4

struct UserInfo{
  DWORD      Socket  ;
  AnsiString UserName;
};  

//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TBevel *Bevel1;
    TLabel *Label1;
    TButton *Client1Send;
    TEdit *Client1Edt;
    TButton *Client1Con;
    TEdit *Client1Edt2;
    TButton *Client1Disconnect;
    TEdit *UserEdit1;
    TIpClient *IpClient1;
    TListBox *Client1LstBx;
    TCheckBox *ShhChkBox;
    TListBox *Cllient1List;
    TButton *ExitBtn;
    TCheckBox *NotifyChkBx;
    TLabel *ConnectLbl;
    void __fastcall Client1ConClick(TObject *Sender);
    void __fastcall IpClient1Status(TObject *Sender, DWORD Socket,
          TIpStatusType Event, const TIpConnRec &Connection,
          const TIpSockStatRec &StatRec);
    void __fastcall IpClient1Error(TObject *Sender, DWORD Socket,
          int ErrCode, const AnsiString ErrStr);
    void __fastcall IpClient1ReadLine(TObject *Sender, DWORD Socket,
          const AnsiString Line);
    void __fastcall Client1DisconnectClick(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall Client1SendClick(TObject *Sender);
    void __fastcall Client1EdtKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
    
    void __fastcall Client1Edt2KeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
    
    
    void __fastcall Cllient1ListDrawItem(TWinControl *Control, int Index,
          TRect &Rect, TOwnerDrawState State);
    void __fastcall ShhChkBoxClick(TObject *Sender);
    void __fastcall ExitBtnClick(TObject *Sender);
    
    
    
private:	// User declarations
    AnsiString Server_str1;
    void __fastcall AddString( const AnsiString Line );

public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
