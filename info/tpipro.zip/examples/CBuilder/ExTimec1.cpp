// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ExTimec1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpSock"
#pragma link "IpTime"
#pragma link "IpUtils"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnPollClick(TObject *Sender)
{
  IpTimeClient1->Server = edtServer->Text;
  IpTimeClient1->Poll();
  Application->ProcessMessages();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
  edtServer->Text = IpTimeClient1->Server;
  rgTimeService->ItemIndex = (int)IpTimeClient1->TimeService;
  rgProtocol->ItemIndex = (int)IpTimeClient1->SockProtocol;
  edtPollInterval->Text = IpTimeClient1->PollInterval;
  cbxLocalHostDropDown(0);
  cbxLocalHost->ItemIndex = IpTimeClient1->DefaultLocalAddress;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::rgTimeServiceClick(TObject *Sender)
{
  IpTimeClient1->TimeService = (TIpTimeService)rgTimeService->ItemIndex;
  rgTimeService->ItemIndex = (int)IpTimeClient1->TimeService;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::rgProtocolClick(TObject *Sender)
{
  IpTimeClient1->SockProtocol = (TIpSockProtocol)rgProtocol->ItemIndex;
  rgProtocol->ItemIndex = (int)IpTimeClient1->SockProtocol;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::edtPollIntervalExit(TObject *Sender)
{
  IpTimeClient1->PollInterval = StrToIntDef(edtPollInterval->Text, 0);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpTimeClient1Time(TObject *Sender, TDateTime TimeStamp)
{
  StatusBar1->Panels->Items[0]->Text = DateTimeToStr(TimeStamp) + " UTC";
}
//---------------------------------------------------------------------------
void __fastcall TForm1::cbxLocalHostDropDown(TObject *Sender)
{
  cbxLocalHost->Items->BeginUpdate();
  cbxLocalHost->Items->Clear();
  for (int i = 0; i < IpTimeClient1->HostAddressCount; i++)
    cbxLocalHost->Items->Add(IpTimeClient1->HostAddress[i]);
  cbxLocalHost->Items->EndUpdate();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::cbxLocalHostChange(TObject *Sender)
{
  IpTimeClient1->DefaultLocalAddress = cbxLocalHost->ItemIndex;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::IpTimeClient1Daytime(TObject *Sender,
      const AnsiString TimeStamp)
{
  StatusBar1->Panels->Items[0]->Text = TimeStamp;
}
//---------------------------------------------------------------------------

