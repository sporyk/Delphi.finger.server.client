//---------------------------------------------------------------------------
#ifndef ExTrace0H
#define ExTrace0H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpIcmp.hpp"
#include "IpSock.hpp"
#include "IpUtils.hpp"
//---------------------------------------------------------------------------
class TfrmExTrace : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TEdit *edtTraceAddress;
    TButton *btnTrace;
    TListBox *lbxTrace;
    TIpIcmp *IpIcmp1;
    void __fastcall btnTraceClick(TObject *Sender);
    void __fastcall IpIcmp1TraceComplete(TIpCustomIcmp *Icmp,
          const TStringList *TraceList);
    void __fastcall lbxTraceDrawItem(TWinControl *Control, int Index,
          TRect &Rect, TOwnerDrawState State);
    void __fastcall IpIcmp1IcmpEcho(TIpCustomIcmp *Icmp,
          const TIpExtendedEchoInfo *EchoInfo, const AnsiString EchoFrom);
private:	// User declarations
public:		// User declarations
    __fastcall TfrmExTrace(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmExTrace *frmExTrace;
//---------------------------------------------------------------------------
#endif
