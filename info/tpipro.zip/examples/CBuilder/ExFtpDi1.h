//---------------------------------------------------------------------------
#ifndef ExFtpDi1H
#define ExFtpDi1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpFtp.hpp"
#include "IpSock.hpp"
#include "IpUtils.hpp"
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label14;
    TButton *btnLogin;
    TButton *btnLogout;
    TEdit *edtURL;
    TEdit *edtUserName;
    TEdit *edtPassword;
    TGroupBox *GroupBox1;
    TIpFtpDirectoryTree *IpFtpDirectoryTree1;
    TListBox *lbxRemoteFiles;
    TGroupBox *gbxFiles;
    TLabel *Label4;
    TLabel *Label5;
    TLabel *Label6;
    TLabel *Label7;
    TLabel *Label8;
    TLabel *Label9;
    TLabel *Label10;
    TLabel *lblLinkPath;
    TLabel *OwnerLbl;
    TLabel *GroupLbl;
    TLabel *SizeLbl;
    TLabel *TimeLbl;
    TLabel *TypeLbl;
    TLabel *Label11;
    TLabel *Label12;
    TLabel *Label13;
    TLabel *PermOwnerLbl;
    TLabel *PermGroupLbl;
    TLabel *PermOtherLbl;
    TComboBox *cbxDirectoryStyle;
    TStatusBar *StatusBar1;
    TIpFtpClient *IpFtpClient1;
    void __fastcall btnLoginClick(TObject *Sender);
    void __fastcall btnLogoutClick(TObject *Sender);
    void __fastcall IpFtpDirectoryTree1Change(TObject *Sender,
          TTreeNode *Node);
    void __fastcall IpFtpDirectoryTree1Changed(TObject *Sender);
    void __fastcall lbxRemoteFilesMouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall cbxDirectoryStyleChange(TObject *Sender);
    void __fastcall IpFtpClient1FtpError(TObject *Sender, int ErrorCode,
          const AnsiString ErrorText);
    
    void __fastcall IpFtpClient1FtpStatus(TObject *Sender,
          TIpFtpStatusCode StatusCode, const AnsiString Info);
    void __fastcall StatusBar1DblClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
