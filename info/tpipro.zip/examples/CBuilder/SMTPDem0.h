//---------------------------------------------------------------------------
#ifndef SMTPDem0H
#define SMTPDem0H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpMsg.hpp"
#include "IpSmtp.hpp"
#include "IpSock.hpp"
#include "IpUtils.hpp"
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TfrmSMTPDemo : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label9;
    TButton *btnSendMail;
    TStatusBar *StatusBar1;
    TGroupBox *GroupBox1;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label6;
    TLabel *Label7;
    TLabel *Label8;
    TEdit *edtMailFrom;
    TEdit *edtMailCC;
    TMemo *memMessage;
    TEdit *edtSubject;
    TEdit *edtMailBCC;
    TComboBox *edtMailTo;
    TComboBox *cbxAttachments;
    TButton *btnBrowseAttachment;
    TGroupBox *GroupBox2;
    TLabel *Label5;
    TLabel *Label10;
    TLabel *Label11;
    TEdit *edtSMTPAddress;
    TEdit *edtUserID;
    TEdit *edtDomain;
    TCheckBox *cbxCloseOnComplete;
    TListBox *ListBox1;
    TOpenDialog *OpenDialog1;
    TIpSmtpClient *IpSmtpClient1;
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall IpSmtpClient1ConnectError(TIpCustomSmtpClient *Client,
          int ErrCode, const AnsiString ErrStr);
    void __fastcall IpSmtpClient1Progress(TIpCustomSmtpClient *Client,
          DWORD CharsTransferred);
    void __fastcall IpSmtpClient1Response(TIpCustomSmtpClient *Client,
          TIpSmtpStates ResponseTo, int Code, const AnsiString Response);
    void __fastcall IpSmtpClient1StateChange(TIpCustomSmtpClient *Client,
          TIpSmtpStates State);
    void __fastcall IpSmtpClient1TaskComplete(TIpCustomSmtpClient *Client,
          TIpSmtpTasks Task);
    void __fastcall btnSendMailClick(TObject *Sender);
    void __fastcall edtMailToKeyPress(TObject *Sender, char &Key);
    void __fastcall cbxAttachmentsKeyPress(TObject *Sender, char &Key);
    void __fastcall btnBrowseAttachmentClick(TObject *Sender);
private:	// User declarations
    void Add(AnsiString S);
public:		// User declarations
    __fastcall TfrmSMTPDemo(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmSMTPDemo *frmSMTPDemo;
//---------------------------------------------------------------------------
#endif
