// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "SmplCS1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpSock"
#pragma link "IpUtils"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpServer1ReadLine(TObject *Sender, DWORD Socket,
      const AnsiString Line)
{
  ListBox1->Items->Add( Line );
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpClient1ReadLine(TObject *Sender, DWORD Socket,
      const AnsiString Line)
{
  ListBox2->Items->Add( Line );
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpServer1Status(TObject *Sender, DWORD Socket,
      TIpStatusType Event, const TIpConnRec &Connection,
      const TIpSockStatRec &StatRec)
{
  switch( Event ) {
    case stConnect :
      Label1->Caption        = "Client connected " + IntToStr( Socket );
      SrvSock                = Socket;
      ClientSndBtn->Enabled  = true;
      ServerSndBtn->Enabled  = true;
      DisConnectBtn->Enabled = true;
      ConnectBtn->Enabled    = false;
    break;
    case stDisconnect :
      Label1->Caption        = "Client Disconnected";
      SrvSock                = Invalid_Socket;
      ClientSndBtn->Enabled  = false;
      ServerSndBtn->Enabled  = false;
      DisConnectBtn->Enabled = false;
      ConnectBtn->Enabled    = true;

      ListBox1->Clear();
      ListBox2->Clear();
      ServerBytesRecvLbl->Caption = "Bytes Recv ";
      ServerBytesSentLbl->Caption = "Bytes Sent ";
      ClientBytesRecvLbl->Caption = "Bytes Recv ";
      ClientBytesSentLbl->Caption = "Bytes Sent ";
    break;
    case stProgress :
      ServerBytesRecvLbl->Caption = "Bytes Recv " + IntToStr( StatRec.TotalBytesRcvd );
      ServerBytesSentLbl->Caption = "Bytes Sent " + IntToStr( StatRec.TotalBytesSent );
    break;
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ConnectBtnClick(TObject *Sender)
{
  IpClient1->ConnectSocket( "127.0.0.1:6669" );
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ClientSndBtnClick(TObject *Sender)
{
  String tmp_str;
  tmp_str = ClientEdt->Text + "\r\n";
  IpClient1->PutString( tmp_str, False);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ServerSndBtnClick(TObject *Sender)
{
  String tmp_str;
  tmp_str = ServerEdt->Text + "\r\n";
  IpServer1->PutString( SrvSock, tmp_str, false );
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DisConnectBtnClick(TObject *Sender)
{
  IpClient1->CloseSocket();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpClient1Status(TObject *Sender, DWORD Socket,
      TIpStatusType Event, const TIpConnRec &Connection,
      const TIpSockStatRec &StatRec)
{
  switch( Event ) {
    case stConnect :
    break;
    case stDisconnect :
    break;
    case stProgress :
      ClientBytesRecvLbl->Caption = "Bytes Recv " + IntToStr( StatRec.BytesRcvd );
      ClientBytesSentLbl->Caption = "Bytes Sent " + IntToStr( StatRec.BytesSent );
    break;
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
  IpClient1->CloseSocket();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
  SrvSock = Invalid_Socket;
}
//---------------------------------------------------------------------------

