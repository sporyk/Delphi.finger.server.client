//---------------------------------------------------------------------------
#ifndef hdrgtr0H
#define hdrgtr0H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpHttp.hpp"
#include "IpSock.hpp"
#include "IpUtils.hpp"
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TEdit *Edit1;
        TButton *btnHead;
        TMemo *Memo1;
        TButton *btnGet;
        TButton *Button1;
        TButton *Button3;
        TSaveDialog *SaveDialog1;
        TIpHttpClient *HTTP;
        void __fastcall btnHeadClick(TObject *Sender);
        void __fastcall btnGetClick(TObject *Sender);
        void __fastcall HTTPDisconnect(TObject *Sender, DWORD Socket);
        void __fastcall HTTPHttpResult(TObject *Sender, DWORD Socket,
          AnsiString Code, AnsiString Message, TStream *HeaderDat);
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall Button3Click(TObject *Sender);
        void __fastcall Memo1DblClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);

        Boolean GotReply;
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
