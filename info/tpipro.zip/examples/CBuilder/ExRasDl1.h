//---------------------------------------------------------------------------
#ifndef ExRasDl1H
#define ExRasDl1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpRas.hpp"
#include "IpUtils.hpp"
#include <Buttons.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TSpeedButton *btnPhonebook;
    TEdit *edtPhonebook;
    TRadioGroup *rgRasDialogs;
    TButton *btnExecute;
    TIpRasDialog *IpRasDialog1;
    TOpenDialog *OpenDialog1;
    void __fastcall btnPhonebookClick(TObject *Sender);
    void __fastcall btnExecuteClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
