//---------------------------------------------------------------------------
#ifndef ImHelpH
#define ImHelpH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <ShellAPI.hpp>
//---------------------------------------------------------------------------
class TfrmHelp : public TForm
{
__published:	// IDE-managed Components
    TImage *Image1;
    TLabel *Label1;
    TButton *btnOK;
    TGroupBox *GroupBox1;
    TLabel *Label2;
    TLabel *Label4;
    TLabel *Label6;
    TGroupBox *GroupBox2;
    TLabel *Label3;
    TLabel *Label5;
    TLabel *Label7;
    void __fastcall Label6MouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
    void __fastcall GroupBox1MouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
    void __fastcall Label7MouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
    void __fastcall GroupBox2MouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
    void __fastcall Label6Click(TObject *Sender);
    void __fastcall Label7Click(TObject *Sender);
    void __fastcall FormMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
private:	// User declarations
public:		// User declarations
    __fastcall TfrmHelp(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmHelp *frmHelp;
//---------------------------------------------------------------------------
#endif
