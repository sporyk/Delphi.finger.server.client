//---------------------------------------------------------------------------
#ifndef NNTPDem1H
#define NNTPDem1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
#include "IpMsg.hpp"
#include <ComCtrls.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TfrmArticle : public TForm
{
__published:	// IDE-managed Components
    TButton *btnPost;
    TButton *btnCancel;
    TMemo *memBody;
    TGroupBox *GroupBox1;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label5;
    TLabel *Label6;
    TEdit *edtSender;
    TEdit *edtReplyTo;
    TEdit *edtNewsgroup;
    TEdit *edtSubject;
    TEdit *edtPath;
    TEdit *edtPostingHost;
    TButton *btnSave;
    TButton *btnLoad;
    TOpenDialog *OpenDialog1;
    TSaveDialog *SaveDialog1;
    TTreeView *tvMimeParts;
    TPopupMenu *PopupMenu1;
    TMenuItem *Add1;
    TMenuItem *Extract1;
    TMenuItem *Delete1;
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall btnSaveClick(TObject *Sender);
    void __fastcall btnLoadClick(TObject *Sender);
    void __fastcall Add1Click(TObject *Sender);
    void __fastcall Extract1Click(TObject *Sender);
    void __fastcall Delete1Click(TObject *Sender);
private:	// User declarations
    void __fastcall AddNestedBlock(TIpMimeEntity* Blk, TTreeNode* ParentNode);
    void __fastcall PopulateMimePartsTree(void);

public:		// User declarations
    __fastcall TfrmArticle(TComponent* Owner);
    TIpNewsArticle *Article;
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmArticle *frmArticle;
//---------------------------------------------------------------------------
#endif
