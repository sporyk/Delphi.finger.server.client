//---------------------------------------------------------------------------
#ifndef ImOptsH
#define ImOptsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Mask.hpp>
#include <ShellAPI.hpp>
#include "IpIM.hpp"
//---------------------------------------------------------------------------
class TfrmOptions : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel1;
    TButton *btnOK;
    TButton *btnCancel;
    TPageControl *PageControl1;
    TTabSheet *TabSheet1;
    TTabSheet *TabSheet2;
    TBevel *Bevel1;
    TLabel *lblStatus;
    TEdit *edtSignInName;
    TMaskEdit *edtPassword;
    TLabel *Label2;
    TLabel *Label1;
    TLabel *Label3;
    TLabel *Label4;
    TButton *btnMSNSignUp;
    TButton *btnAOLSignup;
    TLabel *Label5;
    TLabel *Label6;
    TBevel *Bevel2;
    TEdit *edtServerPort;
    TEdit *edtServerAddress;
    TCheckBox *cbUseProxy;
    TLabel *lblProxyType;
    TLabel *lblProxyServer;
    TLabel *lblProxyPort;
    TLabel *lblProxyUserID;
    TLabel *lblProxyPassword;
    TMaskEdit *edtProxyPassword;
    TEdit *edtUserID;
    TEdit *edtPort;
    TEdit *edtServer;
    TComboBox *cbProxyType;
    void __fastcall cbUseProxyClick(TObject *Sender);
    void __fastcall btnMSNSignUpClick(TObject *Sender);
    void __fastcall btnAOLSignupClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    void EnableProxyEdits(void);
    void DisableProxyEdits(void);
    void FillProxyEdits(TIpIMClient* Client);
    __fastcall TfrmOptions(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmOptions *frmOptions;
//---------------------------------------------------------------------------
#endif
