//---------------------------------------------------------------------------
#ifndef ExBrowPrH
#define ExBrowPrH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "CGRID.h"
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <Tabnotbk.hpp>
#include "IpHtml.hpp"
//---------------------------------------------------------------------------
class TfrmBrowConfig : public TForm
{
__published:	// IDE-managed Components
  TTabbedNotebook *TabbedNotebook1;
  TLabel *Label1;
  TLabel *Label6;
  TLabel *Label7;
  TEdit *Edit1;
  TEdit *Edit6;
  TButton *Button1;
  TEdit *Edit7;
  TCheckBox *CheckBox1;
  TButton *Button2;
  TButton *Button3;
  TOpenDialog *OpenDialog1;
  TLabel *Label2;
  TLabel *Label3;
  TLabel *Label4;
  TLabel *Label5;
  TEdit *Edit2;
  TEdit *Edit3;
  TEdit *Edit4;
  TEdit *Edit5;
  TButton *Button4;
  TColorDialog *ColorDialog1;
  TPanel *Panel1;
  void __fastcall EdEnter(TObject *Sender);
  void __fastcall Button1Click(TObject *Sender);
  void __fastcall FormShow(TObject *Sender);
  void __fastcall TabbedNotebook1Change(TObject *Sender, int NewTab,
          bool &AllowChange);
  void __fastcall Button4Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
  TEdit* CurEd;
  Boolean InColors;
  __fastcall TfrmBrowConfig(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmBrowConfig *frmBrowConfig;
//---------------------------------------------------------------------------
#endif
