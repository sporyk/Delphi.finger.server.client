// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "NNTPDem1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmArticle *frmArticle;
//---------------------------------------------------------------------------
__fastcall TfrmArticle::TfrmArticle(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmArticle::FormCreate(TObject *Sender)
{
  Article = new TIpNewsArticle();
}
//---------------------------------------------------------------------------
void __fastcall TfrmArticle::FormShow(TObject *Sender)
{
  String S = Article->Path->Text;
  for (int I=1; I<S.Length(); I++){
    if (S[I] == '\r')
      S[I] = ';';
    if (S[I] == '\n')
      S[I] = ' ';
  }
  S = S.SubString(1, S.Length() - 2);
  edtPath->Text = S;
  edtPostingHost->Text = Article->NNTPPostingHost;
  S = Article->Newsgroups->Text;
  for (int I=1; I<S.Length(); I++){
    if (S[I] == '\r')
      S[I] = ';';
    if (S[I] == '\n')
      S[I] = ' ';
  }
  S = S.SubString(1, S.Length() - 2);
  edtNewsgroup->Text = S;
  edtSubject->Text = Article->Subject;
  edtSender->Text = Article->Sender;
  if (Article->Sender == "")
    edtSender->Text = Article->From;
  edtReplyTo->Text = Article->ReplyTo;

  TIpMimeEntity* MimeBlk = Article->GetBodyPlain(false);
  if (MimeBlk)
    MimeBlk->ExtractBodyStrings(memBody->Lines);
  else
    Article->ExtractBodyStrings(memBody->Lines);
  PopulateMimePartsTree();
}
//---------------------------------------------------------------------------
void __fastcall TfrmArticle::FormClose(TObject *Sender,
      TCloseAction &Action)
{
  if (ModalResult == mrOk){
    Article->Path->Clear();
    Article->Path->Add(edtPath->Text);
    Article->NNTPPostingHost = edtPostingHost->Text;
    Article->Subject = edtSubject->Text;
    Article->Sender = edtSender->Text;
    Article->ReplyTo = edtReplyTo->Text;
    Article->Newsgroups->Clear();
    Article->Newsgroups->Add(edtNewsgroup->Text);
    Article->EncodeBodyStrings(memBody->Lines, "");
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmArticle::btnSaveClick(TObject *Sender)
{
  if (SaveDialog1->Execute())
    Article->SaveToFile(SaveDialog1->FileName);
}
//---------------------------------------------------------------------------
void __fastcall TfrmArticle::btnLoadClick(TObject *Sender)
{
  if (OpenDialog1->Execute()){
    Article->LoadFromFile(OpenDialog1->FileName);
    FormShow(0);
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmArticle::AddNestedBlock(TIpMimeEntity* Blk,
      TTreeNode* ParentNode)
{
  TTreeNode* Node;
  if (!(Blk->FileName == ""))
    Node = tvMimeParts->Items->AddChild(ParentNode, Blk->FileName);
  else
    Node = tvMimeParts->Items->AddChild(ParentNode, Blk->ContentType + "/" +
      Blk->ContentSubtype);
  Node->Data = (Pointer) Blk;
  if (Blk->MimeParts->Count > 0)
  for (int j = 0; j < Blk->MimeParts->Count; j++)
    AddNestedBlock(Blk->MimeParts->Parts[j], Node);
  Node->Expanded = true;
}
//---------------------------------------------------------------------------
void __fastcall TfrmArticle::PopulateMimePartsTree(void)
{
  tvMimeParts->Items->Clear();
  if (Article->IsMime) {
    TTreeNode* RootNode = tvMimeParts->Items->AddChild(0, Article->ContentType
      + "/" + Article->ContentSubtype);
    RootNode->Data = (Pointer) Article;
    if (Article->MimeParts->Count > 0)
      for (int i = 0; i < Article->MimeParts->Count; i++)
        AddNestedBlock(Article->MimeParts->Parts[i], RootNode);
    RootNode->Expanded = true;
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmArticle::Add1Click(TObject *Sender)
{
  if (OpenDialog1->Execute()) {
    Article->NewMimePart()->EncodeBodyFile(OpenDialog1->FileName);
    PopulateMimePartsTree();
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmArticle::Extract1Click(TObject *Sender)
{
  if (tvMimeParts->Selected) {
    TIpMimeEntity* Blk = (TIpMimeEntity*) tvMimeParts->Selected->Data;
    SaveDialog1->FileName = Blk->FileName;
    if (SaveDialog1->Execute())
      Blk->ExtractBodyFile(SaveDialog1->FileName);
    SaveDialog1->FileName = "";
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmArticle::Delete1Click(TObject *Sender)
{
  if (tvMimeParts->Selected) {
    delete ((TIpMimeEntity*) tvMimeParts->Selected->Data);
    PopulateMimePartsTree();
  }
}
//---------------------------------------------------------------------------

