//---------------------------------------------------------------------------
#ifndef ExTimeD1H
#define ExTimeD1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpSock.hpp"
#include "IpTime.hpp"
#include "IpUtils.hpp"
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TStatusBar *StatusBar1;
    TRadioGroup *rgTimeService;
    TRadioGroup *rgProtocol;
    TEdit *edtFormat;
    TTimer *Timer1;
    TGroupBox *gbxLocalHost;
    TComboBox *cbxLocalHost;
    TCheckBox *chkActive;
    TIpTimeServer *IpTimeServer1;
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall rgTimeServiceClick(TObject *Sender);
    void __fastcall IpTimeServer1Time(TObject *Sender, TDateTime &Time);
    void __fastcall Timer1Timer(TObject *Sender);
    void __fastcall rgProtocolClick(TObject *Sender);
    void __fastcall chkActiveClick(TObject *Sender);
    void __fastcall cbxLocalHostDropDown(TObject *Sender);
    void __fastcall cbxLocalHostChange(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
