// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "SMTPDem0.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpMsg"
#pragma link "IpSmtp"
#pragma link "IpSock"
#pragma link "IpUtils"
#pragma resource "*.dfm"
TfrmSMTPDemo *frmSMTPDemo;
//---------------------------------------------------------------------------
__fastcall TfrmSMTPDemo::TfrmSMTPDemo(TComponent* Owner)
    : TForm(Owner)
{
}
void TfrmSMTPDemo::Add(AnsiString S)
{
  StatusBar1->SimpleText = S;
  ListBox1->Items->Add(S);
  ListBox1->ItemIndex = ListBox1->Items->Count - 1;
}
//---------------------------------------------------------------------------

void __fastcall TfrmSMTPDemo::FormCreate(TObject *Sender)
{
  edtSMTPAddress->Text = "";
  edtUserID->Text = IpSmtpClient1->UserID;
  edtDomain->Text = IpSmtpClient1->Domain;
}
//---------------------------------------------------------------------------

void __fastcall TfrmSMTPDemo::IpSmtpClient1ConnectError(
      TIpCustomSmtpClient *Client, int ErrCode, const AnsiString ErrStr)
{
  Add("OnError: " + IntToStr(ErrCode));
  Add("         " + ErrStr);             
}
//---------------------------------------------------------------------------
void __fastcall TfrmSMTPDemo::IpSmtpClient1Progress(
      TIpCustomSmtpClient *Client, DWORD CharsTransferred)
{
  WORD Percent = ((float)(CharsTransferred / IpSmtpClient1->Message->Size) * 100);
  Add(Format("Sending message (%d )", ARRAYOFCONST(((int)Percent))));
}
//---------------------------------------------------------------------------
void __fastcall TfrmSMTPDemo::IpSmtpClient1Response(
      TIpCustomSmtpClient *Client, TIpSmtpStates ResponseTo, int Code,
      const AnsiString Response)
{
  Add("Response: Code=" + IntToStr(Code) + "; Text=" + Response);
  if (ResponseTo == ssNoOp)
    Add("Message sent");
  // handle errors by showing the response text and a description of what
  // we were doing at the time
  if (Code > 399)
    ShowMessage(Response + "\r\n while " + IpSmtpClient1->StateToStr(ResponseTo));
}
//---------------------------------------------------------------------------
void __fastcall TfrmSMTPDemo::IpSmtpClient1StateChange(
      TIpCustomSmtpClient *Client, TIpSmtpStates State)
{
  Add("State change: " + IpSmtpClient1->StateToStr(State));    
}
//---------------------------------------------------------------------------
void __fastcall TfrmSMTPDemo::IpSmtpClient1TaskComplete(
      TIpCustomSmtpClient *Client, TIpSmtpTasks Task)
{
  if (Task == stSendMail)
    Add("Sending mail");
  else if (Task == stNoTask)
    Add("Done sending mail");
}
//---------------------------------------------------------------------------
void __fastcall TfrmSMTPDemo::btnSendMailClick(TObject *Sender)
{
  IpSmtpClient1->UserID = edtUserID->Text;
  IpSmtpClient1->Domain = edtDomain->Text;

  Add("Preparing message");
  // make sure we are dealing with a clean message
  IpSmtpClient1->Message->NewMessage();
  IpSmtpClient1->Message->Subject = edtSubject->Text;
  IpSmtpClient1->Message->From = edtMailFrom->Text;
  if (edtMailTo->Items->Count > 0)
    IpSmtpClient1->Message->MailTo->Assign(edtMailTo->Items);
  else
    IpSmtpClient1->Message->MailTo->Add(edtMailTo->Text);
  if (edtMailCC->Text.Length() > 0)
    IpSmtpClient1->Message->CC->Add(edtMailCC->Text);
  if (edtMailBCC->Text.Length() > 0)
    IpSmtpClient1->Message->BCC->Add(edtMailBCC->Text);

  IpSmtpClient1->Message->UserFields->Add("X-IPro: Just to show that we "
    "can add extra tags to the header");


  // If there are no attachments, message is not mime.
  // Just place memo text in message body.
  if (cbxAttachments->Items->Count == 0)
    IpSmtpClient1->Message->EncodeBodyStrings(memMessage->Lines, "");
  else {

    // Otherwise, add the memo text as a plain/text mime part }
    TIpMimeEntity* MimePart = IpSmtpClient1->Message->GetBodyPlain(true);
    MimePart->EncodeBodyStrings(memMessage->Lines, "");
    IpSmtpClient1->Message->ContentType = "multipart";
    IpSmtpClient1->Message->ContentSubtype = "mixed";

    // place mime disclaimer text in message body
    TStringList* Disclaimer = new TStringList();
    try {
      Disclaimer->Add("This message is in MIME format. Since your mail reader does not");
      Disclaimer->Add("understand this format, some or all of this message may not be legible.");
      IpSmtpClient1->Message->EncodeBodyStrings(Disclaimer, "");
    }
    __finally {
      delete(Disclaimer);
    }

    // finally, add any file attachments
    IpSmtpClient1->AttachmentList->Assign(cbxAttachments->Items);
  }
  Add("Sending message");
  IpSmtpClient1->SendMail(edtSMTPAddress->Text, cbxCloseOnComplete->Checked);
}
//---------------------------------------------------------------------------
void __fastcall TfrmSMTPDemo::edtMailToKeyPress(TObject *Sender, char &Key)
{
  if (Key == '\r'){
    if (edtMailTo->Items->IndexOf(edtMailTo->Text) == -1)
      edtMailTo->Items->Add(edtMailTo->Text);
    edtMailTo->Text = "";
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmSMTPDemo::cbxAttachmentsKeyPress(TObject *Sender,
      char &Key)
{
  if (Key == '\r'){
    if (cbxAttachments->Items->IndexOf(cbxAttachments->Text) == -1)
      cbxAttachments->Items->Add(cbxAttachments->Text);
    cbxAttachments->Text = "";
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmSMTPDemo::btnBrowseAttachmentClick(TObject *Sender)
{
  if (OpenDialog1->Execute())
    cbxAttachments->Items->AddStrings(OpenDialog1->Files);
}
//---------------------------------------------------------------------------
