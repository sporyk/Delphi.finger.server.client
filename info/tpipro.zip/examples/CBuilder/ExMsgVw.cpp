// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ExMsgVw.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpBroker"
#pragma link "IpHtml"
#pragma link "IpUtils"
#pragma resource "*.dfm"
TfrmExMsgView *frmExMsgView;
TMemoryStream *MemStream;

//---------------------------------------------------------------------------
void __fastcall ViewMessage(TIpMailMessage* MsgToView)
{
  SmallString<8> HtmlTag = "<HTML>\r\n";
  SmallString<8> BodyTag = "<BODY>\r\n";
  SmallString<9> NotHtmlTag = "</HTML>\r\n";
  SmallString<9> NotBodyTag = "</BODY>\r\n";

  if (!MemStream)
    MemStream = new TMemoryStream();
  try {
    TfrmExMsgView* ViewForm = new TfrmExMsgView(0);
    try {
      TIpMimeEntity* MimeBlk = MsgToView->GetBodyHtml(false);
      if (MimeBlk) {
        ViewForm->Label6->Caption = "HTML message";
        MimeBlk->ExtractBodyStream(MemStream);
      }
      else {
        MimeBlk = MsgToView->GetBodyPlain(false);
        if (MimeBlk)                                             
          ViewForm->Label6->Caption = "Plain text message (MIME encoded)";
        else {
          MimeBlk = MsgToView;
          ViewForm->Label6->Caption = "Plain text message (no encoding)";
        }

        // bracket plain text with html tags for html panel
        MemStream->Write(&HtmlTag[1], HtmlTag[0]);
        MemStream->Write(&BodyTag[1], BodyTag[0]);
        MimeBlk->ExtractBodyStream(MemStream);
        MemStream->Write(&NotBodyTag[1], NotHtmlTag[0]);
        MemStream->Write(&NotHtmlTag[1], NotBodyTag[0]);
      }
      MemStream->Position = 0;

      // display message mime structure
      ViewForm->PopulateMimePartsTree(MsgToView);

      ViewForm->Caption = MsgToView->Subject;
      ViewForm->edtFrom->Text = MsgToView->From;
      ViewForm->edtTo->Text = MsgToView->MailTo->CommaText;
      ViewForm->edtCC->Text = MsgToView->CC->CommaText;
      ViewForm->edtSubject->Text = MsgToView->Subject;
      ViewForm->edtSent->Text = MsgToView->Date;
      ViewForm->IpHtmlPanel1->OpenURL(Application->ExeName);
      ViewForm->ShowModal();
    }
    __finally {
      delete (ViewForm);
    }
  }
  __finally {
  }
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
__fastcall TfrmExMsgView::TfrmExMsgView(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmExMsgView::IpHtmlDataProvider1CheckURL(TObject *Sender,
      const AnsiString URL, bool &Available, AnsiString &ContentType)
{
  Available = true;
  ContentType = "text/html";
}
//---------------------------------------------------------------------------
void __fastcall TfrmExMsgView::IpHtmlDataProvider1GetHtml(TObject *Sender,
      const AnsiString URL, const TIpFormDataEntity *PostData,
      TStream *&Stream)
{
  Stream = MemStream;
}
//---------------------------------------------------------------------------
void __fastcall TfrmExMsgView::AddNestedBlock(TIpMimeEntity* Blk,
      TTreeNode* ParentNode)
{
  TTreeNode* Node;
  if (!(Blk->FileName == ""))
    Node = tvMimeParts->Items->AddChild(ParentNode, Blk->FileName);
  else
    Node = tvMimeParts->Items->AddChild(ParentNode, Blk->ContentType + "/" +
      Blk->ContentSubtype);
  Node->Data = (Pointer) Blk;
  if (Blk->MimeParts->Count > 0)
  for (int j = 0; j < Blk->MimeParts->Count; j++)
    AddNestedBlock(Blk->MimeParts->Parts[j], Node);
  Node->Expanded = true;
}
//---------------------------------------------------------------------------
void __fastcall TfrmExMsgView::PopulateMimePartsTree(TIpMessage* MsgToView)
{
  tvMimeParts->Items->Clear();
  if (MsgToView->IsMime) {
    TTreeNode* RootNode = tvMimeParts->Items->AddChild(0, MsgToView->ContentType
      + "/" + MsgToView->ContentSubtype);
    RootNode->Data = (Pointer) MsgToView;
    if (MsgToView->MimeParts->Count > 0)
      for (int i = 0; i < MsgToView->MimeParts->Count; i++)
        AddNestedBlock(MsgToView->MimeParts->Parts[i], RootNode);
    RootNode->Expanded = true;
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmExMsgView::tvMimePartsDblClick(TObject *Sender)
{
  if (tvMimeParts->Selected) {
    TIpMimeEntity* MimeBlk = (TIpMimeEntity*) tvMimeParts->Selected->Data;
    try {
      if (!(MimeBlk->EntityName == ""))
        SaveDialog1->FileName = MimeBlk->EntityName;
      else if (!(MimeBlk->FileName == ""))
        SaveDialog1->FileName = MimeBlk->FileName;
      else
        SaveDialog1->FileName = "*.*";
      if (SaveDialog1->Execute())
        MimeBlk->ExtractBodyFile(SaveDialog1->FileName);
    }
    __finally {
      delete MimeBlk;
    }
  }
}
//---------------------------------------------------------------------------

