// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "telnet1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpTerm"
#pragma link "IpUtils"
#pragma link "IpSock"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ConnectBtnClick(TObject *Sender)
{
  IpTerminal1->ClearAll();

  ConnectBtn->Enabled = false;

  if( ServerEdit->Text == "" ){
    ShowMessage( "No server specified." );
    ConnectBtn->Enabled = true;
  }else{
    AnsiString tmp_str;

    if( TelnetPort->Checked ){
      tmp_str =  ServerEdit->Text + ":23";
    }else{
      tmp_str =  ServerEdit->Text + ":" + PortEdit->Text;
    }
    IpClient1->ConnectSocket( tmp_str );
    Server_str = tmp_str ;
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpClient1Status(TObject *Sender, DWORD Socket,
      TIpStatusType Event, const TIpConnRec &Connection,
      const TIpSockStatRec &StatRec)
{
  switch( Event ) {
    case stConnect :
      ConnectBtn->Enabled    = false                                  ;
      DisconnectBtn->Enabled = true                                   ;
      Form1->Caption         = "ExTelnet : Connected to " + Server_str;
      IpTerminal1->SetFocus()                                         ;
    break;
    case stDisconnect :
      ConnectBtn->Enabled    = true                                   ;
      DisconnectBtn->Enabled = false                                  ;
      Form1->Caption         = "ExTelnet"                             ;
    break;
    case stProgress :
    break;
  }}
//---------------------------------------------------------------------------
void __fastcall TForm1::DisconnectBtnClick(TObject *Sender)
{
  IpClient1->CloseSocket();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::TelnetPortClick(TObject *Sender)
{
  if( TelnetPort->Checked )
    PortEdit->Enabled = false;
  else
    PortEdit->Enabled = true ;

}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpClient1Error(TObject *Sender, DWORD Socket,
      int ErrCode, const AnsiString ErrStr)
{
  ShowMessage( ErrStr );
  ConnectBtn->Enabled    = true ;
  DisconnectBtn->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ExitBtnClick(TObject *Sender)
{
  IpClient1->CloseSocket();
  Close();
}
//---------------------------------------------------------------------------
