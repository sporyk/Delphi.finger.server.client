//---------------------------------------------------------------------------
#ifndef ImMainH
#define ImMainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpIM.hpp"
#include "IpSock.hpp"
#include "IpUtils.hpp"
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TfrmMain : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel1;
    TStatusBar *StatusBar1;
    TPanel *Panel2;
    TPanel *Panel7;
    TSpeedButton *sbAddContact;
    TSpeedButton *sbDeleteContact;
    TSpeedButton *sbSendMessage;
    TSpeedButton *btnShowIM;
    TPanel *Panel8;
    TImage *ImgMSN;
    TImage *ImgAOL;
    TPanel *Panel3;
    TPanel *Panel4;
    TImage *Image1;
    TPanel *Panel5;
    TImage *Image2;
    TImage *Image3;
    TListBox *lbOnLine;
    TPanel *Panel6;
    TListBox *lbOffLine;
    TMainMenu *MainMenu1;
    TMenuItem *File1;
    TMenuItem *Signin1;
    TMenuItem *SignOut1;
    TMenuItem *MyStatus1;
    TMenuItem *OnLine1;
    TMenuItem *Busy1;
    TMenuItem *Berightback1;
    TMenuItem *Away1;
    TMenuItem *Onthephone1;
    TMenuItem *Outtolunch1;
    TMenuItem *Hidden1;
    TMenuItem *Idle1;
    TMenuItem *N5;
    TMenuItem *OffLine1;
    TMenuItem *N1;
    TMenuItem *Addcontact1;
    TMenuItem *Deletecontact1;
    TMenuItem *Properties1;
    TMenuItem *N2;
    TMenuItem *Exit1;
    TMenuItem *View1;
    TMenuItem *Toolbar1;
    TMenuItem *Statusbar2;
    TMenuItem *OffLinecontacts1;
    TMenuItem *Logo11;
    TMenuItem *OnLinecolot1;
    TMenuItem *OffLinecolor1;
    TMenuItem *Tools1;
    TMenuItem *SendIM1;
    TMenuItem *N4;
    TMenuItem *Options1;
    TMenuItem *Help1;
    TMenuItem *About1;
    TIpIMClient *IpIMClient1;
    TPopupMenu *PopupOnLine;
    TMenuItem *Sendmessage1;
    TMenuItem *N6;
    TMenuItem *Delete1;
    TMenuItem *Block1;
    TMenuItem *N7;
    TMenuItem *Properties2;
    TPopupMenu *PopupOffLine;
    TMenuItem *Delete2;
    TMenuItem *Block2;
    TMenuItem *N8;
    TMenuItem *Properties3;
    TColorDialog *ColorDialog1;
    TPopupMenu *puSelProtocol;
    TMenuItem *miSelProtocol;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall btnShowIMClick(TObject *Sender);
    void __fastcall sbSendMessageMouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
    void __fastcall IpIMClient1RcvInstantMessage(TIpCustomIMClient *Client,
          AnsiString SenderID, AnsiString SenderFriendlyName,
          AnsiString Msg, AnsiString MsgRaw, bool &Accept);
    void __fastcall IpIMClient1ProtocolError(TIpCustomIMClient *Client,
          int ErrCode, AnsiString ErrString);
    void __fastcall Block1Click(TObject *Sender);
    void __fastcall Properties2Click(TObject *Sender);
    void __fastcall PopupOnLinePopup(TObject *Sender);
    void __fastcall PopupOffLinePopup(TObject *Sender);
    void __fastcall Sendmessage1Click(TObject *Sender);
    void __fastcall About1Click(TObject *Sender);
    
    void __fastcall Properties1Click(TObject *Sender);
    void __fastcall Options1Click(TObject *Sender);
    void __fastcall Signin1Click(TObject *Sender);
    void __fastcall SignOut1Click(TObject *Sender);
    void __fastcall OnLine1Click(TObject *Sender);
    void __fastcall Busy1Click(TObject *Sender);
    void __fastcall Berightback1Click(TObject *Sender);
    void __fastcall Away1Click(TObject *Sender);
    void __fastcall Onthephone1Click(TObject *Sender);
    void __fastcall Outtolunch1Click(TObject *Sender);
    void __fastcall Hidden1Click(TObject *Sender);
    void __fastcall Idle1Click(TObject *Sender);
    void __fastcall OffLine1Click(TObject *Sender);
    void __fastcall Addcontact1Click(TObject *Sender);
    void __fastcall Deletecontact1Click(TObject *Sender);
    void __fastcall lbOnLineClick(TObject *Sender);
    void __fastcall lbOffLineClick(TObject *Sender);
    void __fastcall Exit1Click(TObject *Sender);
    void __fastcall Toolbar1Click(TObject *Sender);
    void __fastcall Statusbar2Click(TObject *Sender);
    void __fastcall OffLinecontacts1Click(TObject *Sender);
    void __fastcall OnLinecolot1Click(TObject *Sender);
    void __fastcall OffLinecolor1Click(TObject *Sender);
    void __fastcall puSelProtocolPopup(TObject *Sender);
    void __fastcall miSelProtocolClick(TObject *Sender);
    void __fastcall SendIM1Click(TObject *Sender);
    void __fastcall IpIMClient1BuddyPresenceChange(
          TIpCustomIMClient *Client, AnsiString BuddyID,
          AnsiString BuddyFriendlyName, TIMOnLineStatus Status);
    void __fastcall IpIMClient1ChatInvitation(TIpCustomIMClient *Client,
          AnsiString SenderID, AnsiString SenderFriendlyName,
          bool &Accept);
    void __fastcall IpIMClient1ChatRosterChange(TIpCustomIMClient *Client,
          bool Addition, AnsiString UserHandle, AnsiString FriendlyName);
    void __fastcall IpIMClient1ListChange(TIpCustomIMClient *Client,
          bool Addition, AnsiString UserHandle, AnsiString FriendlyName,
          TIMListType ListType);
    void __fastcall IpIMClient1SendInstantMessage(
          TIpCustomIMClient *Client, AnsiString SenderID,
          AnsiString SenderFriendlyName, AnsiString Msg);
    void __fastcall IpIMClient1StateChange(TIpCustomIMClient *Client,
          TIMProtocolState State);
    
    
    void __fastcall IpIMClient1StatusChange(TIpCustomIMClient *Client,
          TIMOnLineStatus Status);
private:	// User declarations
    void SetAllControls(void);
    void UpdateLists(void);
    TIpIMPresentity* FCurrentContact;
    bool FCurrentContactOnLine;
public:		// User declarations
    __fastcall TfrmMain(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmMain *frmMain;
//---------------------------------------------------------------------------
#endif
