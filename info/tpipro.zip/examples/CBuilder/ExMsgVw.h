//---------------------------------------------------------------------------
#ifndef ExMsgVwH
#define ExMsgVwH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpBroker.hpp"
#include "IpHtml.hpp"
#include <ExtCtrls.hpp>
#include "IpUtils.hpp"
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TfrmExMsgView : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel1;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label5;
    TEdit *edtFrom;
    TEdit *edtTo;
    TEdit *edtCC;
    TEdit *edtSent;
    TEdit *edtSubject;
    TIpHtmlPanel *IpHtmlPanel1;
    TIpHtmlDataProvider *IpHtmlDataProvider1;
    TTreeView *tvMimeParts;
    TLabel *Label6;
    TSaveDialog *SaveDialog1;
    void __fastcall IpHtmlDataProvider1CheckURL(TObject *Sender,
          const AnsiString URL, bool &Available, AnsiString &ContentType);
    void __fastcall IpHtmlDataProvider1GetHtml(TObject *Sender,
          const AnsiString URL, const TIpFormDataEntity *PostData,
          TStream *&Stream);
    void __fastcall tvMimePartsDblClick(TObject *Sender);
private:	// User declarations
    void __fastcall AddNestedBlock(TIpMimeEntity* Blk, TTreeNode* ParentNode);
public:		// User declarations
    __fastcall TfrmExMsgView(TComponent* Owner);
    void __fastcall PopulateMimePartsTree(TIpMessage* MsgToView);
};

void __fastcall ViewMessage(TIpMailMessage* MsgToView);

//---------------------------------------------------------------------------
extern PACKAGE TfrmExMsgView *frmExMsgView;
//---------------------------------------------------------------------------
#endif
