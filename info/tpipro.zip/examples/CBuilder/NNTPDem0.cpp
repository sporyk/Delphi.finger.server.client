// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "NNTPDem0.h"
#include "NNTPDem1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpMsg"
#pragma link "IpNntp"
#pragma link "IpSock"
#pragma link "IpUtils"
#pragma resource "*.dfm"
TfrmNNTPDemo *frmNNTPDemo;
//---------------------------------------------------------------------------
__fastcall TfrmNNTPDemo::TfrmNNTPDemo(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void TfrmNNTPDemo::Add(String S)
{
  ListBox1->Items->Add(S);
  ListBox1->ItemIndex = ListBox1->Items->Count - 1;
}
//---------------------------------------------------------------------------
void TfrmNNTPDemo::ResetButtons(bool Connected)
{
  btnConnect->Enabled = True;
  btnList->Enabled = Connected;
  btnArticle->Enabled = Connected;
  btnBody->Enabled = Connected;
  btnHead->Enabled = Connected;
  btnGroup->Enabled = Connected;
  btnHelp->Enabled = Connected;
  btnLast->Enabled = Connected;
  btnNewGroups->Enabled = Connected;
  btnNewNews->Enabled = Connected;
  btnNext->Enabled = Connected;
  btnStat->Enabled = Connected;
  btnPost->Enabled = Connected;

  btnAuthorize->Enabled = Connected;
  btnDate->Enabled = Connected;
  btnList_ActiveTimes->Enabled = Connected;
  btnList_Extensions->Enabled = Connected;
  btnList_Distributions->Enabled = Connected;
  btnList_Newsgroups->Enabled = Connected;
  btnList_OverviewFmt->Enabled = Connected;
  btnListGroup->Enabled = Connected;
  btnOver->Enabled = Connected;
  btnPat->Enabled = Connected;
  btnSpecial->Enabled = Connected;
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::IpNntpClient1Article(TIpCustomNntpClient *Client,
      TIpNewsArticle *Article)
{
  frmArticle->btnPost->Enabled = false;
  if (Article->Newsgroups->Count > 0)
    frmArticle->Caption = Article->Subject + " from " + Article->Newsgroups->Strings[0];
  frmArticle->Article->Assign(Article);
  frmArticle->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::IpNntpClient1MultiLineResponse(
      TIpCustomNntpClient *Client, TIpNntpStates ResponseTo,
      TStringList *ResponseList)
{
  Add("NNTPMultiLineResponse : " + IpNntpClient1->StateToStr(ResponseTo));
  for (int I=0; I<ResponseList->Count; I++)
    Add("                     " + ResponseList->Strings[I]);
  if (ResponseTo == nsList){
      // delete the response code
      ResponseList->Delete(0);
      for (int I=0; I<ResponseList->Count; I++){
        String S = ResponseList->Strings[I];
        ResponseList->Strings[I] = S.SubString(1, S.Pos(' ') - 1);
      }
      cbxNewsGroups->Items->Assign(ResponseList);
      if (cbxNewsGroups->Items->Count > 0)
        cbxNewsGroups->ItemIndex = 0;
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::IpNntpClient1Response(TIpCustomNntpClient *Client,
      TIpNntpStates ResponseTo, int Code, const AnsiString Response)
{
  Add("NNTPResponse: " + IpNntpClient1->StateToStr(ResponseTo) + ", " +
    IntToStr(Code) + ", " + Response);
  if ((ResponseTo == nsConnect) || (ResponseTo == nsQuit) &&
     (Code >= 200) && (Code <= 250))
    ResetButtons(ResponseTo == nsConnect);
  if (ResponseTo == nsConnect)
    cbxPostingAllowed->Checked = IpNntpClient1->PostingAllowed;
  if (ResponseTo == nsGroup)
    lblNumMessages->Caption = "There are " + IntToStr(IpNntpClient1->NumArticles) +
      " articles in " + IpNntpClient1->CurrentGroup;
  lblCurrentMessageNum->Caption = "Message Number: " +
    IntToStr(IpNntpClient1->CurrentArticleNum);
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::IpNntpClient1StateChange(
      TIpCustomNntpClient *Client, TIpNntpStates NewState)
{
  Add("NNTPStateChange : " + IpNntpClient1->StateToStr(NewState));    
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::IpNntpClient1TaskComplete(
      TIpCustomNntpClient *Client, TIpNntpTasks NewTask,
      TStringList *ResponseList)
{
  Add("NntpTaskComplete : " + IpNntpClient1->TaskToStr(NewTask));
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnConnectClick(TObject *Sender)
{
  btnConnect->Enabled = False;
  if (btnConnect->Caption == "Connect") {
    btnConnect->Caption = "Quit";
    IpNntpClient1->UserID = edtUserID->Text;
    IpNntpClient1->Password = edtPassword->Text;
    String S;
    String YYMMDD;
    String HHMMSS;
    switch (rgpTask->ItemIndex){
      case 0 :
        IpNntpClient1->Connect(edtNNTPAddress->Text);
        break;
      case 1 :
        IpNntpClient1->ConnectAndLogon(edtNNTPAddress->Text);
        break;
      case 2 :
        S = InputBox("GotoGroup", "Enter newsgroup name", "");
        IpNntpClient1->GotoGroup(edtNNTPAddress->Text, S);
        break;
      case 3 :
        S = InputBox("NewNews", "Enter newsgroup name", "");
        YYMMDD = InputBox("NewNews", "Enter start date (YYMMDD)", "020101");
        HHMMSS = InputBox("NewNews", "Enter start time (HHMMSS)", "000000");
        IpNntpClient1->NewNews(edtNNTPAddress->Text, S, YYMMDD, HHMMSS);
        break;
      case 4 :
        frmArticle->Caption = "New message: " + IpNntpClient1->CurrentGroup;
        S = InputBox("PostTo", "Enter group to post to", "");
        frmArticle->edtPath->Text = S;
        frmArticle->edtNewsgroup->Text = S;
        if (frmArticle->ShowModal() == mrOk) {
          IpNntpClient1->Article = frmArticle->Article;
          IpNntpClient1->PostTo(edtNNTPAddress->Text, S);
        }
        break;
    }
  } else {
    btnConnect->Caption = "Connect";
    IpNntpClient1->Quit();
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnNewGroupsClick(TObject *Sender)
{
  String YYMMDD = InputBox("Find new newsgroups", "Enter start date (YYMMDD)", "020101");
  String HHMMSS = InputBox("Find new newsgroups", "Enter start time (HHMMSS)", "000000");
  IpNntpClient1->GetNewGroups(YYMMDD, HHMMSS, tzServer);
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnListClick(TObject *Sender)
{
  IpNntpClient1->GetGroupList();
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnGroupClick(TObject *Sender)
{
  IpNntpClient1->SelectGroup(cbxNewsGroups->Text);
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnHelpClick(TObject *Sender)
{
  IpNntpClient1->GetSupportedCommands();
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnNewNewsClick(TObject *Sender)
{
  String YYMMDD = InputBox("Find new articles", "Enter start date ([YY]YYMMDD)", "20000101");
  String HHMMSS = InputBox("Find new articles", "Enter start time (HHMMSS)", "000000");
  IpNntpClient1->GetNewNews(cbxNewsGroups->Text, YYMMDD, HHMMSS, tzServer, "*");
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnArticleClick(TObject *Sender)
{
  IpNntpClient1->GetArticle();    
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnHeadClick(TObject *Sender)
{
  IpNntpClient1->GetHeader();    
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnBodyClick(TObject *Sender)
{
  IpNntpClient1->GetBody();    
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnLastClick(TObject *Sender)
{
  IpNntpClient1->SelectPrior();    
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnNextClick(TObject *Sender)
{
  IpNntpClient1->SelectNext();    
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnStatClick(TObject *Sender)
{
  IpNntpClient1->GetArticleInfo();    
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnPostClick(TObject *Sender)
{
  if (!IpNntpClient1->PostingAllowed)
    ShowMessage("The news server reported that posting is not allowed.\r\n"
                 "Your message may not be accepted by the news server.");

  frmArticle->Caption = "New message: " + IpNntpClient1->CurrentGroup;
  frmArticle->Article->NewMessage();
  frmArticle->Article->Path->Text = IpNntpClient1->CurrentGroup;
  frmArticle->Article->NNTPPostingHost =
    IpNntpClient1->NetAddr2String(IpNntpClient1->LocalAddress);
  frmArticle->Article->Newsgroups->Text = IpNntpClient1->CurrentGroup;
  if (frmArticle->ShowModal() == mrOk){
    IpNntpClient1->Article = frmArticle->Article;
    IpNntpClient1->PostArticle();
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnAuthorizeClick(TObject *Sender)
{
  IpNntpClient1->Authenticate();    
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnList_ExtensionsClick(TObject *Sender)
{
  IpNntpClient1->GetList_Extensions();    
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnList_NewsgroupsClick(TObject *Sender)
{
  IpNntpClient1->GetList_Newsgroups();    
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnDateClick(TObject *Sender)
{
  IpNntpClient1->GetServerDate();    
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnList_DistributionsClick(TObject *Sender)
{
  IpNntpClient1->GetList_Distributions();    
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnList_OverviewFmtClick(TObject *Sender)
{
  IpNntpClient1->GetList_OverviewFmt();    
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnList_ActiveTimesClick(TObject *Sender)
{
  IpNntpClient1->GetList_ActiveTimes(cbxNewsGroups->Text);
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnListGroupClick(TObject *Sender)
{
  IpNntpClient1->GetArticleNumbers(cbxNewsGroups->Text);    
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnOverClick(TObject *Sender)
{
  IpNntpClient1->GetOverview(edtRange->Text);    
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnPatClick(TObject *Sender)
{
  IpNntpClient1->GetMatchingArticles(edtHeader->Text, edtRange->Text);    
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnSpecialClick(TObject *Sender)
{
  String SpecialCommand = InputBox("NNTP Special command",
    "Enter the special command and parameters", "");
  if (SpecialCommand.Length() > 0)
    IpNntpClient1->SendSpecial(SpecialCommand,
      MessageDlg("Are you expecting a multi-line response?",
      mtConfirmation, TMsgDlgButtons() << mbYes << mbNo, 0) == mrYes);
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnSaveListboxClick(TObject *Sender)
{
  SaveDialog1->DefaultExt = ".txt";
  SaveDialog1->Filter = "All files (*.*)|*.*";
  SaveDialog1->Title = "Save responses";
  if (SaveDialog1->Execute())
    ListBox1->Items->SaveToFile(SaveDialog1->FileName);
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::btnClearListboxClick(TObject *Sender)
{
  ListBox1->Items->Clear();    
}
//---------------------------------------------------------------------------
void __fastcall TfrmNNTPDemo::CheckBox1Click(TObject *Sender)
{
  ShowHint = CheckBox1->Checked;    
}
//---------------------------------------------------------------------------
