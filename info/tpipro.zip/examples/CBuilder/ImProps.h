//---------------------------------------------------------------------------
#ifndef ImPropsH
#define ImPropsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TfrmMyProperties : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel1;
    TButton *btnOK;
    TPageControl *PageControl1;
    TTabSheet *tsProperties;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *lblLoginName;
    TLabel *lblFriendlyName;
    TLabel *lblOnLineStatus;
    TLabel *lblConnection;
private:	// User declarations
public:		// User declarations
    __fastcall TfrmMyProperties(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmMyProperties *frmMyProperties;
//---------------------------------------------------------------------------
#endif
