//---------------------------------------------------------------------------
#ifndef ImSignInH
#define ImSignInH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Mask.hpp>
//---------------------------------------------------------------------------
class TfrmSignin : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TLabel *Label2;
    TBevel *Bevel1;
    TButton *btnOK;
    TButton *btnCancel;
    TEdit *edtSignOnName;
    TMaskEdit *edtPassword;
    void __fastcall btnOKClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TfrmSignin(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmSignin *frmSignin;
//---------------------------------------------------------------------------
#endif
