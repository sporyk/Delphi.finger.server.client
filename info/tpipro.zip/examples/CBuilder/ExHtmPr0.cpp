// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ExHtmPr0.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpHtml"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ListNodes(TIpHtmlNode *Node)
{
  String S;

  /*See if node is a type which has an HREF attribute
   That is, <A> || <AREA> nodes.*/

  TIpHtmlNodeA *NodeA = dynamic_cast<TIpHtmlNodeA *>(Node);
  if (NodeA) {
    S = NodeA->HRef;
  }
  else {

    TIpHtmlNodeAREA *NodeAREA = dynamic_cast<TIpHtmlNodeAREA *>(Node);
    if (NodeAREA) {
      S = NodeAREA->HRef;
    }
  }

  S = Trim(S);

  /*If HREF was !blank && we haven"t seen it before,
   add it to the list*/
  if ((S != "") && (LinkList->IndexOf(S) == -1)) {
    LinkList->Add(S);
  }

  /*See if Node is a container type node. If so, recursively
   traverse its children.*/

  TIpHtmlNodeMulti *NodeMulti = dynamic_cast<TIpHtmlNodeMulti *>(Node);
  if (NodeMulti) {
    for (int i = 0; i <= (NodeMulti->ChildCount)-1 ; i++) {
      ListNodes(NodeMulti->ChildNode[i]);
    }
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
  if (OpenDialog1->Execute()) {
    TFileStream *S = new TFileStream(OpenDialog1->FileName, 0);
    try {
      /*create an empty HTML document container*/
      TIpHtml *HTML = new TIpHtml();
      try {
        /*load the document from the stream*/
        HTML->LoadFromStream(S);
        /*create a list to hold the unique links*/
        LinkList = new TStringList();
        try {
          LinkList->Sorted = True;

          /*traverse the HTML node tree starting with the
           <HTML> root node.*/
          ListNodes(HTML->HtmlNode);

          /*Add the list to the memo*/
          Memo1->Lines = LinkList;

          Label3->Caption = "Links in " + OpenDialog1->FileName + " :";
        } __finally {
          delete LinkList;
        }
      } __finally {
        delete HTML;
      }
    } __finally {
      delete S;
    }
  }
}
//---------------------------------------------------------------------------
 