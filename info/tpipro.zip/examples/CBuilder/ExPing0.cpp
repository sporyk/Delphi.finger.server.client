// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ExPing0.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpIcmp"
#pragma link "IpSock"
#pragma link "IpUtils"
#pragma resource "*.dfm"
TfrmExPing *frmExPing;
//---------------------------------------------------------------------------
__fastcall TfrmExPing::TfrmExPing(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TfrmExPing::btnPingClick(TObject *Sender)
{
  int Count = StrToIntDef(edtPingCount->Text, 4);
  lbxPing->Items->Add("Pinging " + edtPingAddress->Text + " with " +
    IntToStr(IpIcmp1->PacketSize) + " bytes data");
  IpIcmp1->ResolveAddress = cbxResolve->Checked;
  if (cbxBlockingPing->Checked)
    IpIcmp1->BlockingPing(edtPingAddress->Text, (Byte)Count);
  else
    IpIcmp1->Ping(edtPingAddress->Text, (Byte)Count);
}
//---------------------------------------------------------------------------

void __fastcall TfrmExPing::IpIcmp1IcmpEcho(TIpCustomIcmp *Icmp,
      const TIpExtendedEchoInfo *EchoInfo, const AnsiString EchoFrom)
{
  lblRTTMinimum->Caption = "RTT Minimum: " + IntToStr(IpIcmp1->RTTMinimum);
  lblRTTMaximum->Caption = "RTT Maximum: " + IntToStr(IpIcmp1->RTTMaximum);
  lblRTTAverage->Caption = "RTT Average: " + IntToStr(IpIcmp1->RTTAverage);
}
//---------------------------------------------------------------------------

void __fastcall TfrmExPing::IpIcmp1IcmpEchoString(TIpCustomIcmp *Icmp,
      const AnsiString EchoString)
{
  lbxPing->Items->Add(EchoString);    
}
//---------------------------------------------------------------------------

void __fastcall TfrmExPing::IpIcmp1PingComplete(TIpCustomIcmp *Icmp,
      const TStringList *Replies, bool PingOK)
{
  lbxPing->Items->Add("OnPingComplete");
  lbxPing->Items->Add("Pings sent: " + IntToStr(IpIcmp1->PacketsSent));
  lbxPing->Items->Add("Pings rcvd: " + IntToStr(IpIcmp1->PacketsRcvd));
  if (PingOK)
    lbxPing->Items->Add("PingOK");
  else
    lbxPing->Items->Add("Ping not OK");
}
//---------------------------------------------------------------------------

