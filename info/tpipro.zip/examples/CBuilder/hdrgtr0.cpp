// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "hdrgtr0.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpHttp"
#pragma link "IpSock"
#pragma link "IpUtils"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnHeadClick(TObject *Sender)
{
  GotReply = false;
  String S = Edit1->Text;
  HTTP->HeadWait(S);

  TIpAnsiTextStream* BS = new TIpAnsiTextStream(HTTP->HeaderDat[Edit1->Text]);
  while (!BS->AtEndOfStream()) {
    Memo1->Lines->Add(BS->ReadLine());
  }
  delete BS;
  HTTP->FreeLink(Edit1->Text);
          
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnGetClick(TObject *Sender)
{
  GotReply = false;
  HTTP->GetWait(Edit1->Text);

  if (HTTP->HeaderDat[Edit1->Text]->Size > 0) {
    Memo1->Lines->Add("Got Header Info");
  }
  else {
    Memo1->Lines->Add("No Header Info");
  }

  if (HTTP->BodyStream[Edit1->Text]->Size > 0) {
    Memo1->Lines->Add("Got Body Info; Size="
      + IntToStr(HTTP->BodyStream[Edit1->Text]->Size));
  }
  else {
    Memo1->Lines->Add("No Body Info");
  }
  HTTP->FreeLink(Edit1->Text);        
}
//---------------------------------------------------------------------------
void __fastcall TForm1::HTTPDisconnect(TObject *Sender, DWORD Socket)
{
  GotReply = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::HTTPHttpResult(TObject *Sender, DWORD Socket,
      AnsiString Code, AnsiString Message, TStream *HeaderDat)
{
  Memo1->Lines->Add("HTTP(" + Code + ") """ + Message + """");        
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
  GotReply = False;
  HTTP->HeadWait(Edit1->Text);

  if (!GotReply) {
    ShowMessage("Unable to get header for requested entity");
    return;
  }

  if (SaveDialog1->Execute()) {
    if (HTTP->HeaderDat[Edit1->Text]->Size > 0) {
      dynamic_cast<TMemoryStream *>(HTTP->HeaderDat[Edit1->Text])->SaveToFile(SaveDialog1->FileName);
      }
    else {
      ShowMessage("No header data to save");
    }
  }
  HTTP->FreeLink(Edit1->Text);        
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
  GotReply = False;
  HTTP->GetWait(Edit1->Text);

  if (!GotReply) {
    ShowMessage("Unable to get body data for requested entity");
    return;
  };

  if (SaveDialog1->Execute()) {
    if (HTTP->BodyStream[Edit1->Text]->Size > 0) {
      dynamic_cast<TIpDownloadFileStream *>(HTTP->BodyStream[Edit1->Text])->Move(SaveDialog1->FileName);
    }
    else {
      ShowMessage("No body data to save");
    }
  }
  HTTP->FreeLink(Edit1->Text);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Memo1DblClick(TObject *Sender)
{
  Memo1->Lines->Clear();        
}
//---------------------------------------------------------------------------
