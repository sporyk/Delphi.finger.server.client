//---------------------------------------------------------------------------
#ifndef telnet1H
#define telnet1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpTerm.hpp"
#include "IpUtils.hpp"
#include "IpSock.hpp"
#include <Mask.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TIpTerminal *IpTerminal1;
    TButton *ConnectBtn;
    TIpClient *IpClient1;
    TIpVT100Emulator *IpVT100Emulator1;
    TEdit *ServerEdit;
    TButton *DisconnectBtn;
    TCheckBox *TelnetPort;
    TEdit *PortEdit;
    TButton *ExitBtn;
    void __fastcall ConnectBtnClick(TObject *Sender);
    void __fastcall IpClient1Status(TObject *Sender, DWORD Socket,
          TIpStatusType Event, const TIpConnRec &Connection,
          const TIpSockStatRec &StatRec);
    void __fastcall DisconnectBtnClick(TObject *Sender);
    void __fastcall TelnetPortClick(TObject *Sender);
    void __fastcall IpClient1Error(TObject *Sender, DWORD Socket,
          int ErrCode, const AnsiString ErrStr);
    
    
    void __fastcall ExitBtnClick(TObject *Sender);
    
private:	// User declarations   ]
    AnsiString Server_str;
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
