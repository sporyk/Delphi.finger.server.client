// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ExFtpDi1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpFtp"
#pragma link "IpSock"
#pragma link "IpUtils"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::btnLoginClick(TObject *Sender)
{
  if (IpFtpClient1->Login(edtURL->Text,
                          edtUserName->Text,
                          edtPassword->Text, "")) {
    Screen->Cursor = crHourGlass;
    Caption = "Logging in to: " + edtURL->Text;
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnLogoutClick(TObject *Sender)
{
  IpFtpClient1->Logout();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::IpFtpDirectoryTree1Change(TObject *Sender,
      TTreeNode *Node)
{
  Screen->Cursor = crHourGlass;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::IpFtpDirectoryTree1Changed(TObject *Sender)
{
  Screen->Cursor = crDefault;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::lbxRemoteFilesMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
  int i = lbxRemoteFiles->ItemAtPos(Point(X,Y), True);
  if (i > -1) {
    TIpFtpFileInfo *Info = (TIpFtpFileInfo*)lbxRemoteFiles->Items->Objects[i];
    if (Info != 0) {
      gbxFiles->Caption = " Selected file: " + Info->FileName + " ";
      lblLinkPath->Caption = Info->LinkPath;
      OwnerLbl->Caption = Info->Owner;
      GroupLbl->Caption = Info->Group;
      SizeLbl->Caption = IntToStr(Info->Size);
      TimeLbl->Caption = Info->TimeStamp;
      switch (Info->FileType) {
        case ftFile  : TypeLbl->Caption = "Normal file";
                       break;
        case ftDir   : TypeLbl->Caption = "Directory";
                       break;
        case ftLink  : TypeLbl->Caption = "Link";
                       break;
        default      : TypeLbl->Caption = "Unknown";
      }
      PermOwnerLbl->Caption = "";
      if (Info->Permissions.Owner.Contains(faRead))
        PermOwnerLbl->Caption = PermOwnerLbl->Caption + "Read/";
      if (Info->Permissions.Owner.Contains(faWrite))
        PermOwnerLbl->Caption = PermOwnerLbl->Caption + "Write/";
      if (Info->Permissions.Owner.Contains(faExecute))
        PermOwnerLbl->Caption = PermOwnerLbl->Caption + "Execute";
      PermGroupLbl->Caption = "";
      if (Info->Permissions.Group.Contains(faRead))
        PermGroupLbl->Caption = PermGroupLbl->Caption + "Read/";
      if (Info->Permissions.Group.Contains(faWrite))
        PermGroupLbl->Caption = PermGroupLbl->Caption + "Write/";
      if (Info->Permissions.Group.Contains(faExecute))
        PermGroupLbl->Caption = PermGroupLbl->Caption + "Execute";
      PermOtherLbl->Caption = "";
      if (Info->Permissions.Other.Contains(faRead))
        PermOtherLbl->Caption = PermOtherLbl->Caption + "Read/";
      if (Info->Permissions.Other.Contains(faWrite))
        PermOtherLbl->Caption = PermOtherLbl->Caption + "Write/";
      if (Info->Permissions.Other.Contains(faExecute))
        PermOtherLbl->Caption = PermOtherLbl->Caption + "Execute";
    }
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
  cbxDirectoryStyle->ItemIndex = (int)IpFtpDirectoryTree1->DirectoryStyle;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::cbxDirectoryStyleChange(TObject *Sender)
{
  IpFtpDirectoryTree1->DirectoryStyle = (TIpFtpDirStyle)cbxDirectoryStyle->ItemIndex;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::IpFtpClient1FtpError(TObject *Sender,
      int ErrorCode, const AnsiString ErrorText)
{
  ShowMessage(ErrorText);
  Screen->Cursor = crDefault;
}
//---------------------------------------------------------------------------


void __fastcall TForm1::IpFtpClient1FtpStatus(TObject *Sender,
      TIpFtpStatusCode StatusCode, const AnsiString Info)
{
  switch (StatusCode) {
    case fscLogin      : Caption = IpFtpClient1->UserName + " logged in";
                         break;
    case fscClose      : Caption = "ExDir";
                         Screen->Cursor = crDefault;
                         StatusBar1->Panels->Items[1]->Text = "";
                         StatusBar1->Panels->Items[0]->Text = "";
                         break;
    case fscCurrentDir : StatusBar1->Panels->Items[1]->Text = Info;
                         break;
    case fscSystem     : StatusBar1->Panels->Items[0]->Text = Info;
                         break;
  }
  Screen->Cursor = crDefault;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::StatusBar1DblClick(TObject *Sender)
{
  IpFtpClient1->SystemName();
}
//---------------------------------------------------------------------------

