// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "BrowSc.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpHtml"
#pragma resource "*.dfm"
TfrmBrowseSource *frmBrowseSource;

void __fastcall ViewHTMLSource(TStream *S)
{
  frmBrowseSource->CurStream = S;
  frmBrowseSource->ShowHTMLSyntax();
  frmBrowseSource->ShowModal();
}

//---------------------------------------------------------------------------
__fastcall TfrmBrowseSource::TfrmBrowseSource(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowseSource::Save1Click(TObject *Sender)
{
  if (SaveDialog1->Execute()) {
    TFileStream* FS = new TFileStream(SaveDialog1->FileName, fmCreate);
    try {
      CurStream->Seek(0, 0);
      FS->CopyFrom(CurStream, CurStream->Size);
    }
    __finally {
      delete FS;
    }
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowseSource::ShowHTMLSyntax()
{
  /*Create an instance of TIpHTML (an Internet Professional
   memory HTML document) to hold the text*/
  TIpHtml* HTML = new TIpHtml;
  /*TIpHTML automatically creates an empty internal
   <HTML> node which can be accessed via the HTML->HTMLNode
   property. Note the difference: The HTML variable here
   is of type TIpHTML. TIpHTML is the document as a whole.
   The auto-created HTML->HTMLNode is of type TIpHTMLNodeHTML,
   representing the <HTML> tag within the HTML document.*/

  /*Now, create a <BODY> node with the <HTML> node as parent, and
   use the newly created <BODY> node as the parent
   for the actual content.*/
  TIpHtmlNodeBODY* NodeBody = new TIpHtmlNodeBODY(HTML->HtmlNode);
  CreateBody(NodeBody);

  /*Assign the HTML document just created in memory to the
   panel for display.*/
  HTMLPanel1->SetHtml(HTML);
  /*The panel takes ownership of the HTML instance && will
   destroy it with its child node hierarchy when it"s no
   longer needed.*/
}
//---------------------------------------------------------------------------
char  __fastcall TfrmBrowseSource::NextChar()
{
/*- read next character from stream,
   set StreamEOF if appropriate*/
  if (Stp > 0) {
    Stp--;
    CurChar = CharStack[Stp];
  }
  else {
  if (StreamEOF) {
    CurChar = (char)0;
  }
  else {
    if (!CurStream->Read(&CurChar, 1)) {
      CurChar= (char)0;
      StreamEOF = True;
    }
  }}
  return CurChar;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowseSource::CollectToOpen(AnsiString& St)
{
/*- Read from stream until a "<" is seen,
   or we reach EOF. Append read characters
   to St. */
  for (;(!StreamEOF && (NextChar() != '<')); St = St + CurChar);
//  do {
//    St = St + CurChar;
//  } while (!StreamEOF && (NextChar() != '<'));
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowseSource::Push(char Ch)
{
  CharStack[Stp] = Ch;
  Stp++;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowseSource::CollectToClose(AnsiString& St)
{
/*- We're in a tag. Collect until ">" is
   seen or we reach EOF */
  int P = St.Pos(">");
  if (P == 0) {
    for (;(!(CurChar == '>') && !StreamEOF);St = St + NextChar());
//    do {
//      St = St + NextChar();
//    } while (!(CurChar == '>') && !StreamEOF);
  }
  else {
    /* We may have read into the next tag || text
     in IsComment, so we need to put that data
     "back on the input stream". */
    for (;(St[St.Length()] != '>');) {
//    do {
      Push(St[St.Length()]);
      St.Delete(St.Length(), 1);
    }
//    } while (St[St.Length()] != '>');
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowseSource::CollectToCloseComment(AnsiString& St)
{
/*- We"re in a comment. Collect until --> is
   seen || we reach EOF*/
  Boolean Done = false;
  for (;(!Done && !StreamEOF);) {
//  do {
    switch (NextChar()) {
      case '-' :
        switch (NextChar()) {
          case '-' :
            switch (NextChar()) {
              case '>' :
                St = St + "-->";
                Done = true;
              break;
            default:
              St = St + "--" + CurChar;
            }
          break;
        default:
          St = St + "-" + CurChar;
        }
      break;
    default:
      St = St + CurChar;
    }
  }
//  } while (!Done && !StreamEOF);
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowseSource::CreateText(TIpHtmlNodePRE* PRE, AnsiString& St)
{
/*- Add the contents of St to the <PRE> block
   as plain text.*/
  TIpHtmlNodeText* Txt = new TIpHtmlNodeText(PRE);
  Txt->ANSIText = St;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowseSource::CreateTag(TIpHtmlNodePRE* PRE, AnsiString& St)
{
/*- Add the contents of St to the <PRE> block
   with a bold font style <B>.*/
  TIpHtmlNodeFontStyle* BO = new TIpHtmlNodeFontStyle(PRE);
  BO->Style = hfsB; /*bold*/
  TIpHtmlNodeText* Txt = new TIpHtmlNodeText(BO);
  Txt->ANSIText = St;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowseSource::CreateComment(TIpHtmlNodePRE* PRE, AnsiString& St)
{
/*- Add the contents of St to the <PRE> block
   with an italics font style <I> && with
   a color of clSilver <FONT>.*/
  TIpHtmlNodeFontStyle* IT = new TIpHtmlNodeFontStyle(PRE);
  IT->Style = hfsI;     /*italics*/
  TIpHtmlNodeFONT* FO = new TIpHtmlNodeFONT(IT);
  FO->Color = clSilver; /*light gray*/
  TIpHtmlNodeText* Txt = new TIpHtmlNodeText(FO);
  Txt->ANSIText = St;
}
//---------------------------------------------------------------------------
Boolean  __fastcall TfrmBrowseSource::IsComment(AnsiString& St)
{
  St = "<" + String(NextChar()) + String(NextChar()) + String(NextChar());
  return (St == "<!--");
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowseSource::CreateBody(TIpHtmlNodeBODY* Body)
{
  StreamEOF = False;
  CurStream->Seek(0, soFromBeginning);

  /*Create a <PRE> block (pre-formatted text) to hold
   the HTML source*/

  TIpHtmlNodePRE* PRE = new TIpHtmlNodePRE(Body);

  Stp = 0; /*Reset character stack*/
  AnsiString St = ""; /*Current text block*/

  /*Collect text to the first "<"*/
  CollectToOpen(St);

  /*Add a plain text node with the contents of St*/
  CreateText(PRE, St);

  /*read rest of HTML source document*/
  while (!StreamEOF) {
    St = "";
    /* we"ve now read up to a < */
    if (IsComment(St)) {
      /* this is an HTML comment, collect to --> */
      CollectToCloseComment(St);
      /* put it in the memory hierarchy */
      CreateComment(PRE, St);
    } else {
      /* this is a tag, collect to > */
      CollectToClose(St);
      /* put it in the memory hierarchy */
      CreateTag(PRE, St);
    }
    St = "";
    /* collect any plain text following tag || comment */
    CollectToOpen(St);
    /* put it in the memory hierarchy */
    CreateText(PRE, St);
  }
  /*done*/
}
//---------------------------------------------------------------------------



