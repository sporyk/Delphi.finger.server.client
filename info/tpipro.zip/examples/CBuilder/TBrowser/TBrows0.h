//---------------------------------------------------------------------------

#ifndef TBrows0H
#define TBrows0H
//---------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>
#include <Menus.hpp>
#include <Dialogs.hpp>
#include <Printers.hpp>
#include <Forms.hpp>
#include "IpCache.hpp"
#include "IpBroker.hpp"
#include "IpHtml.hpp"
#include "IpUtils.hpp"
#include "IpCookie.hpp"
//---------------------------------------------------------------------------

#define INIFileName "BROWSR.INI"
#define HistoryFileName "BROWSR.HIS"
#define CookieFileName  "BROWSR.COK"
#define DefMaxHistAge 60

class TfrmBrowsr0 : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TPanel *Panel2;
        TIpHtmlPanel *IpHTMLPanel1;
        TLabel *Label1;
        TComboBox *ComboBox1;
        TPanel *Panel4;
        TPanel *Panel5;
        TTreeView *TreeView1;
        TButton *Button1;
        TButton *Button2;
        TButton *Button3;
        TButton *Button4;
        TButton *Button5;
        TPopupMenu *PopupMenu1;
        TMainMenu *MainMenu1;
        TIpCache *IpCache1;
        TSaveDialog *SaveDialog1;
        TOpenDialog *OpenDialog1;
        TLabel *lblHot;
        TMenuItem *mnFile;
        TMenuItem *mnFile_OpenPage;
        TMenuItem *mnFile_OpenLocalFile;
        TMenuItem *N1;
        TMenuItem *mnFile_SaveNodeHierarchy;
        TMenuItem *mnFile_SavePageSource;
        TMenuItem *N2;
        TMenuItem *mnFile_Exit;
        TMenuItem *mnEdit;
        TMenuItem *mnEdit_Copy;
        TMenuItem *mnEdit_SelectAll;
        TMenuItem *N3;
        TMenuItem *mnEdit_Preferences;
        TMenuItem *mnEdit_ClearHistory;
        TMenuItem *mnView;
        TMenuItem *mnView_PageSource;
        TMenuItem *N4;
        TMenuItem *mnView_Events;
        TMenuItem *mnView_HTMLTree;
        TMenuItem *mnBack;
        TMenuItem *mnForward;
        TMenuItem *N5;
        TMenuItem *mnSaveAs;
        TMenuItem *mnCopy;
        TIpHttpProvider *IpHttpProvider1;
        TCheckBox *CheckBox1;
        TCheckBox *CheckBox2;
        TMemo *Memo1;
        TPrintDialog *PrintDialog1;
        TSplitter* Splitter1;

        void __fastcall Button1Click(TObject *Sender);
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall Button3Click(TObject *Sender);
        void __fastcall Button4Click(TObject *Sender);
        void __fastcall IpHTMLPanel1HotChange(TObject *Sender);
        void __fastcall TreeView1Compare(TObject *Sender, TTreeNode *Node1,
          TTreeNode *Node2, int Data, int &Compare);
        void __fastcall IpHttpProvider1RequestDone(TObject *Sender,
          const AnsiString Url, TIpAbstractNetRequest *Provider);
        void __fastcall IpHttpProvider1RequestStart(TObject *Sender,
          const AnsiString Url, TIpAbstractNetRequest *Provider);
        void __fastcall IpHttpProvider1RequestStatus(TObject *Sender,
          TIpAbstractNetRequest *Provider, const AnsiString ReqType,
          const AnsiString Url, const AnsiString Code,
          const AnsiString Message, const AnsiString Param);
        void __fastcall Memo1DblClick(TObject *Sender);
        void __fastcall Button5Click(TObject *Sender);
        void __fastcall CheckBox1Click(TObject *Sender);
        void __fastcall CheckBox2Click(TObject *Sender);
        void __fastcall mnFile_OpenPageClick(TObject *Sender);
        void __fastcall mnFile_OpenLocalFileClick(TObject *Sender);
        void __fastcall mnFile_SaveNodeHierarchyClick(TObject *Sender);
        void __fastcall mnFile_SavePageSourceClick(TObject *Sender);
        void __fastcall mnView_PageSourceClick(TObject *Sender);
        void __fastcall mnEdit_CopyClick(TObject *Sender);
        void __fastcall mnEdit_SelectAllClick(TObject *Sender);
        void __fastcall mnEdit_PreferencesClick(TObject *Sender);
        void __fastcall mnEdit_ClearHistoryClick(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall mnView_EventsClick(TObject *Sender);
        void __fastcall mnView_HTMLTreeClick(TObject *Sender);
        void __fastcall mnBackClick(TObject *Sender);
        void __fastcall mnForwardClick(TObject *Sender);
        void __fastcall mnSaveAsClick(TObject *Sender);
        void __fastcall mnCopyClick(TObject *Sender);
        void __fastcall mnFile_ExitClick(TObject *Sender);
        void __fastcall FormCloseQuery(TObject *Sender, bool &CanClose);
        void __fastcall mnFile_PrintPageClick(TObject *Sender);
        void __fastcall IpHTMLPanel1Click(TObject *Sender);
        void __fastcall FormKeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall FormKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall FocusedCtrlEnter(TObject *Sender);
        void __fastcall FocusedCtrlExit(TObject *Sender);
        void __fastcall Panel1Resize(TObject *Sender);
        void __fastcall IpHttpProvider1GetHtml(TObject *Sender,
          const AnsiString URL, const TIpFormDataEntity *PostData,
          TStream *&Stream);
        void __fastcall SocketError(TObject *Sender, unsigned int Socket,
          int ErrCode, const AnsiString ErrStr);
        void __fastcall IpHttpProvider1ReportReference(TObject *Sender,
          const AnsiString URL);
   
   void __fastcall IpHttpProvider1GotCookie(TObject *Sender,
          const AnsiString URL, TStrings *Data);
   void __fastcall IpHttpProvider1AuthenticationChallenge(TObject *Sender,
          const AnsiString URL, TStrings *Data);
private:	// User declarations

   void __fastcall DoOpenPage       (       AnsiString   URL     );
   void __fastcall SetStatus        (       AnsiString   StatStr );
   void __fastcall AddToHistory     (       AnsiString   URL     );
   void __fastcall SetCurUrl        ( const AnsiString   Value   );
   void __fastcall PopulateOutline  (       TIpHtml     *H       );
   void __fastcall AddNode          (       TIpHtmlNode *Node     ,
                                            TTreeNode   *Parent  );
   void __fastcall DoGoBack         ( void                       );
   void __fastcall DoGoForward      ( void                       );
   void __fastcall SavePreferences  ( void                       );
   void __fastcall LoadPreferences  ( void                       );
   void __fastcall HTMLClipboardCopy( void                       );

   void __fastcall LoadHistory      ( void                       );
   void __fastcall SaveHistory(Boolean Done);
   void __fastcall HTMLSelectAll    ( void                       );

   AnsiString __fastcall GetCurUrl( void );
   void __fastcall UpdateTreeview();
   Boolean  __fastcall IsValidUrl(AnsiString URL);
   void __fastcall EnumNodes(TIpHtmlNode* Node, int Level);
   void __fastcall EnumDocument(TIpHtml* H);
   void __fastcall UpdateCombo(AnsiString URL);

public:		// User declarations
  Boolean AutoOpen;
  TControl* CurCtrl;
  TStringList* HistList;
  int MaxHistAge;
  TStringList* NodeFile;
  Boolean SocketDone;
  int ErrorCode;
  AnsiString LastUrl;
  AnsiString DefaultPage;
  TIniFile   *BrowsrIni;
  TIpCookieCacheList *Cookies;
  TIpAddrRec CurAddr;
  Boolean Authenticated;

   __fastcall TfrmBrowsr0(TComponent* Owner);

__published :
   __property AnsiString CurUrl = { read = GetCurUrl, write = SetCurUrl };


};

//---------------------------------------------------------------------------
extern PACKAGE TfrmBrowsr0 *frmBrowsr0;
//---------------------------------------------------------------------------
#endif

