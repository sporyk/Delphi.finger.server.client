// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "BrowPr.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CGRID"
#pragma link "cspin"
#pragma resource "*.dfm"
TfrmBrowConfig *frmBrowConfig;
//---------------------------------------------------------------------------
__fastcall TfrmBrowConfig::TfrmBrowConfig(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowConfig::EdEnter(TObject *Sender)
{
  CurEd = dynamic_cast<TEdit *>(Sender);
  if (InColors) {
    ColorDialog1->Color = StringToColor(CurEd->Text);
  }

}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowConfig::Button1Click(TObject *Sender)
{
  if (CurEd == Edit6) {
    OpenDialog1->Filter = "";
    OpenDialog1->Title  = "Select Cache Directory";
    if (OpenDialog1->Execute()) {
      Edit6->Text = ExtractFilePath( OpenDialog1->FileName );
    }
  }
  else {
  if (CurEd == Edit7) {
    OpenDialog1->Filter = "Windows Bitmap Files (*.BMP)|*.BMP|"
                          "JPEG Files (*.JPG)|*.JPG|"
                          "GIF Files (*.GIF)|*.GIF|"
                          "All Graphics (*.BMP, *.JPG, *.GIF)|*.BMP;*.JPG;*.GIF|"
                          "All Files (*.*)|*.*"
                          "Select Default Graphic";
    if (OpenDialog1->Execute()) {
      Edit7->Text = OpenDialog1->FileName;
    }
  }
  else {
    MessageBeep(0);
  }}
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowConfig::TabbedNotebook1Change(TObject *Sender, int NewTab,
      bool &AllowChange)
{

  switch (NewTab) {
    case 0 : InColors = false;
             SendMessage( Edit1->Handle, WM_SETFOCUS, 0, 0 );
             break;
    case 1 : InColors = true ;
             SendMessage( Edit2->Handle, WM_SETFOCUS, 0, 0 );
             break;
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowConfig::FormShow(TObject *Sender)
{
  TabbedNotebook1->ActivePage = "Browser";
  InColors = false;
  Edit1->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowConfig::Button4Click(TObject *Sender)
{
  if (ColorDialog1->Execute()) {
    CurEd->Text = ColorToString(ColorDialog1->Color);
  }
}
//---------------------------------------------------------------------------

