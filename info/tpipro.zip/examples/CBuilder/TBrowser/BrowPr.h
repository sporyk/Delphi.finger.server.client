//---------------------------------------------------------------------------

#ifndef BrowPrH
#define BrowPrH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <Tabnotbk.hpp>
#include "CGRID.h"
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include "cspin.h"
//---------------------------------------------------------------------------
class TfrmBrowConfig : public TForm
{
__published:	// IDE-managed Components
  TBevel* Bevel1;
  TBevel* Bevel2;
        TTabbedNotebook *TabbedNotebook1;
        TLabel *Label1;
        TEdit *Edit1;
        TCheckBox *CheckBox1;
        TLabel *Label6;
        TLabel *Label7;
        TEdit *Edit6;
        TEdit *Edit7;
        TButton *Button1;
        TLabel *Label3;
        TEdit *Edit2;
        TEdit *Edit3;
        TLabel *Label2;
        TLabel *Label4;
        TEdit *Edit4;
        TEdit *Edit5;
        TLabel *Label5;
        TPanel *Panel1;
        TButton *Button2;
        TButton *Button3;
        TOpenDialog *OpenDialog1;
        TColorDialog *ColorDialog1;
        TCSpinEdit *CSpinEdit1;
        void __fastcall EdEnter(TObject *Sender);
        void __fastcall TabbedNotebook1Change(TObject *Sender, int NewTab,
          bool &AllowChange);
        void __fastcall Button1Click(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall Button4Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
       TEdit* CurEd   ;
       BOOL   InColors;

        __fastcall TfrmBrowConfig(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmBrowConfig *frmBrowConfig;
//---------------------------------------------------------------------------
#endif
