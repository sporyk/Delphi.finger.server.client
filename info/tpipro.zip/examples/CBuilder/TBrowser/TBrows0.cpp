// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#include <dir.h>
#if (__BORLANDC__ > 0x530)  // Jpeg unit not included in Builder 3
#include <Jpeg.hpp>
#endif
#pragma hdrstop
#include "TBrows0.h"
#include "BrowPr.h"
#include "BrowSc.h"
#include "pswddlg.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpHtml"
#pragma link "IpBroker"
#pragma link "IpCache"
#pragma link "IpPngImg"

#pragma link "IpUtils"
#pragma resource "*.dfm"
TfrmBrowsr0 *frmBrowsr0;
//---------------------------------------------------------------------------
__fastcall TfrmBrowsr0::TfrmBrowsr0(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::Button1Click(TObject *Sender)
{
  DoOpenPage(ComboBox1->Text);
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::Button2Click(TObject *Sender)
{
  DoGoBack();
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::Button3Click(TObject *Sender)
{
  DoGoForward();
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::Button4Click(TObject *Sender)
{
  DoOpenPage(DefaultPage);
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::Button5Click(TObject *Sender)
{
  try {
    IpHTMLPanel1->Stop();
    IpHttpProvider1->Cancel();
  }
  __finally {
    Screen->Cursor = crDefault;
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::CheckBox1Click(TObject *Sender)
{
  IpHttpProvider1->UseDefaultGraphic = CheckBox1->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::CheckBox2Click(TObject *Sender)
{
  IpHTMLPanel1->FlagErrors = CheckBox2->Checked;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::DoGoBack( void )
{
  Screen->Cursor = crHourGlass;
  IpHTMLPanel1->GoBack();
  UpdateTreeview();
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::DoGoForward( void )
{
  Screen->Cursor = crHourGlass;
  IpHTMLPanel1->GoForward();
  UpdateTreeview();
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::DoOpenPage( AnsiString URL )
{
  if (URL == "") {
    return;
  }

  AnsiString LocalURL = URL;

  Screen->Cursor = crHourGlass;

  if (IsValidUrl(LocalURL)) {
    SetStatus( "Downloading from " + URL + " ..." );
    AddToHistory( CurUrl );

    AnsiString LocalCookie = Cookies->BuildCookie(LocalURL, 0);
    if (LocalCookie != "") {
      LocalCookie = "Cookie: " + LocalCookie;
      IpClearCookies(IpHttpProvider1->HttpClient->RequestFields);
      IpHttpProvider1->HttpClient->RequestFields->Add(LocalCookie);
    }

    IpParseURL(URL, CurAddr);
    IpHTMLPanel1->OpenURL(LocalURL);
    UpdateTreeview();
  }
  else {
    ShowMessage("Cannot locate URL: """ + LocalURL + """");
    Screen->Cursor = crDefault;
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::FormCreate(TObject *Sender)
{
  CurCtrl = NULL;
  LoadHistory();
  Panel5->Width = 1;
  Cookies = new TIpCookieCacheList(CookieFileName);
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::FormDestroy(TObject *Sender)
{
  SaveHistory(true);
  Cookies->SaveCookiesToFile(CookieFileName);
  delete Cookies;
}
//---------------------------------------------------------------------------
AnsiString __fastcall TfrmBrowsr0::GetCurUrl( void )
{
  return ComboBox1->Text;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::HTMLClipboardCopy( void )
{
  IpHTMLPanel1->CopyToClipboard();
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::HTMLSelectAll( void )
{
  IpHTMLPanel1->SelectAll();
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::SetCurUrl( AnsiString Value )
{
  if (CurUrl != Value) {
    TIpAddrRec NewAddr;
    IpParseURL(Value, NewAddr);

    if (NewAddr.Authority != CurAddr.Authority) {
      IpHttpProvider1->Authenticate = false;
      Authenticated = false;
    }

    CurAddr = NewAddr;
    LastUrl = ComboBox1->Text;
    ComboBox1->Text = Value;
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::SetStatus( AnsiString StatStr )
{
  lblHot->Caption = StatStr;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnBackClick(TObject *Sender)
{
  DoGoBack();
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnForwardClick(TObject *Sender)
{
  DoGoForward();
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnSaveAsClick(TObject *Sender)
{
  TIpHtmlNodeIMG* IMG = dynamic_cast<TIpHtmlNodeIMG *>(IpHTMLPanel1->CurElement->Owner);

  if ((IpHTMLPanel1->CurElement) &&
   (IpHTMLPanel1->CurElement->Owner) &&
   (IMG))
  {
    SaveDialog1->FileName = ExtractEntityName(IMG->Src);
    if (SaveDialog1->Execute()) {
      Screen->Cursor = crHourGlass;
      IMG->Picture->SaveToFile(SaveDialog1->FileName);
    }
  }

  else {
  if ((IpHTMLPanel1->HotURL != "")) {
    AnsiString HotUrl = BuildURL(LastUrl, IpHTMLPanel1->HotURL);
    CurUrl = LastUrl;

    SaveDialog1->FileName = ExtractEntityName(HotUrl);
    if (SaveDialog1->Execute()) {
      Screen->Cursor = crHourGlass;
      TIpHttpClient* TempHttp = new TIpHttpClient(NULL);
      TempHttp->GetWait(HotUrl);

      dynamic_cast<TIpDownloadFileStream *>(TempHttp->BodyStream[HotUrl])->Move(SaveDialog1->FileName);

      TempHttp->FreeLink(HotUrl);
      delete TempHttp;
    }
  }}
  Screen->Cursor = crDefault;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnCopyClick(TObject *Sender)
{
  HTMLClipboardCopy();
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnEdit_CopyClick(TObject *Sender)
{
  HTMLClipboardCopy();
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnEdit_SelectAllClick(TObject *Sender)
{
  HTMLSelectAll();
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnFile_OpenPageClick(TObject *Sender)
{
  Boolean IsNewURL;
  AnsiString NewURL;

  NewURL = CurUrl  ;
  IsNewURL = InputQuery("Open Page", "Enter the URL you would like to open",
    NewURL );
  if(IsNewURL)
    DoOpenPage( NewURL );
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnFile_ExitClick(TObject *Sender)
{
  IpHTMLPanel1->Stop();
  IpHttpProvider1->Cancel();
  Close();
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnEdit_PreferencesClick(TObject *Sender)
{
  LoadPreferences();
  if( frmBrowConfig->ShowModal() == mrOk ){
    SavePreferences();
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnView_PageSourceClick(TObject *Sender)
{
  if( IpHttpProvider1->ViewCopy )
    ViewHTMLSource( IpHttpProvider1->ViewCopy );
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::SavePreferences()
{
  AnsiString S;
  BrowsrIni = new TIniFile( ExtractFilePath( Application->ExeName ) + INIFileName );

  S = frmBrowConfig->Edit1->Text;
  BrowsrIni->WriteString("Init", "DefaultPage", S);
  DefaultPage = S;

  S = frmBrowConfig->Edit7->Text;
  BrowsrIni->WriteString("Init", "DefaultGraphic", S);
  IpHttpProvider1->DefaultGraphic = S;

  S = frmBrowConfig->Edit6->Text;
  if (!DirExists(S)) {
    ShowMessage("Directory does not exist using default");
    S.SetLength(255);
    DWORD L = GetTempPath(255, &S[1]);
    S.SetLength(L);
  }
  BrowsrIni->WriteString("Init", "CacheDir", S);
  IpCache1->CacheDir = S;

  S = IntToStr((int)frmBrowConfig->CSpinEdit1->Value);
  BrowsrIni->WriteString("Init", "MaxHistoryAge", S);

  S = frmBrowConfig->Edit2->Text;
  BrowsrIni->WriteString("Colors", "TextColor", S);
  IpHTMLPanel1->TextColor = StringToColor(S);

  S = frmBrowConfig->Edit3->Text;
  BrowsrIni->WriteString("Colors", "LinkColor", S);
  IpHTMLPanel1->LinkColor = StringToColor(S);

  S = frmBrowConfig->Edit4->Text;
  BrowsrIni->WriteString("Colors", "ActiveLinkColor", S);
  IpHTMLPanel1->ALinkColor = StringToColor(S);

  S = frmBrowConfig->Edit5->Text;
  BrowsrIni->WriteString("Colors", "VisitedLinkColor", S);
  IpHTMLPanel1->VLinkColor = StringToColor(S);

  switch (frmBrowConfig->CheckBox1->Checked) {
    case false:
      S = "0";
      break;
    case true:
      S = "1";
      break;
  }
  BrowsrIni->WriteString("Init", "AutoOpen", S);

  delete BrowsrIni;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::LoadPreferences()
{
  AnsiString Dir;
  AnsiString S;
  DWORD L;

  BrowsrIni = new TIniFile( ExtractFilePath( Application->ExeName )
    + INIFileName );

  Dir.SetLength(255);
  L = GetWindowsDirectory(&Dir[1], 255);
  Dir.SetLength(L);

  S = BrowsrIni->ReadString( "Init", "DefaultGraphic",
    AppendBackSlash(Dir) + "arches.bmp");
  IpHttpProvider1->DefaultGraphic = S;
  frmBrowConfig->Edit7->Text = S;

  Dir = BrowsrIni->ReadString("Init", "CacheDir", "");
  try {
    IpHttpProvider1->Cache->CacheDir = Dir;
  }
  catch (...) {
    ShowMessage("Directory does not exist using default");
    Dir.SetLength(255);
    L = GetTempPath(255, &Dir[1]);
    Dir.SetLength(L);
    IpHttpProvider1->Cache->CacheDir = Dir;
  }
  frmBrowConfig->Edit6->Text = Dir;

  S = BrowsrIni->ReadString("Init", "MaxHistoryAge", IntToStr(DefMaxHistAge));
  MaxHistAge = StrToInt(S);
  frmBrowConfig->CSpinEdit1->Value = MaxHistAge;

  S = BrowsrIni->ReadString( "Colors", "TextColor", "clBlack" );
  IpHTMLPanel1->TextColor    = StringToColor( S );
  frmBrowConfig->Edit2->Text = S                 ;

  S = BrowsrIni->ReadString( "Colors", "LinkColor", "clBlue" );
  IpHTMLPanel1->LinkColor    = StringToColor( S );
  frmBrowConfig->Edit3->Text = S                 ;

  S = BrowsrIni->ReadString( "Colors", "ActiveLinkColor", "clRed" );
  IpHTMLPanel1->ALinkColor   = StringToColor( S );
  frmBrowConfig->Edit4->Text = S                 ;

  S = BrowsrIni->ReadString( "Colors", "VisitedLinkColor", "clMaroon" );
  IpHTMLPanel1->VLinkColor   = StringToColor( S );
  frmBrowConfig->Edit5->Text = S                 ;

  S = BrowsrIni->ReadString( "Init", "DefaultPage", "http://linux.turbopower.com/" );

//  AutoOpen = BrowsrIni->ReadBool( "Init", "AutoOpen", false );
  AutoOpen = (BrowsrIni->ReadString("Init", "AutoOpen", "0") == "1");

  DefaultPage = S;
  CurUrl = S;
  frmBrowConfig->Edit1->Text = S;

  delete BrowsrIni;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::FormShow(TObject *Sender)
{
  LoadPreferences();

  // many HTTP servers behave oddly if an HTTP request doesn't identify
  // itself as coming from some form of Mozilla
  IpHttpProvider1->HttpClient->RequestFields->Add("User-Agent: Mozilla");

  // iPRO's HTTP functionality doesn't presently support Keep-Alive
  IpHttpProvider1->HttpClient->RequestFields->Add("Connection: Close");


  if(( AutoOpen ) && ( CurUrl != "" ))
    DoOpenPage( CurUrl );
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnFile_OpenLocalFileClick(TObject *Sender)
{
  OpenDialog1->InitialDir = ExtractFilePath(Application->ExeName);
  if(OpenDialog1->Execute()) {
    DoOpenPage("file://" + OpenDialog1->FileName);
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::Memo1DblClick(TObject *Sender)
{
  Memo1->Lines->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnView_EventsClick(TObject *Sender)
{
  mnView_Events->Checked = !( mnView_Events->Checked );
  if( mnView_Events->Checked ){
    mnView_HTMLTree->Checked = False;
    TreeView1->Visible       = False;
    Memo1->Visible           = True ;
    Panel5->Width            = 200  ;
  }

  if(( !mnView_Events->Checked ) && ( !mnView_HTMLTree->Checked ))
    Panel5->Width = 0;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnView_HTMLTreeClick(TObject *Sender)
{
  mnView_HTMLTree->Checked = !mnView_HTMLTree->Checked;
  if( mnView_HTMLTree->Checked ){
    mnView_Events->Checked = false;
    TreeView1->Visible     = true ;
    Memo1->Visible         = false;
    Panel5->Width          = 200  ;
  }

  if(( !mnView_Events->Checked ) && ( !mnView_HTMLTree->Checked ))
    Panel5->Width = 0;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::TreeView1Compare(TObject *Sender,
      TTreeNode *Node1, TTreeNode *Node2, int Data, int &Compare)
{
  if( Node1->Index < Node2->Index ) {
    Compare = -1;
  }
  else {
  if( Node1->Index > Node2->Index ) {
    Compare =  1;
  }
  else {
    Compare =  0;
  }}
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::AddNode(TIpHtmlNode* Node, TTreeNode* Parent)
{
  TTreeNode* N =
    TreeView1->Items->AddChildObject(Parent, Node->ClassName(), Node);

  TIpHtmlNodeMulti* NodeMulti = dynamic_cast<TIpHtmlNodeMulti*>(Node);

  if(NodeMulti){
    for(int i = 0; i < NodeMulti->ChildCount; i++) {
      AddNode(NodeMulti->ChildNode[i], N);
    }
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::PopulateOutline(TIpHtml* H)
{
  if (H) {
    AddNode(H->HtmlNode, NULL);
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::EnumNodes(TIpHtmlNode* Node, int Level)
{
  int i;
  AnsiString S = "";

  for (i = 0; i < Level; i++) {
    S = S + " ";
  }
  S = S + Node->ClassName();
  NodeFile->Add(S);

  TIpHtmlNodeMulti* NodeMulti = dynamic_cast<TIpHtmlNodeMulti *>(Node);
  if (NodeMulti) {
    for (i = 0; i < NodeMulti->ChildCount; i++) {
      EnumNodes(NodeMulti->ChildNode[i], Level + 1);
    }
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::EnumDocument(TIpHtml* H)
{
  if (H) {
    EnumNodes(H->HtmlNode, 0);
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnFile_SaveNodeHierarchyClick(
      TObject *Sender)
{
  if (SaveDialog1->Execute()) {
    NodeFile = new TStringList;
    IpHTMLPanel1->EnumDocuments(EnumDocument);
    NodeFile->SaveToFile(SaveDialog1->FileName);
    delete NodeFile;
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnFile_SavePageSourceClick(TObject *Sender)
{
  TMemoryStream* tmp = dynamic_cast<TMemoryStream *>(IpHttpProvider1->ViewCopy);
  if (SaveDialog1->Execute()) {
    if ((tmp) && (tmp->Size > 0)) {
      tmp->SaveToFile(SaveDialog1->FileName);
    }
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::IpHttpProvider1RequestDone(TObject *Sender,
      const AnsiString Url, TIpAbstractNetRequest *Provider)
{
  Screen->Cursor = crDefault;
  SetStatus("Done.");
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::IpHttpProvider1RequestStart(TObject *Sender,
      const AnsiString Url, TIpAbstractNetRequest *Provider)
{
  Screen->Cursor = crHourGlass;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::IpHTMLPanel1HotChange(TObject *Sender)
{
  SetStatus(IpHTMLPanel1->HotURL);
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnEdit_ClearHistoryClick(TObject *Sender)
{
  AnsiString S = ComboBox1->Text;
  ComboBox1->Items->Clear();
  SaveHistory(false);
  ComboBox1->Items->Add(S);
  ComboBox1->Text = S;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::IpHttpProvider1RequestStatus(TObject *Sender,
      TIpAbstractNetRequest *Provider, const AnsiString ReqType,
      const AnsiString Url, const AnsiString Code,
      const AnsiString Message, const AnsiString Param)
{
  Memo1->Lines->Add( ReqType + '(' + Code + ")::" + Url + '"' + Message + '"');
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::FormCloseQuery(TObject *Sender,
      bool &CanClose)
{
  IpHTMLPanel1->Stop();
  IpHttpProvider1->Cancel();
  CanClose = true;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnFile_PrintPageClick(TObject *Sender)
{
  PrintDialog1->MinPage = 0;
  PrintDialog1->MaxPage = IpHTMLPanel1->GetPrintPageCount() - 1;
  PrintDialog1->FromPage = 1;
  PrintDialog1->ToPage =  IpHTMLPanel1->GetPrintPageCount();

  TPrinter* Prntr = Printer();
  if (PrintDialog1->Execute()) {
    Prntr->Copies = PrintDialog1->Copies;
    IpHTMLPanel1->Print(PrintDialog1->FromPage - 1, PrintDialog1->ToPage - 1);
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::IpHTMLPanel1Click(TObject *Sender)
{
  IpHTMLPanel1->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
  if (CurCtrl) {
   return;
  }

  TShiftState SS;
  SS.Clear();

  Set <WORD, 0, 0xFFFF> Keys;
  Keys << VK_UP << VK_DOWN << VK_LEFT << VK_RIGHT <<
          VK_HOME << VK_END << VK_PRIOR << VK_NEXT;

  if ((Shift == SS) && (Keys.Contains(Key))) {
    /*if we get here, this is a key we want to handle*/
    switch (Key) {
      case VK_HOME :
        IpHTMLPanel1->Scroll(hsaHome);
        break;
      case VK_END :
        IpHTMLPanel1->Scroll(hsaEnd);
        break;
      case VK_PRIOR :
        IpHTMLPanel1->Scroll(hsaPgUp);
        break;
      case VK_NEXT :
        IpHTMLPanel1->Scroll(hsaPgDn);
        break;

      case VK_UP:
        IpHTMLPanel1->Scroll(hsaUp);
        break;
      case VK_DOWN:
        IpHTMLPanel1->Scroll(hsaDown);
        break;
      case VK_LEFT:
        IpHTMLPanel1->Scroll(hsaLeft);
        break;
      case VK_RIGHT:
        IpHTMLPanel1->Scroll(hsaRight);
        break;
    }
    Key = 0;
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::FormKeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
  if (CurCtrl) {
    return;
  }

  TShiftState SS;
  SS.Clear();

  Set <WORD, 0, 0xFFFF> Keys;
  Keys << VK_UP << VK_DOWN << VK_LEFT << VK_RIGHT <<
          VK_HOME << VK_END << VK_PRIOR << VK_NEXT;

  if ((Shift == SS) && (Keys.Contains(Key))) {
    /*set key as handled*/
    Key = 0;
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::FocusedCtrlEnter(TObject *Sender)
{
  TControl* TC = dynamic_cast<TControl *>(Sender);
  if (TC) {
    CurCtrl = TC;
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::FocusedCtrlExit(TObject *Sender)
{
  CurCtrl = NULL;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::Panel1Resize(TObject *Sender)
{
  ComboBox1->Width = Panel1->Width - ComboBox1->Left - 10;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::IpHttpProvider1GetHtml(TObject *Sender,
      const AnsiString URL, const TIpFormDataEntity *PostData,
      TStream *&Stream)
{
  Screen->Cursor = crHourGlass;

  SetStatus("Downloading from " + URL + " ...");
  try {
    AddToHistory(CurUrl);
    CurUrl = URL;

    AnsiString LocalCookie = Cookies->BuildCookie(URL, 0);
    if (LocalCookie != "") {
      LocalCookie = "Cookie: " + LocalCookie;
      IpClearCookies(IpHttpProvider1->HttpClient->RequestFields);
      IpHttpProvider1->HttpClient->RequestFields->Add(LocalCookie);
    }



    Stream = IpHttpProvider1->GetHtmlStream(URL, const_cast<TIpFormDataEntity *>(PostData));  //!!!!!!!!!
  }
  __finally {
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::UpdateTreeview()
{
  TreeView1->Selected = 0;
  TreeView1->Items->Clear();
  IpHTMLPanel1->EnumDocuments(&PopulateOutline);
  TreeView1->FullExpand();
  if (TreeView1->Items->Count > 0) {
    TreeView1->Selected = TreeView1->Items->Item[0];
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::AddToHistory(AnsiString URL)
{
  Boolean Found = False;
  for (int i = 0; i < HistList->Count; i++) {
    if (AnsiCompareText(URL,HistList->Names[i]) == 0){
      Found = true;
    }
  }

  if (!Found) {
    HistList->Add(URL + "=" + DateToStr(Date()));
    UpdateCombo(URL);
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::UpdateCombo(AnsiString URL)
{
  ComboBox1->Items->Clear();
  for (int i = 0; i < HistList->Count; i++) {
    ComboBox1->Items->Add(HistList->Names[i]);
  }
  ComboBox1->ItemIndex = ComboBox1->Items->IndexOf(URL);
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::LoadHistory( void )
{
  if (!HistList) {
    HistList = new TStringList;
    HistList->Sorted = true;
    HistList->Duplicates = dupIgnore;
  }

  if (FileExists(ExtractFilePath(Application->ExeName) + HistoryFileName)) {
    HistList->LoadFromFile(ExtractFilePath(Application->ExeName) +
      HistoryFileName);
  }
  UpdateCombo(DefaultPage);
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::SaveHistory(Boolean Done)
{
  for (int i = 0; i < HistList->Count; i++) {
    TDateTime D = StrToDate(HistList->Values[HistList->Names[i]]);
    if ((double)(Date() - D) > MaxHistAge) {  //!!!!!!!!!!!!
        HistList->Delete(i);
    }
  }

  HistList->SaveToFile(ExtractFilePath(Application->ExeName) + HistoryFileName);
  if (Done) {
    delete HistList;
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::SocketError(TObject *Sender,
      unsigned int Socket, int ErrCode, const AnsiString ErrStr)
{
  ErrorCode = ErrCode;
  dynamic_cast<TIpMultiClient *>(Sender)->CloseSocket(Socket);
  SocketDone = true;
}
//---------------------------------------------------------------------------
Boolean  __fastcall TfrmBrowsr0::IsValidUrl(AnsiString URL)
{

  TRegistry* Reg;
  TIpAddrRec AddrRec;
  TIpHttpClient* TestUrl;
  TIpFtpClient* TestFtp;

//  Initialize(AddrRec);
  IpParseURL(URL, AddrRec);

  if (AddrRec.Scheme == "") {
    AddrRec.Scheme = "HTTP";
    URL = "HTTP://" + URL;
  }

  // Protocol specific validations
  if (CompareText(AddrRec.Scheme, "HTTP") == 0) {
    try {
      ErrorCode = 0;
      TestUrl = new TIpHttpClient(NULL);
      TestUrl->OnError = SocketError; //!!!!!!!!!
      TestUrl->HeadWait(URL);
      return ((ErrorCode == 0) && (TestUrl->HeaderDat[URL]->Size > 0));
    }
    __finally {
      delete TestUrl;
    }
  }

  else {
  if (CompareText(AddrRec.Scheme, "FTP") == 0) {
    TestFtp = new TIpFtpClient(NULL);
    // needs work
    delete TestFtp;
    return  true;
  }

  else {
  if (CompareText(AddrRec.Scheme, "FILE") == 0) {
    return FileExists(NetToDOSPath(AddrRec.Path));
  }

  else {
  if ((CompareText(AddrRec.Scheme, "MAILTO") == 0)) {
    Reg = NULL;
    try {
      Reg = new TRegistry;
      Reg->RootKey = HKEY_CLASSES_ROOT;
      return (Reg->OpenKey("MAILTO", true));
    }
    __finally {
      Reg->CloseKey();
      delete Reg;
    }
  }

  else {
  if ((CompareText(AddrRec.Scheme, "NEWS") == 0)) {
    Reg = NULL;
    try {
      Reg = new TRegistry;
      Reg->RootKey = HKEY_CLASSES_ROOT;
      return (Reg->OpenKey("NEWS", true));
    }
    __finally {
      Reg->CloseKey();
      delete Reg;
    }
  }

  else {
    return false;
  }}}}}

  return false;
//  Finalize(AddrRec);
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::IpHttpProvider1ReportReference(
      TObject *Sender, const AnsiString URL)
{
  Memo1->Lines->Add("Reference: " + URL);
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::IpHttpProvider1GotCookie(TObject *Sender,
      const AnsiString URL, TStrings *Data)
{

  for (int i = 0; i < Data->Count; i++) {
    Cookies->AddCookie(URL, Data->Strings[i]);
  }

  AnsiString LocalCookie = Cookies->BuildCookie(URL, 0);
  if (LocalCookie != "") {
    LocalCookie = "Cookie: " + LocalCookie;
    IpClearCookies(IpHttpProvider1->HttpClient->RequestFields);
    IpHttpProvider1->HttpClient->RequestFields->Add(LocalCookie);
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::IpHttpProvider1AuthenticationChallenge(
      TObject *Sender, const AnsiString URL, TStrings *Data)
{
  if (KnownChallenge("Basic", Data)) {

    if (!Authenticated) {
      AnsiString UName;
      AnsiString Pswd;
      TModalResult Rslt = LoginDialog("", "", UName, Pswd);
      if (Rslt == mrOk) {
        IpHttpProvider1->UserID = UName;
        IpHttpProvider1->Password = Pswd;
        IpHttpProvider1->Authenticate = True;
        Authenticated = True;
      }
    }
  }
  else {
    ShowMessage("Unhandled Challenge Type");
  }
}
//---------------------------------------------------------------------------

