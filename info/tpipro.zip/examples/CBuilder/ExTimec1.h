//---------------------------------------------------------------------------
#ifndef ExTimec1H
#define ExTimec1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpSock.hpp"
#include "IpTime.hpp"
#include "IpUtils.hpp"
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TSpeedButton *btnPoll;
    TStatusBar *StatusBar1;
    TEdit *edtServer;
    TRadioGroup *rgTimeService;
    TGroupBox *gbPolling;
    TLabel *Label2;
    TEdit *edtPollInterval;
    TRadioGroup *rgProtocol;
    TIpTimeClient *IpTimeClient1;
    TLabel *Label3;
    TComboBox *cbxLocalHost;
    void __fastcall btnPollClick(TObject *Sender);
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall rgTimeServiceClick(TObject *Sender);
    void __fastcall rgProtocolClick(TObject *Sender);
    void __fastcall edtPollIntervalExit(TObject *Sender);
    void __fastcall IpTimeClient1Time(TObject *Sender, TDateTime TimeStamp);
    void __fastcall cbxLocalHostDropDown(TObject *Sender);
    void __fastcall cbxLocalHostChange(TObject *Sender);
    void __fastcall IpTimeClient1Daytime(TObject *Sender,
          const AnsiString TimeStamp);
private:	// User declarations
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
