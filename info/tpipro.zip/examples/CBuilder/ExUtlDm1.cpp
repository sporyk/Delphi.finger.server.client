// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ExUtlDm1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpMupc"
#pragma link "IpSock"
#pragma link "IpUtils"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::rgServiceClick(TObject *Sender)
{
  IpUtilityServer1->Service = (TIpUtilityService)rgService->ItemIndex;
  rgService->ItemIndex = (int)IpUtilityServer1->Service;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::rgProtocolClick(TObject *Sender)
{
  IpUtilityServer1->SockProtocol = (TIpSockProtocol)rgProtocol->ItemIndex;
  rgProtocol->ItemIndex = (int)IpUtilityServer1->SockProtocol;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  chkActive->Checked = IpUtilityServer1->Active;
  rgService->ItemIndex = (int)IpUtilityServer1->Service;
  rgProtocol->ItemIndex = (int)IpUtilityServer1->SockProtocol;
  cbxLocalHostDropDown(0);
  cbxLocalHost->ItemIndex = IpUtilityServer1->DefaultLocalAddress;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::chkActiveClick(TObject *Sender)
{
  IpUtilityServer1->Active = chkActive->Checked;
  chkActive->Checked = IpUtilityServer1->Active;
  cbxLocalHost->Enabled = !IpUtilityServer1->Active;
  rgProtocol->Enabled = !IpUtilityServer1->Active;
  rgService->Enabled = !IpUtilityServer1->Active;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::cbxLocalHostChange(TObject *Sender)
{
  IpUtilityServer1->DefaultLocalAddress = cbxLocalHost->ItemIndex;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::cbxLocalHostDropDown(TObject *Sender)
{
  cbxLocalHost->Items->BeginUpdate();
  cbxLocalHost->Items->Clear();
  for (int i = 0; i < IpUtilityServer1->HostAddressCount; i++)
    cbxLocalHost->Items->Add(IpUtilityServer1->HostAddress[i]);
  cbxLocalHost->Items->EndUpdate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpUtilityServer1Status(TObject *Sender,
      DWORD Socket, TIpStatusType Event, const TIpConnRec &Connection,
      const TIpSockStatRec &StatRec)
{
  switch (Event) {
    case stConnect :
      StatusBar1->Panels->Items[1]->Text =
        IpUtilityServer1->NetAddr2String(Connection.RemoteAddr);
      break;
    case stDisconnect :
      StatusBar1->Panels->Items[1]->Text = "";
      break;
  }
}
//---------------------------------------------------------------------------

