//---------------------------------------------------------------------------
#ifndef ChatSrv1H
#define ChatSrv1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpSock.hpp"
#include "IpUtils.hpp"
#include <ExtCtrls.hpp>

#define MAXCONNECTIONS 10
#define HELLO          1   
#define TALK           2
#define USERS          3
#define PRIVT          4

struct UserInfo{
  DWORD      Socket  ;
  AnsiString UserName;
};

//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TBevel *Bevel2;
    TLabel *Label3;
    TMemo *ServerMemo;
    TIpServer *IpServer1;
    void __fastcall IpServer1Status(TObject *Sender, DWORD Socket,
          TIpStatusType Event, const TIpConnRec &Connection,
          const TIpSockStatRec &StatRec);
    void __fastcall IpServer1ReadLine(TObject *Sender, DWORD Socket,
          const AnsiString Line);
private:	// User declarations
    UserInfo   SocketArray[ MAXCONNECTIONS ];
    bool __fastcall HaveName( AnsiString Name );
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
