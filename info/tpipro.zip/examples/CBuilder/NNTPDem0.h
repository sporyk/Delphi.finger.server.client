//---------------------------------------------------------------------------
#ifndef NNTPDem0H
#define NNTPDem0H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpMsg.hpp"
#include "IpNntp.hpp"
#include "IpSock.hpp"
#include "IpUtils.hpp"
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TfrmNNTPDemo : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label5;
    TLabel *lblNumMessages;
    TLabel *lblCurrentMessageNum;
    TListBox *ListBox1;
    TGroupBox *gbxRFC977;
    TButton *btnList;
    TButton *btnArticle;
    TButton *btnBody;
    TButton *btnHead;
    TButton *btnGroup;
    TButton *btnHelp;
    TButton *btnLast;
    TButton *btnNewGroups;
    TButton *btnNewNews;
    TButton *btnNext;
    TButton *btnPost;
    TButton *btnStat;
    TGroupBox *GroupBox1;
    TLabel *Label1;
    TLabel *Label3;
    TLabel *Label4;
    TEdit *edtNNTPAddress;
    TEdit *edtUserID;
    TEdit *edtPassword;
    TButton *btnConnect;
    TRadioGroup *rgpTask;
    TComboBox *cbxNewsGroups;
    TButton *btnClearListbox;
    TGroupBox *gbxDraftCommands;
    TGroupBox *GroupBox2;
    TButton *btnAuthorize;
    TButton *btnDate;
    TButton *btnList_Extensions;
    TButton *btnList_Distributions;
    TButton *btnList_Newsgroups;
    TButton *btnList_OverviewFmt;
    TGroupBox *GroupBox3;
    TButton *btnList_ActiveTimes;
    TButton *btnListGroup;
    TGroupBox *GroupBox4;
    TLabel *Label6;
    TLabel *Label7;
    TButton *btnSpecial;
    TButton *btnOver;
    TButton *btnPat;
    TEdit *edtRange;
    TEdit *edtHeader;
    TCheckBox *cbxPostingAllowed;
    TButton *btnSaveListbox;
    TCheckBox *CheckBox1;
    TIpNntpClient *IpNntpClient1;
    TSaveDialog *SaveDialog1;
    void __fastcall IpNntpClient1Article(TIpCustomNntpClient *Client,
          TIpNewsArticle *Article);
    void __fastcall IpNntpClient1MultiLineResponse(
          TIpCustomNntpClient *Client, TIpNntpStates ResponseTo,
          TStringList *ResponseList);
    void __fastcall IpNntpClient1Response(TIpCustomNntpClient *Client,
          TIpNntpStates ResponseTo, int Code, const AnsiString Response);
    void __fastcall IpNntpClient1StateChange(TIpCustomNntpClient *Client,
          TIpNntpStates NewState);
    void __fastcall IpNntpClient1TaskComplete(TIpCustomNntpClient *Client,
          TIpNntpTasks NewTask, TStringList *ResponseList);
    void __fastcall btnConnectClick(TObject *Sender);
    void __fastcall btnNewGroupsClick(TObject *Sender);
    void __fastcall btnListClick(TObject *Sender);
    void __fastcall btnGroupClick(TObject *Sender);
    void __fastcall btnHelpClick(TObject *Sender);
    void __fastcall btnNewNewsClick(TObject *Sender);
    void __fastcall btnArticleClick(TObject *Sender);
    void __fastcall btnHeadClick(TObject *Sender);
    void __fastcall btnBodyClick(TObject *Sender);
    void __fastcall btnLastClick(TObject *Sender);
    void __fastcall btnNextClick(TObject *Sender);
    void __fastcall btnStatClick(TObject *Sender);
    void __fastcall btnPostClick(TObject *Sender);
    void __fastcall btnAuthorizeClick(TObject *Sender);
    void __fastcall btnList_ExtensionsClick(TObject *Sender);
    void __fastcall btnList_NewsgroupsClick(TObject *Sender);
    void __fastcall btnDateClick(TObject *Sender);
    void __fastcall btnList_DistributionsClick(TObject *Sender);
    void __fastcall btnList_OverviewFmtClick(TObject *Sender);
    void __fastcall btnList_ActiveTimesClick(TObject *Sender);
    void __fastcall btnListGroupClick(TObject *Sender);
    void __fastcall btnOverClick(TObject *Sender);
    void __fastcall btnPatClick(TObject *Sender);
    void __fastcall btnSpecialClick(TObject *Sender);
    void __fastcall btnSaveListboxClick(TObject *Sender);
    void __fastcall btnClearListboxClick(TObject *Sender);
    void __fastcall CheckBox1Click(TObject *Sender);
    
private:	// User declarations
    void Add(String S);
    void ResetButtons(bool Connected);
public:		// User declarations
    __fastcall TfrmNNTPDemo(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmNNTPDemo *frmNNTPDemo;
//---------------------------------------------------------------------------
#endif
