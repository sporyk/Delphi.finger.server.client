//---------------------------------------------------------------------------
#ifndef ExUtlDm1H
#define ExUtlDm1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpMupc.hpp"
#include "IpSock.hpp"
#include "IpUtils.hpp"
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TStatusBar *StatusBar1;
    TRadioGroup *rgService;
    TRadioGroup *rgProtocol;
    TGroupBox *gbxLocalHost;
    TComboBox *cbxLocalHost;
    TCheckBox *chkActive;
    TIpUtilityServer *IpUtilityServer1;
    void __fastcall rgServiceClick(TObject *Sender);
    void __fastcall rgProtocolClick(TObject *Sender);
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall chkActiveClick(TObject *Sender);
    void __fastcall cbxLocalHostChange(TObject *Sender);
    void __fastcall cbxLocalHostDropDown(TObject *Sender);
    void __fastcall IpUtilityServer1Status(TObject *Sender, DWORD Socket,
          TIpStatusType Event, const TIpConnRec &Connection,
          const TIpSockStatRec &StatRec);
private:	// User declarations
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
