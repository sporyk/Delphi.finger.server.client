//---------------------------------------------------------------------------
#ifndef ExPop30H
#define ExPop30H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpMsg.hpp"
#include "IpPop3.hpp"
#include "IpSock.hpp"
#include "IpUtils.hpp"
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
#include <Grids.hpp>
#include <Menus.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TStatusBar *StatusBar1;
    TIpPop3Client *IpPop3Client1;
    TPopupMenu *PopupMenu1;
    TMenuItem *Delete1;
    TMenuItem *Download1;
    TMenuItem *Save1;
    TMenuItem *View1;
    TSaveDialog *SaveDialog1;
        TPanel *pnlTop;
        TGroupBox *GroupBox1;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TEdit *edtPop3Address;
        TEdit *edtUserName;
        TEdit *edtPassword;
        TCheckBox *cbxEncryptedLogon;
        TButton *btnCheckMessages;
        TCheckBox *cbxDownloadAll;
        TListBox *lbxStatus;
        TLabel *lblNumMessages;
        TLabel *lblMailBoxSize;
        TPanel *pnlBottom;
        TStringGrid *PreviewGrid;
        TCheckBox *cbEnableStatus;
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall btnCheckMessagesClick(TObject *Sender);
    void __fastcall IpPop3Client1TaskComplete(
          TIpCustomPop3Client *Client, TIpPop3Tasks Task,
          TStringList *Response);
    void __fastcall IpPop3Client1Message(TIpCustomPop3Client *Client,
          TIpMailMessage *Message);
    void __fastcall Delete1Click(TObject *Sender);
    void __fastcall Download1Click(TObject *Sender);
    void __fastcall Save1Click(TObject *Sender);
    void __fastcall IpPop3Client1StateChange(
          TIpCustomPop3Client *Client, TIpPop3States State);
    void __fastcall View1Click(TObject *Sender);
    
    void __fastcall PreviewGridMouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall PopupMenu1Popup(TObject *Sender);
    void __fastcall IpPop3Client1Progress(TIpCustomPop3Client *Client,
          DWORD CharsTransferred);
    void __fastcall IpPop3Client1Status(TObject *Sender, DWORD Socket,
          TIpStatusType Event, const TIpConnRec &Connection,
          const TIpSockStatRec &StatRec);
private:	// User declarations
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
