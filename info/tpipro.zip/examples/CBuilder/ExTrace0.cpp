// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ExTrace0.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpIcmp"
#pragma link "IpSock"
#pragma link "IpUtils"
#pragma resource "*.dfm"
TfrmExTrace *frmExTrace;
//---------------------------------------------------------------------------
__fastcall TfrmExTrace::TfrmExTrace(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmExTrace::btnTraceClick(TObject *Sender)
{
  lbxTrace->Items->Clear();
  lbxTrace->Items->Add("Starting trace to " + edtTraceAddress->Text);
  lbxTrace->Items->Add("*Hop RTT Address");
  IpIcmp1->Trace(edtTraceAddress->Text);
}
//---------------------------------------------------------------------------
void __fastcall TfrmExTrace::IpIcmp1TraceComplete(TIpCustomIcmp *Icmp,
      const TStringList *TraceList)
{
  lbxTrace->Items->Add("OnTraceComplete");
}
//---------------------------------------------------------------------------
void __fastcall TfrmExTrace::lbxTraceDrawItem(TWinControl *Control,
      int Index, TRect &Rect, TOwnerDrawState State)
{
  TCanvas *pCanvas = ((TListBox *)Control)->Canvas;
  if(State.Contains(odSelected)){
    pCanvas->Brush->Color = clHighlight;
    pCanvas->Font->Color = clHighlightText;
  } else {
    pCanvas->Brush->Color = clWindow;
    pCanvas->Font->Color = clWindowText;
  }
  pCanvas->FillRect(Rect);
  String Si = ((TListBox *)Control)->Items->Strings[Index];
  int Col1 = (Rect.Right - Rect.Left) / 6;
  int Col2 = (Rect.Right - Rect.Left) / 3;

  // extract the hop number
  String S = lbxTrace->Items->Strings[Index];
  if ((S.Length() > 1) && (S.Pos("*") == 1)){
    String Str = S.SubString(2, S.Pos(" ") - 1);
    pCanvas->TextOut(Rect.Left, Rect.Top, Str);
    // extract the round-trip time
    S = S.SubString(Str.Length() + 2, S.Length());
    Str = S.SubString(1, S.Pos(" ") - 1);
    pCanvas->TextOut(Col1, Rect.Top, Str);
    // extract the address
    Str = S.SubString(S.Pos(" ") + 1, S.Length());
    pCanvas->TextOut(Col2, Rect.Top, Str);
  } else
    pCanvas->TextOut(Rect.Left, Rect.Top, S);
}
//---------------------------------------------------------------------------
void __fastcall TfrmExTrace::IpIcmp1IcmpEcho(TIpCustomIcmp *Icmp,
      const TIpExtendedEchoInfo *EchoInfo, const AnsiString EchoFrom)
{
  String S = "*" + IntToStr(EchoInfo->HopNumber) + ' ' +
    IntToStr(EchoInfo->Echo->RTTime) + ' ' + EchoFrom;
  lbxTrace->Items->Add(S);      
}
//---------------------------------------------------------------------------

