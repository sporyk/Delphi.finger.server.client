// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ChatCl1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpSock"
#pragma link "IpUtils"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Client1ConClick(TObject *Sender)
{
  Client1Con->Enabled = false;

  if( Client1Edt2->Text == "" ){
    ShowMessage( "No server specified." );
    Client1Con->Enabled = true;
  }else if( UserEdit1->Text == "" ){
    ShowMessage( "No User Name specified." );
    Client1Con->Enabled = true;
  }else{
    AnsiString tmp_str;
    tmp_str =  Client1Edt2->Text + ":5389";
    IpClient1->ConnectSocket( tmp_str );
    // save server id for later use
    Server_str1 = tmp_str;
  }
    
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpClient1Status(TObject *Sender, DWORD Socket,
      TIpStatusType Event, const TIpConnRec &Connection,
      const TIpSockStatRec &StatRec)
{
  switch( Event ) {
    case stConnect :
      Client1Con->Enabled        = false                       ;
      UserEdit1->Enabled         = false                       ;
      Client1Edt2->Enabled       = false                       ;
      Client1Disconnect->Enabled = true                        ;
      Client1Send->Enabled       = true                        ;
      Client1Edt->Enabled        = true                        ;
      Client1Con->Default        = false                       ;
      Client1Send->Default       = true                        ;
      Client1Edt->SetFocus()                                   ;
      Cllient1List->Items->Add( "Connected to " + Server_str1 );
      ConnectLbl->Caption     = "Connected to " + Server_str1  ;
      Client1LstBx->ItemIndex = Client1LstBx->Items->Count - 1 ;
      {
        // since we have a connection give user name
        AnsiString tmp_str = IntToStr( HELLO ) + UserEdit1->Text + "\r\n";
        IpClient1->PutString( tmp_str, false );
      }
    break;
    case stDisconnect :
      Cllient1List->Clear()                                         ;
      Client1LstBx->Clear()                                         ;
      Client1Con->Enabled        = true                             ;
      UserEdit1->Enabled         = true                             ;
      Client1Edt2->Enabled       = true                             ;
      Client1Disconnect->Enabled = false                            ;
      Client1Send->Enabled       = false                            ;
      Client1Edt->Enabled        = false                            ;
      Client1Con->Default        = true                             ;
      Client1Send->Default       = false                            ;
      Client1Edt2->SetFocus()                                       ;
      Cllient1List->Items->Add( "Disconnected from " + Server_str1 );
      ConnectLbl->Caption     = "Connected to "                     ;
      Client1LstBx->ItemIndex = Client1LstBx->Items->Count - 1      ;

    break;
    case stProgress :
    break;
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpClient1Error(TObject *Sender, DWORD Socket,
      int ErrCode, const AnsiString ErrStr)
{
   IpClient1->CloseSocket()          ;

   // note : this assumes that all errors are very bad
   Cllient1List->Items->Add( ErrStr ) ;

   Client1Con->Enabled        = true ;
   UserEdit1->Enabled         = true ;
   Client1Disconnect->Enabled = false;
   Client1Send->Enabled       = false;
   Client1Edt->Enabled        = false;

}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpClient1ReadLine(TObject *Sender, DWORD Socket,
      const AnsiString Line)
{
  try{
    int tmp_int = StrToInt( Line.SubString( 0, ( 1 )));
    switch( tmp_int ){
      case USERS :
        {
          Client1LstBx->Clear();

          AnsiString tmp_str1 = Line                     ;
          AnsiString tmp_str2                            ;
          int tmp_int2        = tmp_str1.Pos( "\t" ) - 1 ;
          tmp_int             = 2                        ;

          // parse out all the users and add them to the ListBox
          while( tmp_int2 ){
            tmp_str2 = tmp_str1.SubString( tmp_int, ( tmp_int2 - 1 ));
            if( tmp_str2 != "" ){
              // don't allow any control characters to be added
              for( int i = 1; i <= tmp_str2.Length(); i++ )
                if( iscntrl( tmp_str2[ i ] )) tmp_str2[ i ] = ' ';

              Client1LstBx->Items->Add( tmp_str2 );
            }
            tmp_str1 = tmp_str1.SubString( tmp_int2 + 1, ( Line.Length()));
            tmp_int  = 1                                                  ;
            tmp_int2 = tmp_str1.Pos( "\t" )                               ;
          }
        }
      break;
      case TALK  :
        {
          AddString( Line.SubString( 2, ( Line.Length( ))));
        }
        if( NotifyChkBx->Checked ) Beep();
      break;
      case PRIVT :
        {
          AddString( "Private message from " +
                   ( Line.SubString( 2, ( Line.Length( )))));
        }
        if( NotifyChkBx->Checked ) Beep();
      break;
      default:
      break;
    }
  }catch(...){
    // it may have not been what we expected
    // some error stuff should go here
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::AddString( const AnsiString Line )
{
  AnsiString tmp_str2 = Line;
  // don't allow any control characters to be added
  for( int i = 1; i <= tmp_str2.Length(); i++ )
    if( iscntrl( tmp_str2[ i ] )) tmp_str2[ i ] = ' ';

  Cllient1List->Items->Add( Line )                        ;
  Cllient1List->ItemIndex = Cllient1List->Items->Count - 1;
  Cllient1List->ItemIndex = -1                            ;

  // allow only 200 messages
  while( Cllient1List->Items->Count > 200 )
    Cllient1List->Items->Delete( 0 );
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Client1DisconnectClick(TObject *Sender)
{
  IpClient1->CloseSocket();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
  IpClient1->CloseSocket();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Client1SendClick(TObject *Sender)
{
  if( Client1Edt->Text != "" ){
    AnsiString tmp_str;
    // is it a private message
    if( ShhChkBox->Checked ){
      if( Client1LstBx->ItemIndex >= 0 ){
        tmp_str = IntToStr( PRIVT )                                       +
                  Client1LstBx->Items->Strings[ Client1LstBx->ItemIndex ] +
                  "\t"                                                    +
                  Client1Edt->Text                                        +
                  "\r\n"                                                  ;
      }else{
        ShowMessage( "No one is selected." );
      }                        
    }else{
      tmp_str = IntToStr( TALK ) + Client1Edt->Text + "\r\n";
    }
    IpClient1->PutString( tmp_str, false );
    Client1Edt->Clear();
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Client1EdtKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
  // this is here to stop that really annoying bell
  if( Key == 13 )
    Key = NULL;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Client1Edt2KeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
  // this is here to stop that really annoying bell
  if( Key == 13 )
    Key = NULL;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Cllient1ListDrawItem(TWinControl *Control,
      int Index, TRect &Rect, TOwnerDrawState State)
{
  // color different messages
  if( 0 != Cllient1List->Items->Count ){
    AnsiString S = Cllient1List->Items->Strings[ Index ];
    if( S.Pos( UserEdit1->Text + " :" )){
      Cllient1List->Canvas->Font->Color = clGreen;
    }else if( S.Pos( "Private message " )){
      Cllient1List->Canvas->Font->Color = clRed  ;
    }else{
    }
    Cllient1List->Canvas->TextRect(Rect, Rect.Left, Rect.Top, S);
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ShhChkBoxClick(TObject *Sender)
{
   // make a visual for private message
   if( ShhChkBox->Checked )
     Client1Edt->Color = clTeal  ;
   else
     Client1Edt->Color = clWindow;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ExitBtnClick(TObject *Sender)
{
  IpClient1->CloseSocket();
  Close();
}
//---------------------------------------------------------------------------



