//---------------------------------------------------------------------------
#ifndef SmplCS1H
#define SmplCS1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpSock.hpp"
#include "IpUtils.hpp"
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TBevel *Bevel1;
    TLabel *Label2;
    TBevel *Bevel2;
    TLabel *Label3;
    TLabel *ServerBytesRecvLbl;
    TLabel *ServerBytesSentLbl;
    TLabel *ClientBytesRecvLbl;
    TLabel *ClientBytesSentLbl;
    TListBox *ListBox1;
    TListBox *ListBox2;
    TButton *ConnectBtn;
    TButton *ClientSndBtn;
    TButton *ServerSndBtn;
    TEdit *ServerEdt;
    TEdit *ClientEdt;
    TButton *DisConnectBtn;
    TIpClient *IpClient1;
    TIpServer *IpServer1;
    void __fastcall IpServer1ReadLine(TObject *Sender, DWORD Socket,
          const AnsiString Line);
    void __fastcall IpClient1ReadLine(TObject *Sender, DWORD Socket,
          const AnsiString Line);
    void __fastcall IpServer1Status(TObject *Sender, DWORD Socket,
          TIpStatusType Event, const TIpConnRec &Connection,
          const TIpSockStatRec &StatRec);
    void __fastcall ConnectBtnClick(TObject *Sender);
    void __fastcall ClientSndBtnClick(TObject *Sender);
    void __fastcall ServerSndBtnClick(TObject *Sender);
    void __fastcall DisConnectBtnClick(TObject *Sender);
    void __fastcall IpClient1Status(TObject *Sender, DWORD Socket,
          TIpStatusType Event, const TIpConnRec &Connection,
          const TIpSockStatRec &StatRec);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
    void __fastcall FormCreate(TObject *Sender);
private:	// User declarations
    DWORD SrvSock;
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
