//---------------------------------------------------------------------------
#ifndef FinWhoD1H
#define FinWhoD1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpSock.hpp"
#include "IpUtils.hpp"
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include "IpMupc.hpp"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TRadioGroup *rgService;
    TGroupBox *gbxLocalHost;
    TComboBox *cbxLocalHost;
    TCheckBox *chkActive;
    TPanel *Panel1;
    TIpFingerWhoIsServer *IpFingerWhoIsServer1;
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall chkActiveClick(TObject *Sender);
    void __fastcall rgServiceClick(TObject *Sender);
    void __fastcall cbxLocalHostDropDown(TObject *Sender);
    void __fastcall cbxLocalHostChange(TObject *Sender);
    void __fastcall IpFingerWhoIsServer1Connect(TObject *Sender,
          bool &SendBanner);
    void __fastcall IpFingerWhoIsServer1Query(TObject *Sender,
          const AnsiString Query, AnsiString &Reply, bool &Disconnect);
private:	// User declarations
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
