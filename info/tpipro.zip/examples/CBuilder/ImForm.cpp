// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ImForm.h"
#include "ImSelect.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmIM *frmIM;
//---------------------------------------------------------------------------
__fastcall TfrmIM::TfrmIM(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmIM::btnClearClick(TObject *Sender)
{
  lbDialog->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TfrmIM::btnSendClick(TObject *Sender)
{
  AnsiString Str;
  bool x;

  x = false;
  Str = memoSendText->Lines->Strings[0];

  //responding to incoming message
  if (Str != "") {

    if ((Client->Protocol == pMSN) && (lbSession->Items->Count == 0)) {
      ShowMessage("First invite a user to the chat session");
      x = true;
    }

    if (x == false) {
    if (FToUser == NULL) {
      Client->SendMsg(FLoginID, FFriendlyName, Str);
      memoSendText->Lines->Clear();
    } else {
      Client->SendMsg(FToUser->LoginID, FToUser->FriendlyName, Str);
      memoSendText->Lines->Clear();
      }
    }
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmIM::btnInviteClick(TObject *Sender)
{
  TIpIMPresentity* p;

  Client->GetListItems(ltBuddy, frmSelectForSend->lbSelect->Items);
  if (frmSelectForSend->ShowModal() == mrOk) {
    p = Client->GetBuddy(frmSelectForSend->lbSelect->ItemIndex);
    Client->InviteChatUser(p->LoginID, Client->FriendlyName, "Join chat");
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmIM::FormHide(TObject *Sender)
{
  if (Client->ProtocolState >= psStartingChatSession)
    Client->LeaveChat();
}
//---------------------------------------------------------------------------
void __fastcall TfrmIM::FormShow(TObject *Sender)
{

  TIpIMPresentity* p;
  int i;

  if (Client != NULL)
    pnlSession->Visible = (Client->Protocol == pMSN);
  else
    pnlSession->Visible = false;

  if (Client != NULL) {
    Client->GetListItems(ltChatRoster, lbSession->Items);
    if (lbSession->Items->Count > 0) {
      for (i = 0 ; i <= lbSession->Items->Count - 1 ; i++) {
        p = Client->GetBuddy(i);
        Client->InviteChatUser(p->LoginID, "","");
      }
    }
  }
}
//---------------------------------------------------------------------------
