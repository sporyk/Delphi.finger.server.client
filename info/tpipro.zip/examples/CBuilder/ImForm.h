//---------------------------------------------------------------------------
#ifndef IMFormH
#define IMFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include "IpIM.hpp"

//---------------------------------------------------------------------------
class TfrmIM : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel1;
    TSpeedButton *btnInvite;
    TSpeedButton *btnClear;
    TPanel *Panel2;
    TPanel *Panel6;
    TButton *btnSend;
    TMemo *memoSendText;
    TPanel *Panel3;
    TPanel *pnlSession;
    TPanel *Panel4;
    TListBox *lbSession;
    TPanel *Panel5;
    TListBox *lbDialog;
    void __fastcall btnClearClick(TObject *Sender);
    void __fastcall btnSendClick(TObject *Sender);
    void __fastcall btnInviteClick(TObject *Sender);
    
    void __fastcall FormHide(TObject *Sender);
    void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
    TIpCustomIMClient* Client;
    TIpIMPresentity* FToUser;
    AnsiString FLoginID;
    AnsiString FFriendlyName;
    __fastcall TfrmIM(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmIM *frmIM;
//---------------------------------------------------------------------------
#endif
