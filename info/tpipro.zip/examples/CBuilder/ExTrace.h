//---------------------------------------------------------------------------
#ifndef ExTraceH
#define ExTraceH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpIcmp.hpp"
#include "IpSock.hpp"
#include "IpUtils.hpp"
//---------------------------------------------------------------------------
class TfrmExTrace : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TEdit *edtTraceAddress;
    TButton *btnTrace;
    TListBox *lbxTrace;
    TIpIcmp *IpIcmp1;
private:	// User declarations
public:		// User declarations
    __fastcall TfrmExTrace(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmExTrace *frmExTrace;
//---------------------------------------------------------------------------
#endif
