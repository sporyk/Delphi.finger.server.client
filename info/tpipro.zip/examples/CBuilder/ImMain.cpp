// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ImMain.h"
#include "ImAddCon.h"
#include "ImHelp.h"
#include "ImForm.h"
#include "ImProps.h"
#include "ImOpts.h"
#include "ImSelect.h"
#include "ImSignIn.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpIM"
#pragma link "IpSock"
#pragma link "IpUtils"
#pragma resource "*.dfm"
TfrmMain *frmMain;
//---------------------------------------------------------------------------
__fastcall TfrmMain::TfrmMain(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::FormShow(TObject *Sender)
{
  FCurrentContact = NULL;
  FCurrentContactOnLine = false;
  SetAllControls();
}
//---------------------------------------------------------------------------
void TfrmMain::SetAllControls(void)
{
  //Status bar
  if (IpIMClient1->ProtocolState == psLoggedOff)
    StatusBar1->Panels->Items[0]->Text = " Logged off";
  else
    StatusBar1->Panels->Items[0]->Text = " " + IpIMClient1->StateToString();

  //Protocol images
  if (IpIMClient1->Protocol == pMSN) {
    ImgAOL->Visible = false;
    ImgMSN->Visible = true;
  } else {
    ImgAOL->Visible = true;
    ImgMSN->Visible = false;
  }

  //speed buttons
  sbAddContact->Enabled = (IpIMClient1->ProtocolState > psRedirecting);
  sbDeleteContact->Enabled = (IpIMClient1->ProtocolState > psRedirecting);
  sbSendMessage->Enabled = (IpIMClient1->ProtocolState > psRedirecting);
  btnShowIM->Enabled = (IpIMClient1->ProtocolState > psRedirecting);

  //Main (file) menu items
  Signin1->Enabled = (IpIMClient1->ProtocolState == psLoggedOff);
  SignOut1->Enabled = (IpIMClient1->ProtocolState > psRedirecting);
  MyStatus1->Enabled = (IpIMClient1->ProtocolState > psRedirecting);
  Addcontact1->Enabled = (IpIMClient1->ProtocolState > psRedirecting);
  Deletecontact1->Enabled = (IpIMClient1->ProtocolState > psRedirecting);
  Exit1->Enabled = IpIMClient1->ProtocolState == psLoggedOff;

  //status sub-menu items
  switch (IpIMClient1->OnLineStatus)
  {
    case osOnLine : OnLine1->Checked = true; break;
    case osOffLine : OffLine1->Checked = true; break;
    case osHidden : Hidden1->Checked = true; break;
    case osBRB : Berightback1->Checked = true; break;
    case osOnPhone : Onthephone1->Checked = true; break;
    case osOutToLunch : Outtolunch1->Checked = true; break;
    case osBusy : Busy1->Checked = true; break;
    case osIdle : Idle1->Checked = true; break;
    case osAway : Away1->Checked = true; break;
  }

  //Main (tools) menu items
  SendIM1->Enabled = (IpIMClient1->ProtocolState > psRedirecting);
  Options1->Enabled = (IpIMClient1->ProtocolState == psLoggedOff);

  //OnLine popup menu items
  Sendmessage1->Enabled = (IpIMClient1->ProtocolState > psRedirecting);

  Delete1->Enabled = ((IpIMClient1->ProtocolState > psRedirecting) && (lbOnLine->ItemIndex >= 0));
  Block1->Enabled = ((IpIMClient1->ProtocolState > psRedirecting) && (lbOnLine->ItemIndex >= 0));
  Properties2->Enabled = ((IpIMClient1->ProtocolState > psRedirecting) && (lbOnLine->ItemIndex >= 0));

  //OffLine popup menu items
  Delete2->Enabled = ((IpIMClient1->ProtocolState > psRedirecting) && (lbOffLine->ItemIndex >= 0));
  Block2->Enabled = ((IpIMClient1->ProtocolState > psRedirecting) && (lbOffLine->ItemIndex >= 0));
  Properties3->Enabled = ((IpIMClient1->ProtocolState > psRedirecting) && (lbOffLine->ItemIndex >= 0));
  UpdateLists();
}
//---------------------------------------------------------------------------
void TfrmMain::UpdateLists(void)
{
  TStringList* Strs;
  int i;
  AnsiString OnLineItem;
  AnsiString OffLineItem;
  TIpIMPresentity* p;

  if (lbOnLine->ItemIndex >= 0)
    OnLineItem = lbOnLine->Items->Strings[lbOnLine->ItemIndex];
  else
    OnLineItem = "";


  if (lbOffLine->ItemIndex >= 0)
    OffLineItem = lbOffLine->Items->Strings[lbOffLine->ItemIndex];
  else
    OffLineItem = "";

  lbOnLine->Clear();
  lbOffLine->Clear();

  Strs = new(TStringList);
  IpIMClient1->GetListItems(ltBuddy, Strs);

  for (i = 0; i <= Strs->Count - 1; i++) {
    p = IpIMClient1->GetBuddy(i);
    if (p->OnLineStatus != osOffLine)
      lbOnLine->Items->Add(p->FriendlyName);
    else
      lbOffLine->Items->Add(p->FriendlyName);
  }

  delete(Strs);

  i = lbOffLine->Items->IndexOf(OffLineItem);
  if (i >= 0) {
    lbOffLine->ItemIndex = i;
//    lbOffLineClick(this);
  }

  i = lbOnLine->Items->IndexOf(OnLineItem);
  if (i >= 0) {
    lbOnLine->ItemIndex = i;
//    lbOnLineClick(this);
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::btnShowIMClick(TObject *Sender)
{
  frmIM->Client = IpIMClient1;
  frmIM->FToUser = FCurrentContact;
  if (frmIM->Visible == true)
    frmIM->Hide();
  else
    frmIM->Show();
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::sbSendMessageMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
  if (FCurrentContact != NULL)
    sbSendMessage->Hint = "Call " + FCurrentContact->FriendlyName;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::IpIMClient1RcvInstantMessage(
      TIpCustomIMClient *Client, AnsiString SenderID,
      AnsiString SenderFriendlyName, AnsiString Msg, AnsiString MsgRaw,
      bool &Accept)
{
  TStringList* TempList;
  int i;

  TempList = new(TStringList);
  TempList->Text = Msg;

  for (i = 0 ; i <= TempList->Count - 1; i++) {
    frmIM->lbDialog->Items->Add(SenderFriendlyName + ": " + TempList->Strings[i]);
    frmIM->lbDialog->ItemIndex = frmIM->lbDialog->Items->Count - 1;
  }

  delete(TempList);

  if (IpIMClient1->Protocol == pAIM) {
    frmIM->FLoginID = SenderID;
    frmIM->FFriendlyName = SenderFriendlyName;
    frmIM->FToUser = NULL;
    frmIM->Client = IpIMClient1;
    frmIM->Show();
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::IpIMClient1ProtocolError(
      TIpCustomIMClient *Client, int ErrCode, AnsiString ErrString)
{
  //Bad Password
  if (ErrCode == 911) {
    if (MessageDlg("Bad password or login ID. Retry?", mtConfirmation, TMsgDlgButtons() << mbYes << mbNo,0) == mrYes) {
    frmSignin->edtSignOnName->Text = IpIMClient1->LoginID;
    frmSignin->edtPassword->Text = IpIMClient1->Password;
    if (frmSignin->ShowModal() == mrOk) {
      IpIMClient1->LoginID = frmSignin->edtSignOnName->Text;
      IpIMClient1->Password = frmSignin->edtPassword->Text;
      IpIMClient1->Login();
      }
    }
  }
  else
    ShowMessage(ErrString);
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Block1Click(TObject *Sender)
{
  if (FCurrentContact != NULL)
    IpIMClient1->Block(FCurrentContact->LoginID, FCurrentContact->FriendlyName);
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Properties2Click(TObject *Sender)
{
  if (FCurrentContact != NULL) {
    frmMyProperties->lblConnection->Caption = "n/a";
    frmMyProperties->lblFriendlyName->Caption = FCurrentContact->FriendlyName;
    frmMyProperties->lblLoginName->Caption = FCurrentContact->LoginID;

    switch(FCurrentContact->OnLineStatus) {
      case osOnLine : frmMyProperties->lblOnLineStatus->Caption = "OnLine"; break;
      case osOffLine : frmMyProperties->lblOnLineStatus->Caption = "OffLine"; break;
      case osHidden : frmMyProperties->lblOnLineStatus->Caption = "Hidden"; break;
      case osBRB : frmMyProperties->lblOnLineStatus->Caption = "Be right back"; break;
      case osOnPhone : frmMyProperties->lblOnLineStatus->Caption = "On the phone"; break;
      case osOutToLunch : frmMyProperties->lblOnLineStatus->Caption = "Out to lunch"; break;
      case osBusy : frmMyProperties->lblOnLineStatus->Caption = "Busy"; break;
      case osIdle : frmMyProperties->lblOnLineStatus->Caption = "Idle"; break;
      case osAway : frmMyProperties->lblOnLineStatus->Caption = "Away"; break;
    }
  frmMyProperties->ShowModal();
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::PopupOnLinePopup(TObject *Sender)
{
  Sendmessage1->Enabled = ((FCurrentContact != NULL) && (IpIMClient1->Protocol == pAIM));
  Delete1->Enabled = (FCurrentContact != NULL);
  Block1->Enabled = (FCurrentContact != NULL);
  Properties2->Enabled = (FCurrentContact != NULL);
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::PopupOffLinePopup(TObject *Sender)
{
  Delete2->Enabled = (FCurrentContact != NULL);
  Block2->Enabled = (FCurrentContact != NULL);
  Properties3->Enabled = (FCurrentContact != NULL);
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Sendmessage1Click(TObject *Sender)
{
  frmIM->Client = IpIMClient1;
  frmIM->FToUser = FCurrentContact;
  frmIM->FFriendlyName = FCurrentContact->FriendlyName;
  frmIM->FLoginID = FCurrentContact->LoginID;
  frmIM->Show();
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::About1Click(TObject *Sender)
{
  frmHelp->ShowModal();
}
//---------------------------------------------------------------------------


void __fastcall TfrmMain::Properties1Click(TObject *Sender)
{
  AnsiString PortStr;

  PortStr = ":" + IntToStr(IpIMClient1->Port);

  frmMyProperties->lblConnection->Caption = IpIMClient1->URL + PortStr;
  frmMyProperties->lblFriendlyName->Caption = IpIMClient1->FriendlyName;
  frmMyProperties->lblLoginName->Caption = IpIMClient1->LoginID;

  switch(IpIMClient1->OnLineStatus) {
    case osOnLine : frmMyProperties->lblOnLineStatus->Caption = "OnLine"; break;
    case osOffLine : frmMyProperties->lblOnLineStatus->Caption = "OffLine"; break;
    case osHidden : frmMyProperties->lblOnLineStatus->Caption = "Hidden"; break;
    case osBRB : frmMyProperties->lblOnLineStatus->Caption = "Be right back"; break;
    case osOnPhone : frmMyProperties->lblOnLineStatus->Caption = "On the phone"; break;
    case osOutToLunch : frmMyProperties->lblOnLineStatus->Caption = "Out to lunch"; break;
    case osBusy : frmMyProperties->lblOnLineStatus->Caption = "Busy"; break;
    case osIdle : frmMyProperties->lblOnLineStatus->Caption = "Idle"; break;
    case osAway : frmMyProperties->lblOnLineStatus->Caption = "Away"; break;
  }
  frmMyProperties->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Options1Click(TObject *Sender)
{
  if (IpIMClient1->ProtocolState == psLoggedOff)
    frmOptions->lblStatus->Caption = "  Logged off  ";
  else
    frmOptions->lblStatus->Caption = "  Logged on  ";
  frmOptions->edtSignInName->Text = IpIMClient1->LoginID;
  frmOptions->edtPassword->Text = IpIMClient1->Password;
  frmOptions->edtServerAddress->Text = IpIMClient1->URL;
  frmOptions->edtServerPort->Text = IntToStr(IpIMClient1->Port);

  if (IpIMClient1->SocksServer->Address == "") {
    frmOptions->cbUseProxy->Checked = false;
    frmOptions->DisableProxyEdits();
  } else {
    frmOptions->EnableProxyEdits();
    frmOptions->FillProxyEdits(IpIMClient1);
  }

  frmOptions->PageControl1->ActivePage = frmOptions->TabSheet1;
  if (frmOptions->ShowModal() == mrOk) {
    IpIMClient1->Password = frmOptions->edtPassword->Text;
    IpIMClient1->LoginID = frmOptions->edtSignInName->Text;
    IpIMClient1->URL = frmOptions->edtServerAddress->Text;
    IpIMClient1->Port = StrToInt(frmOptions->edtServerPort->Text);

    if (frmOptions->cbUseProxy->Checked == true) {
      IpIMClient1->SocksServer->Address = frmOptions->edtServer->Text;
      IpIMClient1->SocksServer->Port = StrToInt(frmOptions->edtPort->Text);

      IpIMClient1->SocksServer->UserCode = frmOptions->edtUserID->Text;
      IpIMClient1->SocksServer->Password = frmOptions->edtProxyPassword->Text;
      
      switch(frmOptions->cbProxyType->ItemIndex) {
        case 0 : IpIMClient1->SocksServer->SocksVersion = svSocks4; break;
        case 1 : IpIMClient1->SocksServer->SocksVersion = svSocks4a; break;
        case 2 : IpIMClient1->SocksServer->SocksVersion = svSocks5; break;
        default : {
          IpIMClient1->SocksServer->Address = "";
          IpIMClient1->SocksServer->Port = 0;
          IpIMClient1->SocksServer->UserCode = "";
          IpIMClient1->SocksServer->Password = "";
        }
      }  //switch
    }
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Signin1Click(TObject *Sender)
{
  bool x;

  x = false;

  if (IpIMClient1->ProtocolState > psLoggingOn) {
    ShowMessage("You are already signed in");
    x = true;
  } else if ((IpIMClient1->LoginID != "") && (IpIMClient1->Password != "")) {
    Screen->Cursor = crHourGlass;
    IpIMClient1->Login();
    x = true;
  } else {
    IpIMClient1->LoginID = frmOptions->edtSignInName->Text;
    IpIMClient1->Password = frmOptions->edtPassword->Text;
  }

  if (x == false) {
    if ((IpIMClient1->LoginID != "") && (IpIMClient1->Password != "")) {
      IpIMClient1->Login();
      Screen->Cursor = crHourGlass;
      x = true;

    } else {
      if (x == false) {
        if (frmSignin->ShowModal() == mrOk) {
          IpIMClient1->LoginID = frmSignin->edtSignOnName->Text;
          IpIMClient1->Password = frmSignin->edtPassword->Text;
          IpIMClient1->Login();
          Screen->Cursor = crHourGlass;
        }
      }
    }
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::SignOut1Click(TObject *Sender)
{
  lbOnLine->Clear();
  lbOffLine->Clear();
  if (IpIMClient1->ProtocolState > psLoggingOn)
    IpIMClient1->LogOff();
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::OnLine1Click(TObject *Sender)
{
  IpIMClient1->OnLineStatus = osOnLine;
  OnLine1->Checked = true;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Busy1Click(TObject *Sender)
{
  IpIMClient1->OnLineStatus = osBusy;
  Busy1->Checked = true;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Berightback1Click(TObject *Sender)
{
  IpIMClient1->OnLineStatus = osBRB;
  Berightback1->Checked = true;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Away1Click(TObject *Sender)
{
  IpIMClient1->OnLineStatus = osAway;
  Away1->Checked = true;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Onthephone1Click(TObject *Sender)
{
  IpIMClient1->OnLineStatus = osOnPhone;
  Onthephone1->Checked = true;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Outtolunch1Click(TObject *Sender)
{
  IpIMClient1->OnLineStatus = osOutToLunch;
  Outtolunch1->Checked = true;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Hidden1Click(TObject *Sender)
{
  IpIMClient1->OnLineStatus = osHidden;
  Hidden1->Checked = true;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Idle1Click(TObject *Sender)
{
  IpIMClient1->OnLineStatus = osIdle;
  Idle1->Checked = true;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::OffLine1Click(TObject *Sender)
{
  IpIMClient1->OnLineStatus = osOffLine;
  OffLine1->Checked = true;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Addcontact1Click(TObject *Sender)
{
  if (frmAddContact->ShowModal() == mrOk) {
    IpIMClient1->AddBuddy(frmAddContact->edtUserName->Text, frmAddContact->edtFriendlyName->Text);
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Deletecontact1Click(TObject *Sender)
{
  bool x;

  x = false;

  if (FCurrentContact == NULL) {
    ShowMessage("First select a contact");
    x = true;
  }
  if (x == false) {
  if (MessageDlg("Delete " + FCurrentContact->FriendlyName + "?", mtConfirmation, TMsgDlgButtons() << mbYes << mbNo, 0) == mrYes)
    IpIMClient1->DeleteContact(FCurrentContact->LoginID, FCurrentContact->FriendlyName);
  }
}
//---------------------------------------------------------------------------


void __fastcall TfrmMain::lbOnLineClick(TObject *Sender)
{
  TStringList* Strs;
  int Ndx = 0;

  Strs = new(TStringList);

  IpIMClient1->GetListItems(ltBuddy, Strs);
  Ndx = Strs->IndexOf(lbOnLine->Items->Strings[lbOnLine->ItemIndex]);
  if (Ndx >= 0) {
    FCurrentContact = IpIMClient1->GetBuddy(Ndx);
    FCurrentContactOnLine = true;
  } else {
    FCurrentContact = NULL;
    FCurrentContactOnLine = false;
  }
  delete(Strs);
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::lbOffLineClick(TObject *Sender)
{
  TStringList* Strs;
  int Ndx = 0;

  Strs = new(TStringList);

  IpIMClient1->GetListItems(ltBuddy, Strs);
  Ndx = Strs->IndexOf(lbOffLine->Items->Strings[lbOffLine->ItemIndex]);
  if (Ndx > 0) {
    FCurrentContact = IpIMClient1->GetBuddy(Ndx);
    FCurrentContactOnLine = false;
  } else {
    FCurrentContact = NULL;
    FCurrentContactOnLine = false;
  }
  delete(Strs);
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Exit1Click(TObject *Sender)
{
  if (IpIMClient1->ProtocolState > psLoggedOff)
    IpIMClient1->LogOff();
  Application->Terminate();
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Toolbar1Click(TObject *Sender)
{
  Toolbar1->Checked = !(Toolbar1->Checked);
  Panel2->Visible = Toolbar1->Checked;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::Statusbar2Click(TObject *Sender)
{
  Statusbar2->Checked = !(Statusbar2->Checked);
  StatusBar1->Visible = Statusbar2->Checked;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::OffLinecontacts1Click(TObject *Sender)
{
  OffLinecontacts1->Checked = !(OffLinecontacts1->Checked);
  if (OffLinecontacts1->Checked == true)
    Panel6->Visible = true;
  else
    Panel6->Visible = OffLinecontacts1->Checked;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::OnLinecolot1Click(TObject *Sender)
{
  if (ColorDialog1->Execute())
    lbOnLine->Color = ColorDialog1->Color;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::OffLinecolor1Click(TObject *Sender)
{
  if (ColorDialog1->Execute())
    lbOffLine->Color = ColorDialog1->Color;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::puSelProtocolPopup(TObject *Sender)
{
  miSelProtocol->Enabled = (IpIMClient1->ProtocolState == psLoggedOff);
  if (IpIMClient1->Protocol == pMSN)
    miSelProtocol->Caption = "Switch to AOL protocol";
  else
    miSelProtocol->Caption = "Switch to MSN protocol";
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::miSelProtocolClick(TObject *Sender)
{
  if (IpIMClient1->Protocol == pMSN) {
    ImgMSN->Visible = false;
    ImgAOL->Visible = true;
    IpIMClient1->Protocol = pAIM;
  } else {
    ImgMSN->Visible = true;
    ImgAOL->Visible = false;
    IpIMClient1->Protocol = pMSN;
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::SendIM1Click(TObject *Sender)
{
  if (IpIMClient1->Protocol == pMSN) {
    IpIMClient1->CreateChatRoom();
    if ((FCurrentContact != NULL) && (FCurrentContactOnLine == true)) {
      //send IM to FCurrentContact
      frmIM->Caption = "Instant Message (" + FCurrentContact->FriendlyName + ")";
      frmIM->FToUser = FCurrentContact;
      frmIM->Client = IpIMClient1;
    } else {
      frmSelectForSend->lbSelect->Items = lbOnLine->Items;
      if (frmSelectForSend->ShowModal() == mrOk) {
        lbOnLine->ItemIndex = frmSelectForSend->lbSelect->ItemIndex;
        lbOnLineClick(this);      //gets presentity
        frmIM->Caption = "Instant Message (" + FCurrentContact->FriendlyName + ")";
        frmIM->FToUser = FCurrentContact;
        frmIM->Client = IpIMClient1;
      }
    }
  } else {        //Protocol is pAIM
    if ((FCurrentContact != NULL) && (FCurrentContactOnLine == true)) {
      //send IM to FCurrentContact
      frmIM->Caption = "Instant Message (" + FCurrentContact->FriendlyName + ")";
      frmIM->FToUser = FCurrentContact;
      frmIM->Client = IpIMClient1;
      IpIMClient1->CreateChatRoom();
      frmIM->Show();
    } else {
      frmSelectForSend->lbSelect->Items = lbOnLine->Items;
      if (frmSelectForSend->ShowModal() == mrOk) {
        lbOnLine->ItemIndex = frmSelectForSend->lbSelect->ItemIndex;
        lbOnLineClick(this);      //gets presentity
        frmIM->Caption = "Instant Message (" + FCurrentContact->FriendlyName + ")";
        frmIM->FToUser = FCurrentContact;
        frmIM->Client = IpIMClient1;
        IpIMClient1->CreateChatRoom();
        frmIM->Show();
      }
    }
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::IpIMClient1BuddyPresenceChange(
      TIpCustomIMClient *Client, AnsiString BuddyID,
      AnsiString BuddyFriendlyName, TIMOnLineStatus Status)
{
  UpdateLists();
}
//---------------------------------------------------------------------------


void __fastcall TfrmMain::IpIMClient1ChatInvitation(
      TIpCustomIMClient *Client, AnsiString SenderID,
      AnsiString SenderFriendlyName, bool &Accept)
{
  frmIM->FLoginID = SenderID;
  frmIM->FFriendlyName = SenderFriendlyName;
  frmIM->Client = IpIMClient1;
  frmIM->Show();
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::IpIMClient1ChatRosterChange(
      TIpCustomIMClient *Client, bool Addition, AnsiString UserHandle,
      AnsiString FriendlyName)
{
  frmIM->lbSession->Clear();
  IpIMClient1->GetListItems(ltChatRoster, frmIM->lbSession->Items);
  if (frmIM->lbSession->Items->Count > 0)
    frmIM->pnlSession->Visible = true;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::IpIMClient1ListChange(TIpCustomIMClient *Client,
      bool Addition, AnsiString UserHandle, AnsiString FriendlyName,
      TIMListType ListType)
{
  UpdateLists();
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::IpIMClient1SendInstantMessage(
      TIpCustomIMClient *Client, AnsiString SenderID,
      AnsiString SenderFriendlyName, AnsiString Msg)
{
  frmIM->lbDialog->Items->Add(SenderFriendlyName + ": " + Msg);
  frmIM->lbDialog->ItemIndex = frmIM->lbDialog->Items->Count - 1;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::IpIMClient1StateChange(TIpCustomIMClient *Client,
      TIMProtocolState State)
{
  StatusBar1->Panels->Items[0]->Text = IpIMClient1->StateToString();
  SetAllControls();
  if ((State > psRedirecting) || (State == psLoggedOff))
    Screen->Cursor = crDefault;

  if (State >= psStartingChatSession)
    frmIM->Show();
  if (State == psLoggedOff) {
    lbOnLine->Clear();
    lbOffLine->Clear();
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::IpIMClient1StatusChange(
      TIpCustomIMClient *Client, TIMOnLineStatus Status)
{
  switch(Status) {
    case osOnLine : OnLine1->Checked = true; break;
    case osOffLine : OffLine1->Checked = true; break;
    case osHidden : Hidden1->Checked = true; break;
    case osBRB : Berightback1->Checked = true; break;
    case osOnPhone : Onthephone1->Checked = true; break;
    case osOutToLunch : Outtolunch1->Checked = true; break;
    case osBusy : Busy1->Checked = true; break;
    case osIdle : Idle1->Checked = true; break;
    case osAway : Away1->Checked = true; break;
  }
  UpdateLists();   
}
//---------------------------------------------------------------------------

