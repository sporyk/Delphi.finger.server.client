//---------------------------------------------------------------------------
#ifndef ExBrow0H
#define ExBrow0H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Forms.hpp>
#include <Menus.hpp>
#include <Dialogs.hpp>

#include "IpUtils.hpp"
#include "IpSock.hpp"
#include "IpCache.hpp"
#include "IpBroker.hpp"
#include "IpHttp.hpp"
#include "IpHtml.hpp"
//---------------------------------------------------------------------------

#define INIFileName "BROWSR.INI"
#define HistoryFileName "BROWSR.HIS"

class TfrmBrowsr0 : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TPanel *Panel2;
        TPanel *Panel3;
        TMainMenu *MainMenu1;
        TPopupMenu *PopupMenu1;
        TIpHtmlPanel *IpHTMLPanel1;
        TComboBox *ComboBox1;
        TLabel *Label1;
        TButton *Button1;
        TButton *Button2;
        TButton *Button3;
        TButton *Button4;
        TButton *Button5;
        TCheckBox *CheckBox1;
        TSaveDialog *SaveDialog1;
        TIpHtmlDataProvider *IpHtmlDataProvider1;
        TIpCache *IpCache1;
        TIpHttpClient *IpHTTPClient1;
        TLabel *lblHot;
        TMenuItem *mnFile;
        TMenuItem *mnEdit;
        TMenuItem *mnView;
        TMenuItem *mnFile_Open;
        TMenuItem *N1;
        TMenuItem *mnFile_Exit;
        TMenuItem *mnEdit_Copy;
        TMenuItem *mnEdit_SelectAll;
        TMenuItem *N2;
        TMenuItem *mnEdit_Preferences;
        TMenuItem *mnView_PageSource;
        TMenuItem *mnBack;
        TMenuItem *mnForward;
        TMenuItem *N3;
        TMenuItem *mnSaveAs;
        TMenuItem *mnCopy;
  void __fastcall Button1Click(TObject *Sender);
  void __fastcall FormCreate(TObject *Sender);
  void __fastcall FormDestroy(TObject *Sender);
  void __fastcall IpCache1LoadFromCache(TObject *Sender,
          const AnsiString Item, const AnsiString CacheFileName);
  void __fastcall IpCache1CacheItem(TObject *Sender, const AnsiString Item,
          const AnsiString CacheFileName, TStream *HeaderStream,
          TStream *ItemStream);
  void __fastcall IpHTMLDataProvider1CheckURL(TObject *Sender,
          const AnsiString URL, bool &Available, AnsiString &ContentType);
  void __fastcall IpHTMLDataProvider1GetHtml(TObject *Sender,
          const AnsiString URL, const TIpFormDataEntity *PostData,
          TStream *&Stream);
  void __fastcall IpHTMLDataProvider1GetImage(TIpHtmlNode *Sender,
          const AnsiString URL, TPicture *&Picture);
  void __fastcall IpHTTPClient1GotItem(TObject *Sender, DWORD Socket,
          const AnsiString Item, bool Cached);
  void __fastcall Button2Click(TObject *Sender);
  void __fastcall Button3Click(TObject *Sender);
  void __fastcall mnBackClick(TObject *Sender);
  void __fastcall mnForwardClick(TObject *Sender);
  void __fastcall IpHTMLDataProvider1Leave(TIpHtml *Sender);
  void __fastcall mnSaveAsClick(TObject *Sender);
  void __fastcall mnCopyClick(TObject *Sender);
  void __fastcall mnEdit_CopyClick(TObject *Sender);
  void __fastcall mnEdit_SelectAllClick(TObject *Sender);
  void __fastcall mnEdit_PreferencesClick(TObject *Sender);
  void __fastcall PopupMenu1Popup(TObject *Sender);
  void __fastcall FormShow(TObject *Sender);
  void __fastcall mnFile_OpenClick(TObject *Sender);
  void __fastcall mnFile_ExitClick(TObject *Sender);
  void __fastcall Button5Click(TObject *Sender);
  void __fastcall mnView_PageSource1Click(TObject *Sender);
  void __fastcall Button4Click(TObject *Sender);
  void __fastcall IpHTMLPanel1HotChange(TObject *Sender);
        
private:	// User declarations
  bool FCancelled;
public:		// User declarations
  __fastcall TfrmBrowsr0(TComponent* Owner);

  TIpImageQueue* ImageQueue;
  TMemoryStream* ViewCopy; // copy of last HTML stream

  Boolean AutoOpen;
  TIniFile* BrowsrIni;
  AnsiString DefaultPage, DefaultGraphic;
  AnsiString LastUrl;

  void __fastcall DoOpenPage(const AnsiString URL);
  void __fastcall AddToHistory(const AnsiString URL);
  void __fastcall SetStatus(const AnsiString URL);
  void __fastcall DoGoBack();
  void __fastcall DoGoForward();
  void __fastcall HTMLClipboardCopy();
  void __fastcall HTMLSelectAll();
  void __fastcall DownloadEntity(AnsiString URL, AnsiString ContentType);
  void __fastcall LoadImage(AnsiString ImgURL, TPicture*& Picture);
  void __fastcall LoadPreferences();
  void __fastcall SavePreferences();
  void __fastcall SetDone();

  AnsiString __fastcall GetCurURL();            // read method
  void __fastcall SetCurURL(AnsiString Value);  // write method

  __property AnsiString CurURL = {read=GetCurURL, write=SetCurURL};

};
//---------------------------------------------------------------------------
extern PACKAGE TfrmBrowsr0 *frmBrowsr0;
//---------------------------------------------------------------------------
#endif