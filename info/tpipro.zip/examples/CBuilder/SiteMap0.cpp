// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "SiteMap0.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpBroker"
#pragma link "IpCache"
#pragma link "IpHtml"
#pragma link "IpHttp"
#pragma link "IpSock"
#pragma link "IpUtils"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
/* Traditional HTTP requester stuff begins */
void __fastcall TForm1::IpHTMLDataProvider1CheckURL(TObject *Sender,
      const AnsiString URL, bool &Available, AnsiString &ContentType)
{
  AnsiString S, X;
  TIpAddrRec AddrRec;

  Available = false;
  IpParseURL(URL, AddrRec);
  AnsiString Protocol = UpperCase(AddrRec.Scheme);

  if (Protocol == "FILE") {
    S = NetToDOSPath(AddrRec.Path);
    Available = FileExists(S);
    if (Available) {
      AnsiString X = UpperCase(ExtractFileExt(S));
      if ((X == ".HTM") || (X == ".HTML")) {
        ContentType = "text/html";
      }
      else {
      if (X == ".GIF") {
        ContentType = "image/gif";
      }
      else {
      if ((X == ".JPG") || (X == ".JPEG") || (X == ".JFIF")) {
        ContentType = "image/jpeg";
      }
      else {
        ContentType = "file/binary";
      }}}
    }
  }

  if (Protocol == "HTTP") {
    Available = false;
    WaitingForReply = true;
    HaveReply = false;
    try {
      IpHttpClient1->HeadWait(URL);
      if (HaveReply) {
        Available = true;
        ContentType = IpHttpClient1->GetItemContentType(URL);
      }
    }
    __finally {
      WaitingForReply = false;
    }
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpHTMLDataProvider1GetHtml(TObject *Sender,
      const AnsiString URL, const TIpFormDataEntity *PostData,
      TStream *&Stream)
{
  AnsiChar NullChar = 0;
  TIpAddrRec AddrRec;

  IpParseURL(URL, AddrRec);
  AnsiString Protocol = UpperCase(AddrRec.Scheme);

  if (Protocol == "FILE") {
    Stream = new TFileStream(NetToDOSPath(AddrRec.Path), fmOpenRead || fmShareDenyWrite);
  }
  else {

  if (Protocol == "HTTP") {
    Stream = new TMemoryStream;
    WaitingForReply = true;
    HaveReply = false;
    try {
      IpHttpClient1->GetWait(URL);
      if (HaveReply) {
        if (IpHttpClient1->BodyStream[URL]->Size > 0) {
          Stream->CopyFrom(IpHttpClient1->BodyStream[URL], IpHttpClient1->BodyStream[URL]->Size);
          Stream->Seek(0, 0);
        } else {
          Stream->Write(&NullChar, 1);
        }
      }
    }
    __finally {
      WaitingForReply = false;
    }
  }
  else {
    delete Stream;
    Stream = NULL;
    Exception* E = new Exception("HTML data provider does not support this protocol:%s",ARRAYOFCONST((URL)));
    throw E;
  }}
}
/* Traditional HTTP requester stuff ends */
//---------------------------------------------------------------------------
void __fastcall TForm1::ListNodes(TIpHtmlNode *Node)
{
/*- Walk document's node hierarchy looking for
   nodes which have HREFs.
   When a unique HREF is found, add it to the
   global LinkList.*/
  AnsiString S;
  if (Cancelled) {
    return;
  }

  /* See if node is a type which has an HREF attribute
   That is, <A> || <AREA> nodes. */

  TIpHtmlNodeA* HNA = dynamic_cast<TIpHtmlNodeA *>(Node);
  if (HNA) {
    S = HNA->HRef;
  }
  else {
  TIpHtmlNodeAREA* HNArea = dynamic_cast<TIpHtmlNodeAREA *>(Node);
  if (HNArea) {
    S = HNArea->HRef;
  }}

  S = Trim(S);

  /*If HREF was !blank && we haven"t seen it before,
   add it to the list*/
  if ((S != "") && (LinkList->IndexOf(S) == -1)) {
    LinkList->Add(S);
  }

  /* See if Node is a container type node. If so, recursively
   traverse its children. */

  TIpHtmlNodeMulti* HNM = dynamic_cast<TIpHtmlNodeMulti *>(Node);
  if (HNM) {
    for (int i = 0; i < HNM->ChildCount; i++) {
      ListNodes(HNM->ChildNode[i]);
      if (i % 50 == 0)
        Application->ProcessMessages();
      if (Cancelled) {
        return;
      }
    }
  }
}

//---------------------------------------------------------------------------
void __fastcall TForm1::BuildList(TIpHtml* H)
{
  if (H) {
    ListNodes(H->HtmlNode);
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::WalkLinks(TTreeNode  *N,
                            const AnsiString Root,
                            const AnsiString Host)
{
  AnsiString URL;
  int i;
  TIpAddrRec AddrRec;
  /* Get the Authority field from the URL */
  IpParseURL(Root, AddrRec);

  /* Tell treeview to expand all nodes (just a visual effect) */
  TreeView1->FullExpand();

  /* if the Authority is not the same as the host, do not go further and
   download the HTML file--it's out of our purview */
  if (AddrRec.Authority != Host) {
    return;
  }

  /* Clear global link list before processing the current document */
  LinkList->Clear();

  /* List all HREF in the current document */
  IpHTMLScanner1->EnumDocuments(BuildList);

  /* Copy global list into local list */
  TStringList* LocalLinkList = new TStringList;
  LocalLinkList->Assign(LinkList);

  /* create a list to hold new pages */
  TStringList* NewSubLinks = new TStringList;

  try {
    /* Add links at this level */
    for (i = 0; i < LocalLinkList->Count; i++) {
      /* Build the URL */
      URL = BuildURL(Root, LocalLinkList->Strings[i]);
      /* Check that the URL is local to this site,
       that it specifies HTML (not stuff like MAILTO:),
       and that we haven't already processed the page */
      if ((AddrRec.Authority == Host)
        && IpHTMLScanner1->IsURLHtml(URL)
        && (VisitedLinks->IndexOf(URL) == -1))
      {
        /* Add the new page to the Visited list */
        VisitedLinks->Add(URL);
        NewSubLinks->Add(URL);
      }
      Application->ProcessMessages();
      if (Cancelled) {
        return;
      }
    }

    /*Traverse each link in the current document*/
    for (i = 0; i < NewSubLinks->Count; i++) {
      /* Build the URL */
      URL = BuildURL(Root, NewSubLinks->Strings[i]);

      /* if the URL is not within this host, just add it to the tree-
       view; there's nothing else to do since we certainly don't want
       to load it */
      IpParseURL(URL, AddrRec);
      if (AddrRec.Authority != Host) {
        TreeView1->Items->AddChild(N, URL);
        TreeView1->FullExpand();
      }
      else {
        /* Open the sub-page */
        IpHTMLScanner1->OpenURL(URL);
        /* Recursively process it */
        WalkLinks(TreeView1->Items->AddChild(N, URL), Root, Host);
      }
      Application->ProcessMessages();
      if (Cancelled) {
       return;
      }
    }
  }
  __finally {
    /* Free our local link lists */
    delete LocalLinkList;
    delete NewSubLinks;
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
  TTreeNode* N;
  TIpAddrRec AddrRec;

  Screen->Cursor = crHourGlass;
  Button1->Enabled = false;
  try {
    Button2->Enabled = true;
    Cancelled = false;
    /* Check if URL typed in is available && identifies an HTML resource */
    if (!IpHTMLScanner1->IsURLHtml(Edit1->Text)) {
      Exception* E = new Exception(Edit1->Text+ " is not an HTML resource");
      throw E;
    }

    if (Edit1->Text[Edit1->Text.Length()] != '/') {
      Edit1->Text = Edit1->Text + "/";
    }

    /* Open root page */
    IpHTMLScanner1->OpenURL(Edit1->Text);

    /* Clear site map tree view */
    TreeView1->Items->Clear();

    /* Add root page to site map, save node as parent for future nodes */
    N = TreeView1->Items->Add(NULL, Edit1->Text);

    /* Create a list to store already visited pages so that a link
     from one page to another, which has already been processed,
     does not cause us to enter an infinite loop. */
    VisitedLinks = new TStringList;
    VisitedLinks->Sorted = true;
    VisitedLinks->Add(Edit1->Text);

    /* Create a global list for the document enumerator logic */
    LinkList = new TStringList;
    LinkList->Sorted = true;

    /* Walk links, starting with root page */
    IpParseURL(Edit1->Text, AddrRec);

    WalkLinks(N, Edit1->Text, AddrRec.Authority);

    delete LinkList;
    delete VisitedLinks;
  }
  __finally {
    Button1->Enabled = true;
    Button2->Enabled = false;
    Screen->Cursor = crDefault;
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
  Cancelled = true;
  Button2->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  IpHTMLScanner1 = new TIpHtmlScanner(this);
  IpHTMLScanner1->DataProvider = IpHTMLDataProvider1;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
  delete IpHTMLScanner1;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpHttpClient1GotItem(TObject *Sender, DWORD Socket,
      const AnsiString Item, bool Cached)
{
  HaveReply = true;
  WaitingForReply = false;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpHttpClient1Disconnect(TObject *Sender,
      DWORD Socket)
{
  WaitingForReply = false;
  HaveReply = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::TreeView1DblClick(TObject *Sender)
{
  TreeView1->Items->Clear();
}
//---------------------------------------------------------------------------

