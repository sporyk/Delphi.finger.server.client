// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ExRasEn1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpRas"
#pragma link "IpUtils"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpRasEntryComboBox1Change(TObject *Sender)
{
  TRasEntry Entry;
  int EntrySize = sizeof(Entry);
  int DevInfoSize = 0;
  memset(&Entry, 0, EntrySize);
  Entry.dwSize = EntrySize;
  int Index = IpRasEntryComboBox1->ItemIndex;
  AnsiString EntryName = IpRasEntryComboBox1->Items->Strings[Index];
  long rs = IpRasAccess->RasGetEntryProperties(0, EntryName.c_str(), &Entry,
                                               EntrySize, 0, DevInfoSize);
  ListBox1->Clear();
  ListBox1->Items->Add("RasGetEntryProperties");
  ListBox1->Items->Add("  function result: " + IntToStr(rs));
  ListBox1->Items->Add("  area code: " + StrPas(Entry.szAreaCode));
  ListBox1->Items->Add("  local phone number: " + StrPas(Entry.szLocalPhoneNumber));
  ListBox1->Items->Add("  device type: " + StrPas(Entry.szDeviceType));
  ListBox1->Items->Add("  device name: " + StrPas(Entry.szDeviceName));
}
//---------------------------------------------------------------------------
