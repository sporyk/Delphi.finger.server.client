//---------------------------------------------------------------------------
#ifndef ExPing0H
#define ExPing0H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpIcmp.hpp"
#include "IpSock.hpp"
#include "IpUtils.hpp"
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TfrmExPing : public TForm
{
__published:	// IDE-managed Components
    TBevel *Bevel1;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *lblRTTMinimum;
    TLabel *lblRTTMaximum;
    TLabel *lblRTTAverage;
    TButton *btnPing;
    TListBox *lbxPing;
    TEdit *edtPingAddress;
    TEdit *edtPingCount;
    TCheckBox *cbxBlockingPing;
    TCheckBox *cbxResolve;
    TIpIcmp *IpIcmp1;
    void __fastcall btnPingClick(TObject *Sender);
    void __fastcall IpIcmp1IcmpEcho(TIpCustomIcmp *Icmp,
          const TIpExtendedEchoInfo *EchoInfo, const AnsiString EchoFrom);
    void __fastcall IpIcmp1IcmpEchoString(TIpCustomIcmp *Icmp,
          const AnsiString EchoString);
    void __fastcall IpIcmp1PingComplete(TIpCustomIcmp *Icmp,
          const TStringList *Replies, bool PingOK);
private:	// User declarations
public:		// User declarations
    __fastcall TfrmExPing(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmExPing *frmExPing;
//---------------------------------------------------------------------------
#endif
