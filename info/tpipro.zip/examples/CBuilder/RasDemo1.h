//---------------------------------------------------------------------------
#ifndef RasDemo1H
#define RasDemo1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpRas.hpp"
#include "IpUtils.hpp"
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
#include <Menus.hpp>
#include "IpRasSt.hpp"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox2;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label11;
    TLabel *Label12;
    TEdit *PasswordEdit;
    TEdit *UserNameEdit;
    TEdit *DomainEdit;
    TEdit *PhoneNumberEdit;
    TEdit *CallbackEdit;
    TComboBox *DialModeSelect;
    TGroupBox *GroupBox3;
    TLabel *Label6;
    TLabel *Label5;
    TSpeedButton *PhonebookBtn;
    TEdit *PhoneBookEdit;
    TStatusBar *StatusBar1;
    TMainMenu *MainMenu;
    TMenuItem *File1;
    TMenuItem *Exit1;
    TMenuItem *Call1;
    TMenuItem *Dial1;
    TMenuItem *Hangup1;
    TMenuItem *Phonebook1;
    TMenuItem *NewPhonebookEntry;
    TMenuItem *EditPhonebookEntry;
    TMenuItem *Deleteentry1;
    TOpenDialog *OpenDialog;
    TIpRasDialer *IpRasDialer;
    TIpRasEntryComboBox *IpRasEntryComboBox;
    TIpRasStatus *IpRasStatus1;
    TGroupBox *rgOptions;
    TCheckBox *chkPausedStates;
    TCheckBox *chkIgnoreModemSpeaker;
    TCheckBox *chkSetModemSpeaker;
    TCheckBox *chkIgnoreSWCompression;
    TCheckBox *chkSetSWCompression;
    TCheckBox *chkUsePrefixSuffix;
    TButton *btnDial;
    TButton *btnHangup;
    void __fastcall Dial1Click(TObject *Sender);
    void __fastcall Hangup1Click(TObject *Sender);
    void __fastcall NewPhonebookEntryClick(TObject *Sender);
    void __fastcall EditPhonebookEntryClick(TObject *Sender);
    void __fastcall Deleteentry1Click(TObject *Sender);
    void __fastcall IpRasDialerDialStatus(TObject *Sender, int Status);
    void __fastcall PhonebookBtnClick(TObject *Sender);
    void __fastcall Exit1Click(TObject *Sender);
    void __fastcall IpRasDialerConnected(TObject *Sender);
    void __fastcall IpRasDialerDialError(TObject *Sender, int Error);
    void __fastcall IpRasDialerDisconnected(TObject *Sender);
    void __fastcall IpRasEntryComboBoxChange(TObject *Sender);
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall chkUsePrefixSuffixClick(TObject *Sender);
    void __fastcall chkPausedStatesClick(TObject *Sender);
    void __fastcall chkIgnoreModemSpeakerClick(TObject *Sender);
    void __fastcall chkSetModemSpeakerClick(TObject *Sender);
    void __fastcall chkIgnoreSWCompressionClick(TObject *Sender);
    void __fastcall chkSetSWCompressionClick(TObject *Sender);
private:	// User declarations
    void __fastcall DisplayDialParameters(void);
    void __fastcall SetDialParameters(void);
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
