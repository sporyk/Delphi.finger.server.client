//---------------------------------------------------------------------------
#ifndef ImAddConH
#define ImAddConH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TfrmAddContact : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TLabel *Label2;
    TBevel *Bevel1;
    TButton *btnOK;
    TButton *btnCancel;
    TEdit *edtUserName;
    TEdit *edtFriendlyName;
    void __fastcall btnOKClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TfrmAddContact(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmAddContact *frmAddContact;
//---------------------------------------------------------------------------
#endif
