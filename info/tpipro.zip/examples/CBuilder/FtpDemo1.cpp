// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "FtpDemo1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpFtp"
#pragma link "IpSock"
#pragma link "IpUtils"
#pragma link "IpMupc"
#pragma resource "*.dfm"
TForm1 *Form1;

enum TMultiFileOp {mfoNone, mfoRetrieve, mfoDelete};

TMultiFileOp MultiFileOp;


//---------------------------------------------------------------------------
bool __fastcall GetFileName(AnsiString Caption, AnsiString &FN)
{
  FN = "";
  return(InputQuery("FtpDemo", Caption, FN));
}
//---------------------------------------------------------------------------
bool __fastcall GetRemoteDirName(AnsiString &R)
{
  return(GetFileName("Remote Directory", R));
}
//---------------------------------------------------------------------------
bool __fastcall GetRemoteFileName(AnsiString &R)
{
  return(GetFileName("Remote Filename", R));
}
//---------------------------------------------------------------------------
bool __fastcall GetRLNames(AnsiString &R, AnsiString &L)
{
  if (GetFileName("Remote Filename", R))
    return(GetFileName("Local Filename", L));
  else
    return(false);
}
//---------------------------------------------------------------------------
bool __fastcall GetRNNames(AnsiString &R, AnsiString &N)
{
  if (GetFileName("Remote Filename", R))
    return(GetFileName("New Filename", N));
  else
    return(false);
}
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  TimeoutEdit->Text = IntToStr(IpFtpClient1->TransferTimeout);
  FileType1->ItemIndex = (int)IpFtpClient1->FileType;
  rgDirStyle->ItemIndex = (int)IpFtpDirectoryTree1->DirectoryStyle;
  chkPassive->Checked = IpFtpClient1->PassiveMode;
  edtSocksAddress->Text = IpFtpClient1->SocksServer->Address;
  edtSocksPassword->Text = IpFtpClient1->SocksServer->Password;
  edtSocksPort->Text = IntToStr(IpFtpClient1->SocksServer->Port);
  cbxSocksVersion->ItemIndex = (int)IpFtpClient1->SocksServer->SocksVersion;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Login1Click(TObject *Sender)
{
  IpFtpClient1->SocksServer->Address = edtSocksAddress->Text;
  IpFtpClient1->SocksServer->Password = edtSocksPassword->Text;
  IpFtpClient1->SocksServer->Port = short(StrToIntDef(edtSocksPort->Text, 1080));
  IpFtpClient1->SocksServer->SocksVersion =
    (TIpSocksVersion)cbxSocksVersion->ItemIndex;
  IpFtpClient1->PassiveMode = chkPassive->Checked;
  IpFtpClient1->Login(edtURL->Text, edtUserName->Text, edtPassword->Text, "");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Logout1Click(TObject *Sender)
{
  IpFtpClient1->Logout();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Exit1Click(TObject *Sender)
{
  IpFtpClient1->Logout();
  Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Change1Click(TObject *Sender)
{
  AnsiString R;
  if (GetRemoteDirName(R))
    IpFtpClient1->ChangeDir(R);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::NamesList1Click(TObject *Sender)
{
  AnsiString R;
  if (GetFileName("Remote directory or null string", R))
    IpFtpClient1->ListDir(R, false);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FullList1Click(TObject *Sender)
{
  AnsiString R;
  if (GetFileName("Remote directory or null string", R))
    IpFtpClient1->ListDir(R, true);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Help1Click(TObject *Sender)
{
  AnsiString C = "";
  if (InputQuery("ExFtp1 - Help", "FTP command", C))
    IpFtpClient1->Help(C);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Send1Click(TObject *Sender)
{
  AnsiString R, L;
  if (GetRLNames(R, L))
    IpFtpClient1->Store(R, L, (TIpFtpStoreMode)SendMode1->ItemIndex,
      StrToIntDef(edtRestartAt->Text, 0));
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Recieve1Click(TObject *Sender)
{
  AnsiString R, L;
  if (GetRLNames(R, L))
    IpFtpClient1->Retrieve(R, L, (TIpFtpRetrieveMode)ReceiveMode1->ItemIndex,
      StrToIntDef(edtRestartAt->Text, 0));
}
//---------------------------------------------------------------------------
void __fastcall TForm1::CreateDir1Click(TObject *Sender)
{
  AnsiString R;
  if (GetRemoteDirName(R))
    IpFtpClient1->MakeDir(R);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Delete1Click(TObject *Sender)
{
  AnsiString R;
  if (GetRemoteFileName(R))
    IpFtpClient1->Delete(R);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SendFtp1Click(TObject *Sender)
{
  AnsiString C = "";
  if (InputQuery("FtpDemo: Ftp Client", "Ftp command", C))
    IpFtpClient1->SendFtpCommand(C);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Status1Click(TObject *Sender)
{
  AnsiString R;
  if (GetRemoteDirName(R))
    IpFtpClient1->Status(R);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Rename1Click(TObject *Sender)
{
  AnsiString R, N;
  if (GetRNNames(R, N))
    IpFtpClient1->Rename(R, N);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpFtpDirectoryTree1Change(TObject *Sender,
      TTreeNode *Node)
{
  Screen->Cursor = crHourGlass;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpFtpDirectoryTree1Changed(TObject *Sender)
{
  Screen->Cursor = crDefault;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::rgDirStyleClick(TObject *Sender)
{
  IpFtpDirectoryTree1->DirectoryStyle = (TIpFtpDirStyle)rgDirStyle->ItemIndex;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FileType1Click(TObject *Sender)
{
  IpFtpClient1->FileType = (TIpFtpFileType)FileType1->ItemIndex;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::TimeoutEditExit(TObject *Sender)
{
  IpFtpClient1->TransferTimeout = StrToIntDef(TimeoutEdit->Text, 1092);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::btnRetrieveClick(TObject *Sender)
{
  MultiFileOp = mfoRetrieve;
  RetrieveNext();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnDeleteClick(TObject *Sender)
{
  MultiFileOp = mfoDelete;
  DeleteNext();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnStoreClick(TObject *Sender)
{
  if (OpenDialog1->Execute()) {
    AnsiString L = OpenDialog1->FileName;
    AnsiString R = ExtractFileName(L);
    if (InputQuery("FtpDemo", "Remote file name", R))
      IpFtpClient1->Store(R, L, (TIpFtpStoreMode) SendMode1->ItemIndex,
        StrToIntDef(edtRestartAt->Text, 0));
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DeleteNext(void)
{
  if (lbxFiles->SelCount == 0)
    MultiFileOp = mfoNone;
  else
    for (int i = lbxFiles->Items->Count - 1; i > -1; i--) {
      if (lbxFiles->Selected[i]) {
        IpFtpClient1->Delete(lbxFiles->Items->Strings[i]);
        lbxFiles->Items->Delete(i);
        break;
      }
    }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::RetrieveNext(void)
{
  if (lbxFiles->SelCount == 0)
    MultiFileOp = mfoNone;
  else
    for (int i = lbxFiles->Items->Count - 1; i > -1; i--) {
      if (lbxFiles->Selected[i]) {
        AnsiString s = GetCurrentDir();
        if (s[s.Length()] != ':')
          s = s + "\\";
        IpFtpClient1->Retrieve(lbxFiles->Items->Strings[i], s + lbxFiles->Items->Strings[i],
          (TIpFtpRetrieveMode) ReceiveMode1->ItemIndex, 0);
        lbxFiles->Selected[i] = false;
        break;
      }
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::IpFtpClient1FtpError(TObject *Sender,
      int ErrorCode, const AnsiString ErrorText)
{
  MessageDlg(ErrorText, mtError, TMsgDlgButtons() << mbOK, 0);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::IpFtpClient1FtpReply(TObject *Sender,
      int ReplyCode, const AnsiString Reply)
{
  ReplyMemo->Lines->Add(Reply);
}
//---------------------------------------------------------------------------


void __fastcall TForm1::IpFtpClient1FtpStatus(TObject *Sender,
      TIpFtpStatusCode StatusCode, const AnsiString Info)
{
  switch (StatusCode) {
    case fscClose :      Caption = "FtpDemo: Ftp Client";
                         break;
    case fscOpen :       Caption = " connected to " + IpFtpClient1->ServerAddress;
                         break;
    case fscComplete :   if (MultiFileOp == mfoDelete)
                           DeleteNext();
                         break;
    case fscCurrentDir : Caption = Info;
                         break;
    case fscLogin :      Caption = IpFtpClient1->UserName + " logged on to " + IpFtpClient1->ServerAddress;
                         break;
    case fscLogout :     Caption = IpFtpClient1->UserName + " logged out";
                         break;
    case fscDirList :    ReplyMemo->Lines->Add(Info);
                         break;
    case fscProgress :   Caption = IntToStr(IpFtpClient1->BytesTransferred) + " bytes Transferred";
                         break;
    case fscTransferOK : Caption = Caption + " - transfer complete";
                         if (MultiFileOp == mfoRetrieve)
                           RetrieveNext();
                         break;
    case fscTimeout :    ShowMessage("Transfer timed out");
                         break;
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnAbortClick(TObject *Sender)
{
  IpFtpClient1->Abort();    
}
//---------------------------------------------------------------------------

