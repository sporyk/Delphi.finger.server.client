//---------------------------------------------------------------------------
#ifndef ExBrowScH
#define ExBrowScH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpHtml.hpp"
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
void __fastcall ViewHTMLSource(TStream* S);

class TfrmBrowseSource : public TForm
{
__published:	// IDE-managed Components
  TIpHtmlPanel *HTMLPanel1;
  TPopupMenu *PopupMenu1;
  TMenuItem *Save1;
  TSaveDialog *SaveDialog1;
  void __fastcall Save1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
  Boolean StreamEOF;
  char CharStack[3];
  int Stp;
  char CurChar;

  void __fastcall Push(char Ch);
  char  __fastcall NextChar();
  void __fastcall CollectToOpen(AnsiString& St);
  void __fastcall CollectToClose(AnsiString& St);
  void __fastcall CollectToCloseComment(AnsiString& St);
  void __fastcall CreateText(TIpHtmlNodePRE* PRE, AnsiString& St);
  void __fastcall CreateTag(TIpHtmlNodePRE* PRE, AnsiString& St);
  void __fastcall CreateComment(TIpHtmlNodePRE* PRE, AnsiString& St);
  Boolean  __fastcall IsComment(AnsiString& St);
  __fastcall TfrmBrowseSource(TComponent* Owner);
  void __fastcall CreateBody(TIpHtmlNodeBODY* Body);
  void __fastcall ShowHTMLSyntax();
  TStream* CurStream;
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmBrowseSource *frmBrowseSource;
//---------------------------------------------------------------------------
#endif
