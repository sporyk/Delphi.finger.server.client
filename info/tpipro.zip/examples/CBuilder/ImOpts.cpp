// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ImOpts.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmOptions *frmOptions;
//---------------------------------------------------------------------------
__fastcall TfrmOptions::TfrmOptions(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void TfrmOptions::EnableProxyEdits(void)
{
  lblProxyPassword->Enabled = true;
  lblProxyPort->Enabled = true;
  lblProxyServer->Enabled = true;
  lblProxyType->Enabled = true;
  lblProxyUserID->Enabled = true;

  cbProxyType->Enabled = true;
  edtServer->Enabled = true;
  edtPort->Enabled = true;
  edtUserID->Enabled = true;
  edtProxyPassword->Enabled = true;
}
//---------------------------------------------------------------------------
void TfrmOptions::DisableProxyEdits(void)
{
  lblProxyPassword->Enabled = false;
  lblProxyPort->Enabled = false;
  lblProxyServer->Enabled = false;
  lblProxyType->Enabled = false;
  lblProxyUserID->Enabled = false;

  cbProxyType->ItemIndex = -1;
  cbProxyType->Enabled = false;
  edtServer->Text = "";
  edtServer->Enabled = false;
  edtPort->Text = "";
  edtPort->Enabled = false;
  edtUserID->Text = "";
  edtUserID->Enabled = false;
  edtProxyPassword->Text = "";
  edtProxyPassword->Enabled = false;
}
//---------------------------------------------------------------------------
void TfrmOptions::FillProxyEdits(TIpIMClient* Client)
{
  switch(Client->SocksServer->SocksVersion) {
    case svSocks4 : cbProxyType->ItemIndex = 0; break;
    case svSocks4a : cbProxyType->ItemIndex = 1; break;
    case svSocks5 : cbProxyType->ItemIndex = 2; break;
  }
  edtServer->Text = Client->SocksServer->Address;
  edtPort->Text = IntToStr(Client->SocksServer->Port);
  edtUserID->Text = Client->SocksServer->UserCode;
  edtProxyPassword->Text = Client->SocksServer->Password;
}
//---------------------------------------------------------------------------
void __fastcall TfrmOptions::cbUseProxyClick(TObject *Sender)
{
  if (cbUseProxy->Checked)
    EnableProxyEdits();
  else
    DisableProxyEdits();
}
//---------------------------------------------------------------------------
void __fastcall TfrmOptions::btnMSNSignUpClick(TObject *Sender)
{
  ShellExecute(0, "open", "http://memberservices.passport.com/Default.asp", "", "", SW_SHOWNORMAL);
}
//---------------------------------------------------------------------------
void __fastcall TfrmOptions::btnAOLSignupClick(TObject *Sender)
{
  ShellExecute(0, "open", "http://aim.aol.com/aimnew/Aim/register.adp?promo=106723&pageset=Aim&client=no", "", "", SW_SHOWNORMAL);
}
//---------------------------------------------------------------------------
