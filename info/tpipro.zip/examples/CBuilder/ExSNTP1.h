//---------------------------------------------------------------------------
#ifndef ExSNTP1H
#define ExSNTP1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpSock.hpp"
#include "IpTime.hpp"
#include "IpUtils.hpp"
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TStatusBar *StatusBar1;
    TGroupBox *gbOptions;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label2;
    TLabel *Label1;
    TLabel *Label14;
    TComboBox *cbxBroadcastMode;
    TEdit *edtSyncThreshold;
    TEdit *edtPollInterval;
    TEdit *edtURL;
    TComboBox *cbxLocalHost;
    TGroupBox *gbTimestamp;
    TLabel *Label5;
    TLabel *Label6;
    TLabel *Label7;
    TLabel *Label8;
    TLabel *Label9;
    TLabel *Label10;
    TLabel *Label11;
    TBevel *Bevel1;
    TLabel *Label12;
    TLabel *Label13;
    TEdit *edtYear;
    TEdit *edtMonth;
    TEdit *edtDay;
    TEdit *edtHour;
    TEdit *edtMinute;
    TEdit *edtSecond;
    TEdit *edtMillisecond;
    TEdit *edtOffset;
    TEdit *edtDelay;
    TButton *btnPoll;
    TIpSNTPClient *IpSNTPClient1;
    TTimer *Timer1;
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall edtPollIntervalExit(TObject *Sender);
    void __fastcall Timer1Timer(TObject *Sender);
    void __fastcall edtSyncThresholdExit(TObject *Sender);
    void __fastcall btnPollClick(TObject *Sender);
    void __fastcall cbxLocalHostDropDown(TObject *Sender);
    void __fastcall cbxLocalHostChange(TObject *Sender);
    void __fastcall IpSNTPClient1SNTPTime(TObject *Sender,
          TDateTime TimeStamp, double LocalOffset, double RoundTripDelay,
          BYTE Stratum, bool Synchronized);
private:	// User declarations
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
