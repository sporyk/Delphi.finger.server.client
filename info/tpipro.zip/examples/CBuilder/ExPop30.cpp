// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ExPop30.h"
#include "ExMsgVw.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpMsg"
#pragma link "IpPop3"
#pragma link "IpSock"
#pragma link "IpUtils"
#pragma resource "*.dfm"
TForm1 *Form1;
Cardinal RetrieveNum;
int RetrieveIndex;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  // set the column headings and default widths, widths are based on
  // PreviewGrid.Width = 600
  PreviewGrid->Cells[0][0] = "Msg #";
  PreviewGrid->Cells[1][0] = "From";
  PreviewGrid->Cells[2][0] = "Subject";
  PreviewGrid->Cells[3][0] = "Date";
  PreviewGrid->Cells[4][0] = "Attachment";
  PreviewGrid->Cells[5][0] = "Size";
  PreviewGrid->ColWidths[0] = 40;
  PreviewGrid->ColWidths[1] = 150;
  PreviewGrid->ColWidths[2] = 200;
  PreviewGrid->ColWidths[3] = 80;
  PreviewGrid->ColWidths[4] = 60;
  PreviewGrid->ColWidths[5] = 60;
  StatusBar1->Panels->Items[1]->Width = ClientWidth - 100;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnCheckMessagesClick(TObject *Sender)
{
  RetrieveIndex = 1;
  if (btnCheckMessages->Caption == "Check messages"){
    //  Connects, then retrieves list of message numbers
    IpPop3Client1->UserName = edtUserName->Text;
    IpPop3Client1->Password = edtPassword->Text;
    IpPop3Client1->EncryptedLogon = cbxEncryptedLogon->Checked;
    IpPop3Client1->CheckList(edtPop3Address->Text);
    StatusBar1->Panels->Items[0]->Text = "Connecting to " + edtPop3Address->Text;
  } else {
    //  Disconnects nicely
    StatusBar1->Panels->Items[0]->Text = "Disconnecting";
    IpPop3Client1->Quit();
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::IpPop3Client1TaskComplete(
      TIpCustomPop3Client *Client, TIpPop3Tasks Task,
      TStringList *Response)
{
  // the CheckList task is complete, fill in the grid with the message numbers
  // and the message sizes
  if (Task == ptList){
    for (int I=0;I<Response->Count;I++){
      PreviewGrid->RowCount = Response->Count + 1;
      PreviewGrid->Cells[0][I + 1] = IpPop3Client1->ExtractFirstPart(Response->Strings[I]);
      PreviewGrid->Cells[5][I + 1] = IpPop3Client1->ExtractSecondPart(Response->Strings[I]);
    }
    StatusBar1->Panels->Items[0]->Text = "List of messages downloaded";
    StatusBar1->Panels->Items[1]->Text = "0";
    if (cbxDownloadAll->Checked){
      // retrieve the first message
      RetrieveNum = StrToInt(IpPop3Client1->ExtractFirstPart(Response->Strings[0]));
      StatusBar1->Panels->Items[0]->Text = "Downloading message " + IntToStr(RetrieveNum);
      PreviewGrid->Row = RetrieveIndex;
      IpPop3Client1->Retrieve(RetrieveNum);
      RetrieveIndex = 1;
    }
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::IpPop3Client1Message(
      TIpCustomPop3Client *Client, TIpMailMessage *Message)
{
  StatusBar1->Panels->Items[0]->Text = "Message " + IntToStr(RetrieveNum) + " downloaded";
  StatusBar1->Panels->Items[1]->Text = "Done";
  // fill the cells with the applicable strings
  PreviewGrid->Cells[1][RetrieveIndex] = Message->From;
  PreviewGrid->Cells[2][RetrieveIndex] = Message->Subject;
  PreviewGrid->Cells[3][RetrieveIndex] = Message->Date;
  if (Message->MimeParts->Count > 0)
    PreviewGrid->Cells[4][RetrieveIndex] = "Y";
  else
    PreviewGrid->Cells[4][RetrieveIndex] = "N";
  PreviewGrid->Cells[5][RetrieveIndex] = IntToStr(Message->Size);

  PreviewGrid->Objects[0][RetrieveIndex] = Message;

  if(cbxDownloadAll->Checked){
    // retrieve the next message
    RetrieveIndex++;
    if(RetrieveIndex < PreviewGrid->RowCount){
      RetrieveNum = StrToInt(PreviewGrid->Cells[0][RetrieveIndex]);
      StatusBar1->Panels->Items[0]->Text = "Downloading message " + IntToStr(RetrieveNum);
      StatusBar1->Panels->Items[1]->Text = "0";
      PreviewGrid->Row = RetrieveNum;
      IpPop3Client1->Retrieve(RetrieveNum);
    } else {
    StatusBar1->Panels->Items[0]->Text = "Done dowloading " + IntToStr(RetrieveIndex - 1) +
      " messages";
    }
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Delete1Click(TObject *Sender)
{
  // we aren't going to mark any messages for deletion, this is just to show
  // how it is done. The message isn't deleted until the Quit method terminates
  // the connection.
  // IpPop3Client1->Delete(StrToInt(PreviewGrid->Cells[0][PreviewGrid->Row]));
  ShowMessage("Delete not implemented, see comments in the code");
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Download1Click(TObject *Sender)
{
  RetrieveIndex = PreviewGrid->Row;
  RetrieveNum = StrToInt(PreviewGrid->Cells[0][PreviewGrid->Row]);
  StatusBar1->Panels->Items[0]->Text = "Downloading message " + IntToStr(RetrieveNum);
  StatusBar1->Panels->Items[1]->Text = "0";
  IpPop3Client1->Retrieve(RetrieveNum);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Save1Click(TObject *Sender)
{
  if(PreviewGrid->Objects[0][PreviewGrid->Row]){
    if(SaveDialog1->Execute()){
      TIpMailMessage* Msg = dynamic_cast<TIpMailMessage*>
        (PreviewGrid->Objects[0][PreviewGrid->Row]);
      Msg->SaveToFile(SaveDialog1->FileName);
    }
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::IpPop3Client1StateChange(
      TIpCustomPop3Client *Client, TIpPop3States State)
{
  if (cbEnableStatus->Checked)
    lbxStatus->Items->Add(IpPop3Client1->StateToStr(State));
  if (State == psList) {
    lblNumMessages->Caption = IntToStr(IpPop3Client1->NumMessages) + " messages";
    lblMailBoxSize->Caption = IntToStr(IpPop3Client1->MailBoxSize) + " bytes";
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::View1Click(TObject *Sender)
{
  ViewMessage((TIpMailMessage*) PreviewGrid->Objects[0][PreviewGrid->Row]);
}
//---------------------------------------------------------------------------


void __fastcall TForm1::PreviewGridMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
  TGridCoord GC = PreviewGrid->MouseCoord(X, Y);
  PreviewGrid->Row = GC.Y;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::PopupMenu1Popup(TObject *Sender)
{
  bool ValidMsg = PreviewGrid->Cells[4][PreviewGrid->Row] != "";
  Delete1->Enabled = ValidMsg;
  Download1->Enabled = !ValidMsg;
  Save1->Enabled = ValidMsg;
  View1->Enabled = ValidMsg;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::IpPop3Client1Progress(TIpCustomPop3Client *Client,
      DWORD CharsTransferred)
{
  if (IpPop3Client1->State == psRetr)
    StatusBar1->Panels->Items[1]->Text = IntToStr(CharsTransferred);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::IpPop3Client1Status(TObject *Sender, DWORD Socket,
      TIpStatusType Event, const TIpConnRec &Connection,
      const TIpSockStatRec &StatRec)
{
  if (Event == stConnect){
    btnCheckMessages->Caption = "Quit";
  } else if (Event == stDisconnect){
    btnCheckMessages->Caption = "Check messages";
  }
}
//---------------------------------------------------------------------------

