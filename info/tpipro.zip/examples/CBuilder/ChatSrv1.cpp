// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "ChatSrv1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpSock"
#pragma link "IpUtils"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpServer1Status(TObject *Sender, DWORD Socket,
      TIpStatusType Event, const TIpConnRec &Connection,
      const TIpSockStatRec &StatRec)
{
  AnsiString tmp_str = IpServer1->LookupName( Connection.RemoteAddr );
  switch( Event ) {
    case stConnect :
      {
        // log activity
        ServerMemo->Lines->Add( "Connection from " + tmp_str           );
        ServerMemo->Lines->Add( "Socket for "      + tmp_str           +
                                " :"               + IntToStr( Socket ));

        /*--------------------------------------------------------------------*/
        // note : max clients should restrict the number of connections
        // so I do not verify that we have enough slots for everyone
        /*--------------------------------------------------------------------*/
        int i = 0;
        while( SocketArray[ i ].Socket ) i++;
        SocketArray[ i ].Socket = Socket;
      }
    break;
    case stDisconnect :
      {
        // remove the old one from the list
        int i = 0;
        while(( SocketArray[ i ].Socket != Socket )) i++;

        SocketArray[ i ].Socket   = NULL                     ;
        AnsiString tmp_name       = SocketArray[ i ].UserName;
        SocketArray[ i ].UserName = ""                       ;

        // since we have StripLineTerminator set true; we need to add a new terminator
        AnsiString tmp_str = IntToStr( TALK )          + tmp_name +
                             " has left the building." + "\r\n"   ;

        // let everyone know about the exiting user
        for( int x = 0; x < MAXCONNECTIONS; x++ ){
          if(( SocketArray[ x ].Socket ))
            IpServer1->PutString( SocketArray[ x ].Socket, tmp_str, false );
        }

        // send the new list to everyone
        for( int x = 0; x < MAXCONNECTIONS; x++ ){
          if(( SocketArray[ x ].Socket )){
            tmp_str = IntToStr( USERS );
            for( int r = 0; r < MAXCONNECTIONS; r++ ){
              if( SocketArray[ r ].Socket ){
                tmp_str = tmp_str + SocketArray[ r ].UserName + "\t";
              }
            }
            tmp_str = tmp_str + "\r\n";
            IpServer1->PutString( SocketArray[ x ].Socket, tmp_str, false );
          }
        }
        try{
          ServerMemo->Lines->Add( "Disconnection from " + IpServer1->LookupName( Connection.RemoteAddr ));
        }catch( ... ){
          // someone may still be connected but our socket is closed
        }
      }
    break;
    case stProgress :
    break;
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpServer1ReadLine(TObject *Sender, DWORD Socket,
      const AnsiString Line)
{

  try{
    int tmp_int = StrToInt( Line.SubString( 0, ( 1 )));
    switch( tmp_int ){
      case HELLO :
        {
          int tmp_int = 0;
          AnsiString tmp_str1 = Line.SubString( 2, ( Line.Length( )));
          AnsiString tmp_str2 = tmp_str1                             ;

          while( HaveName( tmp_str1 )){
            tmp_int++;
            tmp_str1 = tmp_str2 + "( " + IntToStr( tmp_int ) + " )";
          }

          // add a name to associate with the socket
          for( int x = 0; x < MAXCONNECTIONS; x++ ){
            if(( SocketArray[ x ].Socket == Socket ))
              SocketArray[ x ].UserName = tmp_str1;
          }

          AnsiString tmp_str = IntToStr( TALK )     + tmp_str1 +
                               " is now among us." + "\r\n"   ;
          // let everyone know about the new Luser
          for( int x = 0; x < MAXCONNECTIONS; x++ ){
            if(( SocketArray[ x ].Socket ))
              IpServer1->PutString( SocketArray[ x ].Socket, tmp_str, false );
          }

          // send the new list to everyone
          for( int x = 0; x < MAXCONNECTIONS; x++ ){
            if(( SocketArray[ x ].Socket )){
              tmp_str1 = IntToStr( USERS );
              for( int r = 0; r < MAXCONNECTIONS; r++ ){
                if( SocketArray[ r ].Socket ){
                  tmp_str1 = tmp_str1 + SocketArray[ r ].UserName + "\t";
                }
              }
              tmp_str1 = tmp_str1 + "\r\n";
              IpServer1->PutString( SocketArray[ x ].Socket, tmp_str1, false );
            }
          }
        }
      break;
      case TALK :
        {
          AnsiString tmp_name;
          // find the user name
          for( int r = 0; r < MAXCONNECTIONS; r++ ){
            if(( SocketArray[ r ].Socket == Socket ))
              tmp_name = SocketArray[ r ].UserName;
          }

          // since we have StripLineTerminator set true; we need to add a new terminator
          AnsiString tmp_str = IntToStr( TALK ) + tmp_name + " : " +
                               Line.SubString( 2, ( Line.Length() )) + "\r\n";
          // broadcast to everyone
          for( int x = 0; x < MAXCONNECTIONS; x++ ){
            if(( SocketArray[ x ].Socket ))
              IpServer1->PutString( SocketArray[ x ].Socket, tmp_str, false );
          }
          // make a log of this action
          ServerMemo->Lines->Add( tmp_name + Line );
        }
      break;
      case PRIVT :
        {
          DWORD tmp_dword                                           ;
          int tmp_int2        = Line.Pos( "\t" )                    ;
          AnsiString tmp_name = Line.SubString( 2, ( tmp_int2 - 2 ));
          AnsiString rec_name = tmp_name                            ;

          // find the receiver
          bool found = false;
          for( int x = 0; x < MAXCONNECTIONS; x++ ){
            if( tmp_name == SocketArray[ x ].UserName ){
              tmp_dword = SocketArray[ x ].Socket;
              found = true;
              break;
            }
          }

          if( found ){
            // find the Senders name
            for( int r = 0; r < MAXCONNECTIONS; r++ ){
              if(( SocketArray[ r ].Socket == Socket ))
                tmp_name = SocketArray[ r ].UserName;
            }

            // send to recipient
            AnsiString tmp_str = IntToStr( PRIVT ) + tmp_name + " : " +
                                 Line.SubString( tmp_int2 + 1 ,( Line.Length() )) +
                                 "\r\n";

            IpServer1->PutString( tmp_dword, tmp_str, false );

            // send it back to the luser
            tmp_str = IntToStr( TALK ) + "Private message to " + rec_name + " : " +
                                 Line.SubString( tmp_int2 + 1 ,( Line.Length() )) +
                                 "\r\n";

            IpServer1->PutString( Socket, tmp_str, false );

            // make a log of this action
            ServerMemo->Lines->Add( tmp_str + Line );
          }
        }
      break;
      default:
      break;
    }
  }catch(...){
    // it may have not been what we expected
    // some error stuff should go here
  }
}
//---------------------------------------------------------------------------
bool __fastcall TForm1::HaveName( AnsiString Name )
{
  // add a name to associate with the socket
  for( int x = 0; x < MAXCONNECTIONS; x++ ){
    if(( SocketArray[ x ].UserName == Name ))
      return( true );
  }
  return( false );
}

//---------------------------------------------------------------------------
