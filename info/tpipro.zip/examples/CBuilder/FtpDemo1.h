//---------------------------------------------------------------------------
#ifndef FtpDemo1H
#define FtpDemo1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpFtp.hpp"
#include "IpSock.hpp"
#include "IpUtils.hpp"
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Menus.hpp>
#include <Tabnotbk.hpp>
#include "IpMupc.hpp"
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TTabbedNotebook *TabbedNotebook1;
    TIpFtpDirectoryTree *IpFtpDirectoryTree1;
    TListBox *lbxFiles;
    TRadioGroup *rgDirStyle;
    TLabel *Label1;
    TLabel *Label6;
    TRadioGroup *ReceiveMode1;
    TRadioGroup *SendMode1;
    TEdit *TimeoutEdit;
    TEdit *edtRestartAt;
    TRadioGroup *FileType1;
    TMemo *ReplyMemo;
    TButton *btnRetrieve;
    TButton *btnDelete;
    TButton *btnStore;
    TGroupBox *GroupBox1;
    TLabel *Label7;
    TLabel *Label2;
    TLabel *Label3;
    TEdit *edtURL;
    TEdit *edtUserName;
    TEdit *edtPassword;
    TCheckBox *chkPassive;
    TGroupBox *GroupBox2;
    TLabel *Label4;
    TLabel *Label5;
    TLabel *Label8;
    TLabel *Label9;
    TLabel *Label10;
    TEdit *edtSocksPort;
    TEdit *edtSocksAddress;
    TEdit *edtSocksPassword;
    TEdit *edtSocksUserCode;
    TComboBox *cbxSocksVersion;
    TButton *LoginBtn;
    TButton *LogoutBtn;
    TButton *ExitBtn;
    TIpFtpClient *IpFtpClient1;
    TMainMenu *MainMenu1;
    TMenuItem *File1;
    TMenuItem *Login1;
    TMenuItem *Logout1;
    TMenuItem *N2;
    TMenuItem *Send1;
    TMenuItem *Retrieve1;
    TMenuItem *Rename1;
    TMenuItem *Delete1;
    TMenuItem *N1;
    TMenuItem *Exit1;
    TMenuItem *Directory1;
    TMenuItem *List1;
    TMenuItem *FullList1;
    TMenuItem *NamesList1;
    TMenuItem *Change1;
    TMenuItem *CreateDir1;
    TMenuItem *Rename2;
    TMenuItem *N3;
    TMenuItem *Delete2;
    TMenuItem *Misc1;
    TMenuItem *Help1;
    TMenuItem *Status1;
    TMenuItem *SendFtp1;
    TOpenDialog *OpenDialog1;
    TButton *btnAbort;
    void __fastcall FormCreate(TObject *Sender);
    void __fastcall Login1Click(TObject *Sender);
    void __fastcall Logout1Click(TObject *Sender);
    void __fastcall Exit1Click(TObject *Sender);
    void __fastcall Change1Click(TObject *Sender);
    void __fastcall NamesList1Click(TObject *Sender);
    void __fastcall FullList1Click(TObject *Sender);
    void __fastcall Help1Click(TObject *Sender);
    void __fastcall Send1Click(TObject *Sender);
    void __fastcall Recieve1Click(TObject *Sender);
    void __fastcall CreateDir1Click(TObject *Sender);
    void __fastcall Delete1Click(TObject *Sender);
    void __fastcall SendFtp1Click(TObject *Sender);
    void __fastcall Status1Click(TObject *Sender);
    void __fastcall Rename1Click(TObject *Sender);
    void __fastcall IpFtpDirectoryTree1Change(TObject *Sender,
          TTreeNode *Node);
    void __fastcall IpFtpDirectoryTree1Changed(TObject *Sender);
    void __fastcall rgDirStyleClick(TObject *Sender);
    void __fastcall FileType1Click(TObject *Sender);
    void __fastcall TimeoutEditExit(TObject *Sender);
    void __fastcall btnRetrieveClick(TObject *Sender);
    void __fastcall btnDeleteClick(TObject *Sender);
    void __fastcall btnStoreClick(TObject *Sender);
    void __fastcall IpFtpClient1FtpError(TObject *Sender, int ErrorCode,
          const AnsiString ErrorText);
    void __fastcall IpFtpClient1FtpReply(TObject *Sender, int ReplyCode,
          const AnsiString Reply);
    
    void __fastcall IpFtpClient1FtpStatus(TObject *Sender,
          TIpFtpStatusCode StatusCode, const AnsiString Info);
    void __fastcall btnAbortClick(TObject *Sender);
private:	// User declarations
    void __fastcall DeleteNext(void);
    void __fastcall RetrieveNext(void);
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
