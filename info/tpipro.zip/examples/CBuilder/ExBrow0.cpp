// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
/* Feeding the HTML Panel using IpHttpClient and IpHtmlDataProvider      */
/* demonstrates how to get more low-level control over the HTTP activity */
//---------------------------------------------------------------------------
#include <vcl.h>
#if (__BORLANDC__ > 0x530)  // Jpeg unit not included in Builder 3
#include <Jpeg.hpp>
#endif
#pragma hdrstop

#include "ExBrowPr.h"
#include "Exbrowsc.h"
#include "ExBrow0.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpBroker"
#pragma link "IpCache"
#pragma link "IpHtml"

#pragma link "IpHttp"
#pragma link "IpSock"
#pragma link "IpUtils"
#pragma link "IpPngImg"

#pragma resource "*.dfm"
TfrmBrowsr0 *frmBrowsr0;
//---------------------------------------------------------------------------
__fastcall TfrmBrowsr0::TfrmBrowsr0(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::Button1Click(TObject *Sender)
{
  DoOpenPage(ComboBox1->Text);
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::DoOpenPage(const AnsiString URL)
{
  if (URL != "")
  {
    FCancelled = false;
    AnsiString Prefix, tmpURL;
    Prefix = UpperCase(URL.SubString(1, 5));
    if ((Prefix != "HTTP:") && (Prefix != "FILE:"))
      tmpURL = "http://" + URL;
    else
      tmpURL = URL;
    SetStatus("Downloading from " + tmpURL + " ...");
    IpHTMLPanel1->OpenURL(tmpURL);
    AddToHistory(tmpURL);
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::AddToHistory(const AnsiString URL)
{
  ComboBox1->ItemIndex = ComboBox1->Items->IndexOf(URL);
  if (ComboBox1->ItemIndex == -1) {
    ComboBox1->Items->Add(URL);
    ComboBox1->ItemIndex = ComboBox1->Items->IndexOf(URL);
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::SetStatus(const AnsiString StatStr)
{
  lblHot->Caption = StatStr;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::DoGoBack()
{
  IpHTMLPanel1->GoBack();
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::DoGoForward()
{
  IpHTMLPanel1->GoForward();
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::FormCreate(TObject *Sender)
{
  ImageQueue = new TIpImageQueue;
  if (FileExists(ExtractFilePath(Application->ExeName) + HistoryFileName)) {
    ComboBox1->Items->LoadFromFile(ExtractFilePath(Application->ExeName) + HistoryFileName);
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::FormDestroy(TObject *Sender)
{
  ComboBox1->Items->SaveToFile(ExtractFilePath(Application->ExeName) + HistoryFileName);

  delete ViewCopy;
  ViewCopy = NULL;

  delete ImageQueue;
  ImageQueue = NULL;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::HTMLClipboardCopy()
{
  IpHTMLPanel1->CopyToClipboard();
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::HTMLSelectAll()
{
  IpHTMLPanel1->SelectAll();
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::IpCache1LoadFromCache(TObject *Sender,
      const AnsiString Item, const AnsiString CacheFileName)
{
  if (ImageQueue->IndexOf(Item) > -1) {
    ImageQueue->Entries[Item]->CacheName = CacheFileName;
    ImageQueue->Entries[Item]->GotIt = True;
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::IpCache1CacheItem(TObject *Sender,
      const AnsiString Item, const AnsiString CacheFileName,
      TStream *HeaderStream, TStream *ItemStream)
{
  if (ImageQueue->IndexOf(Item) > -1) {
    ImageQueue->Entries[Item]->CacheName = CacheFileName;
    ImageQueue->Entries[Item]->GotIt = True;
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::DownloadEntity(AnsiString URL, AnsiString ContentType)
{
  TIpAddrRec Addr;

  IpParseURL(URL, Addr);
  AnsiString FN = ExtractEntityName(Addr.Path);

  SaveDialog1->FileName = FN;
  if (SaveDialog1->InitialDir == "")
    SaveDialog1->InitialDir = ExtractFilePath(Application->ExeName);

  if (SaveDialog1->Execute()) {
    IpHTTPClient1->Download(URL, SaveDialog1->FileName);
  }
}
//---------------------------------------------------------------------------



void __fastcall TfrmBrowsr0::IpHTMLDataProvider1CheckURL(TObject *Sender,
      const AnsiString URL, bool &Available, AnsiString &ContentType)
{
  TCursor SaveCursor;
  int Rslt;
  TIpAddrRec Addr;

  IpParseURL(URL, Addr);
  Available = False;
  SaveCursor = Screen->Cursor;
  Screen->Cursor = crHourGlass;

  if (UpperCase(Addr.Scheme) == "FILE") {
    Available = True;
    ContentType = "TEXT/HTML";
    return;
  }

  if (IpHTTPClient1->HeadWait(URL))
  try {
    if (IpHTTPClient1->HeaderDat[URL]->Size > 0) {
      Available = True;
      ContentType = UpperCase(IpHTTPClient1->GetElement(URL, "Content-Type"));

      if (UpperCase(ContentType) != "TEXT/HTML") {

        AnsiString Msg = "Download " + ExtractEntityName(Addr.Path) + '?';
        Rslt = Application->MessageBox(
          Msg.c_str(),
          "Inquiry", MB_YESNO || MB_ICONQUESTION);

        switch (Rslt) {
          case IDYES:
            DownloadEntity(URL, ContentType);
            break;
          case IDNO:
            /* nada */
            break;

        }
      }
    }
  }
  __finally {
    IpHTTPClient1->FreeLink(URL);
    Screen->Cursor = SaveCursor;
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::IpHTMLDataProvider1GetHtml(TObject *Sender,
      const AnsiString URL, const TIpFormDataEntity *PostData,
      TStream *&Stream)
{
  char NullChar = 0;
  TCursor SaveCursor;
  TMemoryStream* MemStream;
  TIpAddrRec AddrRec;

  SaveCursor = Screen->Cursor;
  Screen->Cursor = crHourGlass;

  IpParseURL(URL, AddrRec);

  if (UpperCase(AddrRec.Scheme) == "FILE") {
    Stream = new TFileStream(AddrRec.Path, fmOpenRead || fmShareDenyNone);
    Stream->Write(&NullChar, 1);
    Screen->Cursor = SaveCursor;
    return;
  }

  if (PostData) {
    MemStream = new TMemoryStream;
    try {
      PostData->SaveToStream(MemStream);
      MemStream->Seek(0, 0);
      IpHTTPClient1->Post(URL, MemStream);
    }
    __finally {
      delete MemStream;
    }
  }
  else {

    Stream = NULL;
    if (IpHTTPClient1->GetWait(URL)) {
      Stream = new TMemoryStream;
      dynamic_cast<TMemoryStream *>(Stream)->LoadFromStream(IpHTTPClient1->BodyStream[URL]);
      AddToHistory(URL);
    }
    else {
      if (!FCancelled)
        ShowMessage("Error Getting Page "" + URL + """);
    }
    /* clear old view copy, if any */
    if (ViewCopy != NULL)
    {
      delete ViewCopy;
      ViewCopy = NULL;
    }
    /* save a copy of the stream so that we can view the source */
    if (Stream != NULL)
    {
      ViewCopy = new TMemoryStream;
      ViewCopy->CopyFrom(Stream, Stream->Size);
      Stream->Seek(0, 0);
    }
  }
  Screen->Cursor = SaveCursor;
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::IpHTMLDataProvider1GetImage(
      TIpHtmlNode *Sender, const AnsiString URL, TPicture *&Picture)
{
  TIpImageQueueEntry NewEntry;
  int I;

  // Default graphic handling
  if (CheckBox1->Checked) {
    Picture = new TPicture;
    Picture->LoadFromFile(DefaultGraphic);
    return;
  }

  I = ImageQueue->IndexOf(URL);

  if ((I > -1) && (ImageQueue->Entries[URL]->Failed)) return;

// Image already in Queue
  if ((I > -1) && (ImageQueue->Entries[URL]->GotIt)) {
   LoadImage(URL, Picture);
   Update();
  }
// New Image request
  else {
    Picture = NULL;
    NewEntry.URL = URL;
    NewEntry.CacheName = "";
    NewEntry.ClientNode = Sender;
    NewEntry.ClientHtml = Sender->Owner;
    NewEntry.Abandoned = False;
    NewEntry.Done = False;
    NewEntry.InProgress = False;
    NewEntry.Failed = False;
    NewEntry.GotIt = False;
    ImageQueue->AddEntry(NewEntry);

    if (I < 0) // no previous request
      IpHTTPClient1->GetAsync(URL);
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::IpHTTPClient1GotItem(TObject *Sender,
      DWORD Socket, const AnsiString Item, bool Cached)
{
  TPicture* Picture;
  TPicture* PictureCopy;
  int i;

  Picture = NULL;
  if (ImageQueue->IndexOf(Item) > -1) {
    if (ImageQueue->Entries[Item]->GotIt) {
      LoadImage(Item, Picture);

      if (Picture) {
        for (i = ImageQueue->Count - 1; i >= 0; i--) {
          if (ImageQueue->Items[i]->URL == Item) {
            PictureCopy = new TPicture;
            PictureCopy->Assign(Picture);
            ImageQueue->Items[i]->ClientNode->ImageChange(PictureCopy);
            ImageQueue->Items[i]->Done = True;
          }
        }
      }
      Update();
      delete Picture;
    }
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::LoadImage(AnsiString ImgURL, TPicture*& Picture)
{
  TIpImageQueueEntry* QueueEntry = ImageQueue->Entries[ImgURL];

  if ((!QueueEntry->GotIt) && (!QueueEntry->Done)) {
    Picture = NULL;
    return;
  }
  else {
    Picture = new TPicture;
    try {
      if (FileExists(IpCache1->InternalCacheDir + QueueEntry->CacheName)) {
        Picture->LoadFromFile(IpCache1->InternalCacheDir + QueueEntry->CacheName);
      }
    }
    catch (...) {
      delete Picture;
      Picture = NULL;
    }
  }
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::Button2Click(TObject *Sender)
{
  DoGoBack();  
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::Button3Click(TObject *Sender)
{
  DoGoForward();  
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::mnBackClick(TObject *Sender)
{
  DoGoBack();  
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::mnForwardClick(TObject *Sender)
{
  DoGoForward();  
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::IpHTMLDataProvider1Leave(TIpHtml *Sender)
{
  PIpImageQueueEntry CurEntry;

  for (int i = ImageQueue->Count - 1; i >= 0; i--) {
    CurEntry = ImageQueue->Items[i];
    if (CurEntry->ClientHtml == Sender) {
      CurEntry->Abandoned = True;
      IpHTTPClient1->FreeLink(ImageQueue->Items[i]->URL);
    }
  }
  IpHTTPClient1->FreeLink(CurURL);
}
//---------------------------------------------------------------------------
AnsiString __fastcall TfrmBrowsr0::GetCurURL()            // read method
{
  return ComboBox1->Text;
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::SetCurURL(AnsiString Value)  // write method
{
  if (CurURL != Value) {
    LastUrl = ComboBox1->Text;
    ComboBox1->Text = Value;
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::mnSaveAsClick(TObject *Sender)
{
  if (SaveDialog1->Execute()) {
    dynamic_cast<TIpHtmlNodeIMG *>(IpHTMLPanel1->CurElement->Owner)->
      Picture->SaveToFile(SaveDialog1->FileName);
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::mnCopyClick(TObject *Sender)
{
  HTMLClipboardCopy();
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::mnEdit_CopyClick(TObject *Sender)
{
  HTMLClipboardCopy();
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::mnEdit_SelectAllClick(TObject *Sender)
{
  HTMLSelectAll();
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnEdit_PreferencesClick(TObject *Sender)
{
  LoadPreferences();
  if (frmBrowConfig->ShowModal() == mrOk) {
    SavePreferences();
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::LoadPreferences()
{
  AnsiString S = "";
  BrowsrIni = new TIniFile(ExtractFilePath(Application->ExeName) + INIFileName);

  S = BrowsrIni->ReadString("Init", "DefaultGraphic", "");
  DefaultGraphic = S;
  frmBrowConfig->Edit7->Text = S;


  S = BrowsrIni->ReadString("Init", "CacheDir", "");
  try {
    IpHTTPClient1->Cache->CacheDir = S;
  }
  catch (...) {
    // invalid path, use the system default
    S.SetLength(255);
    DWORD L = GetTempPath(255, &S[1]);
    S.SetLength(L);
    IpHTTPClient1->Cache->CacheDir = S;
  }
  frmBrowConfig->Edit6->Text = S;

  S = BrowsrIni->ReadString("Colors", "TextColor", "clBlack");
  IpHTMLPanel1->TextColor = StringToColor(S);
  frmBrowConfig->Edit2->Text = S;

  S = BrowsrIni->ReadString("Colors", "LinkColor", "clBlue");
  IpHTMLPanel1->LinkColor = StringToColor(S);
  frmBrowConfig->Edit3->Text = S;

  S = BrowsrIni->ReadString("Colors", "ActiveLinkColor", "clRed");
  IpHTMLPanel1->ALinkColor = StringToColor(S);
  frmBrowConfig->Edit4->Text = S;

  S = BrowsrIni->ReadString("Colors", "VisitedLinkColor", "clMaroon");
  IpHTMLPanel1->VLinkColor = StringToColor(S);
  frmBrowConfig->Edit5->Text = S;

  S = BrowsrIni->ReadString("Init", "DefaultPage", "http://www.turbopower.com/");

  AutoOpen = (BrowsrIni->ReadString("Init", "AutoOpen", "0") == "1");

  BrowsrIni->Free();

  DefaultPage = S;
  CurURL = S;
  frmBrowConfig->Edit1->Text = S;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::SavePreferences()
{
  AnsiString S;

  BrowsrIni = new TIniFile(ExtractFilePath(Application->ExeName) + INIFileName);

  S = frmBrowConfig->Edit1->Text;
  BrowsrIni->WriteString("Init", "DefaultPage", S);
  DefaultPage = S;

  S = frmBrowConfig->Edit7->Text;
  BrowsrIni->WriteString("Init", "DefaultGraphic", S);
  DefaultGraphic = S;

  S = frmBrowConfig->Edit6->Text;
  if (!DirExists(S)) {
    // if the dir doesn't exist, use the system Temp path
    S.SetLength(255);
    DWORD L = GetTempPath(255, &S[1]);
    S.SetLength(L);
  }
  BrowsrIni->WriteString("Init", "CacheDir", S);
  IpHTTPClient1->Cache->CacheDir = S;

  S = frmBrowConfig->Edit2->Text;
  BrowsrIni->WriteString("Colors", "TextColor", S);
  IpHTMLPanel1->TextColor = StringToColor(S);

  S = frmBrowConfig->Edit3->Text;
  BrowsrIni->WriteString("Colors", "LinkColor", S);
  IpHTMLPanel1->LinkColor = StringToColor(S);


  S = frmBrowConfig->Edit4->Text;
  BrowsrIni->WriteString("Colors", "ActiveLinkColor", S);
  IpHTMLPanel1->ALinkColor = StringToColor(S);

  S = frmBrowConfig->Edit5->Text;
  BrowsrIni->WriteString("Colors", "VisitedLinkColor", S);
  IpHTMLPanel1->VLinkColor = StringToColor(S);

  switch (frmBrowConfig->CheckBox1->Checked) {
    case false:
      S = "0";
      break;
    case true:
      S = "1";
      break;
  }
  BrowsrIni->WriteString("Init", "AutoOpen", S);

  delete BrowsrIni;
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::PopupMenu1Popup(TObject *Sender)
{
  mnSaveAs->Enabled =
    (IpHTMLPanel1->CurElement != NULL)
    && dynamic_cast<TIpHtmlNodeIMG *>(IpHTMLPanel1->CurElement->Owner);
  mnCopy->Enabled =
    IpHTMLPanel1->HaveSelection();
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::FormShow(TObject *Sender)
{
  LoadPreferences();
  if (AutoOpen && (CurURL != ""))
    DoOpenPage(CurURL);
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::SetDone()
{
  lblHot->Caption = "Done.";
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnFile_OpenClick(TObject *Sender)
{
  Boolean IsNewURL;
  AnsiString NewURL;

  NewURL = CurURL;
  IsNewURL = InputQuery("Open Page", "Enter the URL you would like to open", NewURL);

  if (IsNewURL) {
    CurURL = NewURL;
    IpHTMLPanel1->OpenURL(CurURL);
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::mnFile_ExitClick(TObject *Sender)
{
  IpHTMLPanel1->Stop();
  IpHTTPClient1->Cancel();
  Close();
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::Button5Click(TObject *Sender)
{
  FCancelled = true;
  IpHTMLPanel1->Stop();
  IpHTTPClient1->Cancel();
  SetStatus("Done");
  Screen->Cursor = crDefault;
}
//---------------------------------------------------------------------------
void __fastcall TfrmBrowsr0::mnView_PageSource1Click(TObject *Sender)
{
  if (ViewCopy) {
    ViewHTMLSource(ViewCopy);
  }
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::Button4Click(TObject *Sender)
{
  CurURL = DefaultPage;
  IpHTMLPanel1->OpenURL(CurURL);
}
//---------------------------------------------------------------------------

void __fastcall TfrmBrowsr0::IpHTMLPanel1HotChange(TObject *Sender)
{
  SetStatus(IpHTMLPanel1->HotURL);
}
//---------------------------------------------------------------------------




