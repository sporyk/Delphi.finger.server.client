//---------------------------------------------------------------------------
#ifndef FinWhoC1H
#define FinWhoC1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "IpSock.hpp"
#include "IpUtils.hpp"
#include <ComCtrls.hpp>
#include "IpMupc.hpp"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TListBox *lbxReplies;
    TGroupBox *gbxOptions;
    TLabel *Label2;
    TEdit *edtURL;
    TEdit *edtFinger;
    TButton *btnFinger;
    TButton *btnCancel;
    TButton *btnWhoIs;
    TEdit *edtWhoIs;
    TStatusBar *StatusBar1;
    TIpFingerWhoIsClient *IpFingerWhoIsClient1;
    void __fastcall btnFingerClick(TObject *Sender);
    void __fastcall btnWhoIsClick(TObject *Sender);
    void __fastcall btnCancelClick(TObject *Sender);
    void __fastcall IpFingerWhoIsClient1Reply(TObject *Sender,
          AnsiString Reply);
    void __fastcall IpFingerWhoIsClient1Error(TObject *Sender,
          DWORD Socket, int ErrCode, const AnsiString ErrStr);
    void __fastcall IpFingerWhoIsClient1IdleTimeout(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
