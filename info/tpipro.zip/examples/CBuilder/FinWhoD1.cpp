// ***** BEGIN LICENSE BLOCK *****
// * Version: MPL 1.1
// *
// * The contents of this file are subject to the Mozilla Public License Version
// * 1.1 (the "License"); you may not use this file except in compliance with
// * the License. You may obtain a copy of the License at
// * http://www.mozilla.org/MPL/
// *
// * Software distributed under the License is distributed on an "AS IS" basis,
// * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
// * for the specific language governing rights and limitations under the
// * License.
// *
// * The Original Code is TurboPower Internet Professional
// *
// * The Initial Developer of the Original Code is
// * TurboPower Software
// *
// * Portions created by the Initial Developer are Copyright (C) 2000-2002
// * the Initial Developer. All Rights Reserved.
// *
// * Contributor(s):
// *
// * ***** END LICENSE BLOCK *****

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "FinWhoD1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "IpMupc"
#pragma link "IpSock"
#pragma link "IpUtils"
#pragma link "IpMupc"
#pragma resource "*.dfm"
TForm1 *Form1;
int HitCount;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
  chkActive->Checked = IpFingerWhoIsServer1->Active;
  rgService->ItemIndex = (int)IpFingerWhoIsServer1->Service;
  cbxLocalHostDropDown(0);
  cbxLocalHost->ItemIndex = IpFingerWhoIsServer1->DefaultLocalAddress;
  HitCount = 0;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::chkActiveClick(TObject *Sender)
{
  IpFingerWhoIsServer1->Active = chkActive->Checked;
  chkActive->Checked = IpFingerWhoIsServer1->Active;
  cbxLocalHost->Enabled = !IpFingerWhoIsServer1->Active;
  rgService->Enabled = !IpFingerWhoIsServer1->Active;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::rgServiceClick(TObject *Sender)
{
  IpFingerWhoIsServer1->Service = (TIpFingerWhoIsService)rgService->ItemIndex;
  rgService->ItemIndex = (int)IpFingerWhoIsServer1->Service;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::cbxLocalHostDropDown(TObject *Sender)
{
  cbxLocalHost->Items->BeginUpdate();
  cbxLocalHost->Items->Clear();
  for (int i = 0; i < IpFingerWhoIsServer1->HostAddressCount; i++)
    cbxLocalHost->Items->Add(IpFingerWhoIsServer1->HostAddress[i]);
  cbxLocalHost->Items->EndUpdate();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::cbxLocalHostChange(TObject *Sender)
{
  IpFingerWhoIsServer1->DefaultLocalAddress = cbxLocalHost->ItemIndex;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpFingerWhoIsServer1Connect(TObject *Sender,
      bool &SendBanner)
{
  if (IpFingerWhoIsServer1->Service == fwsWhoIs)
    SendBanner = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IpFingerWhoIsServer1Query(TObject *Sender,
      const AnsiString Query, AnsiString &Reply, bool &Disconnect)
{
  HitCount++;
  Panel1->Caption = "Hits - " + IntToStr(HitCount);
  InputQuery(Query, "Reply", Reply);
  Disconnect = true;
}
//---------------------------------------------------------------------------

