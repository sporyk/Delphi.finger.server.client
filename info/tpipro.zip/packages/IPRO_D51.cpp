//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("IPRO_D51.res");
USEPACKAGE("vcl50.bpi");
USEPACKAGE("vclx50.bpi");
USEFORMNS("..\source\IpDesign.pas", Ipdesign, IpAboutForm);
USERES("..\source\IpDesign.dcr");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//   Package source.
//---------------------------------------------------------------------------
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
